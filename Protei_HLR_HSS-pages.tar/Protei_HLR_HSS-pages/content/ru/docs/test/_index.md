---
title : "Тестирование системы"
description : ""
weight : 3

---

[Отчет последнего тестирования](https://jenkins.protei.ru/job/team4/job/Testing/job/FunctionalTesting/job/HSS/lastCompletedBuild/cucumber-html-reports/overview-features.html)
