---
title : "CLI"
description : ""
weight : 3

---


## Добавление абонента
### add_subscriber
Позволяет загрузить в HLR нового абонента

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|M|
|Ki|Ключ аутентификации. (TS 33.102)|M|
|algorithm|Алгоритм шифрования. Доступные значения: 1-4. (TS 33.102)|M|
|status|Статус профиля абонента.|M|
|hlr_profile_id|Идентификатор профиля абонента.|O|
|MSISDN|MSISDN абонента|O|
|Group_ID|Идентификатор группы абонентов|O|
|opc|Параметр вектора аутентификации, используется в алгоритме Milenage (TS 43.020)|O|

**Пример**
Добавление абонента IMSI 101010000001000 Ki 7D25499BD1817AAF49BF42939343B299 Algorithm 4 Status 2 c привязанным MSISDN 1010100100 и указанием hlr профиля id=1.
```bash
$ add_subscriber 101010000001000 ki 7D25499BD1817AAF49BF42939343B299 alg 4 status 2 profile_id 1 msisdn 1010100100
{
  "status": "OK"
}
```

### параметры профиля абонента (Profiles.json)
Формат профиля абонента. 
<br>Файл с параметрами профилей расположен в директории /usr/protei/Protei_HLR_API/config и имеет название profiles.json
<br>Изменения в файле считываются автоматически, результат считывания заносится в config.log
<br>Новые профайлы можно создавать и использовать в режиме реального времени. 

|Parameter|Description|O/M|Type|Version|
|---|---|---|---|---|
|Profile_id|Идентификатор профиля|M|Integer|
|SCA|Service Centre Address (3GPP TS 23.040) |O|String|
|O_CSI|Originating CAMEL Subscription Information (3GPP TS 23.008, 3GPP TS 23.078)|O|Integer|
|T_CSI|Terminating CSI (3GPP TS 23.008, 3GPP TS 23.078)|O|Integer|
|SMS_CSI|Short Message Service CSI (3GPP TS 23.008, 3GPP TS 23.078)|O|Integer|
|USSD_CSI|Unstructured Supplementary Service Data CSI (3GPP TS 23.008, 3GPP TS 23.078)|O|Integer|
|M_CSI|Mobility Management CSI (3GPP TS 23.008, 3GPP TS 23.078)|O|Integer|
|GPRS_CSI|GPRS CSI (3GPP TS 23.008, 3GPP TS 23.078) |O|Integer|
|D_CSI|Dialled service CSI (3GPP TS 23.008, 3GPP TS 23.078)|O|Integer|
|O_IM_CSI|Originating IP Multimedia CSI (3GPP TS 23.278)|O|Integer|
|VT_IM_CSI|Terminating IP Multimedia CSI (3GPP TS 23.278)|O|Integer|
|D_IM_CSI|Dialled service IP Multimedia CSI (3GPP TS 23.278)|O|Integer|
|PDP_DATA|Параметры привязанных PDP контекстов в формате: <br>"context-id":"<String>", "address":<String>, "type":"<String>"|O|List|
|TeleServices|Список основных телесервисов (3GPP TS 22.003)|O|List|
|Active_SS|Активные дополнительные услуги, Supplementary Service Codes (3GPP TS 22.030)|O|List|
|NotActive_SS|Неактивные дополнительные услуги, Supplementary Service Codes (3GPP TS 22.030) |O|List|
|Forced_SS|Принудительные дополнительные услуги, Supplementary Service Codes (3GPP TS 22.003)|O|List|
|SS_TeleServices|Коды телесервисов, на базе которых работают дополнительные сервисы|O|List|
|DefaultForwardingNumber|Номер переадресации по-умолчанию |O|String|
|DefaultForwardingStatus|Статус переадресации по-умолчанию |O|String|
|Forwarding|Параметры переадресации |O|String|
|WL_DATA|Привязываемые белые списки|O|List|
|BL_DATA|Привязываемые черные списки |O|List|
|TK_ID|Идентификатор транспортного ключа |O|Integer|
|OP_ID|Идентификатор операторской константы |O|Integer|
|AuCC_ID|Идентификатор параметра C |O|Integer|
|AuCR_ID|Идентификатор параметра R |O|Integer|
|EPS_DATA|Параметры EPS профиля в формате: <br>"ueApnOiRep":"<String>", "ueMaxDl":<int>, "ueMaxUl":<int>, "ratType":<int>, "ratFreqPriorId":<int>, "defContextId":<int>|O||
|EPS_CONTEXTS|Параметры привязанных EPS контекстов в формате: <br>"context-id":"<String>", "ipv4":<String>, "ipv6":"<String>">|O|List|
|LCS_ID|Идентификатор Location Services|O|Integer|
|Group_ID|Идентификатор группы абонентов |O|Integer|
|deacticvatePsi|Отправка сообщений PSI в результате SRI |O|Flag|
|baocWithoutCamel|Запрет исходящих вызовов, если версия CAMEL у абонента не совпадает с версией CAMEL на Protei HLR/HSS |O|Flag|
|qosGprsId|Идентификатор QoS-профиля GPRS |O|Integer|
|qosEpsId|Идентификатор QoS-профиля EPS|O|Integer|
|roamingNotAllowed|Запрет роуминга |O|Flag|
|accessRestrictionData|Ограничения доступа в формате: "utranNotAllowed":<int>, "geranNotAllowed":<int>, "ganNotAllowed":<int>, "iHspaEvolutionNotAllowed":<int>, "wbEUtranNotAllowed":<int>, "hoToNon3GPPAccessNotAllowed":<int>, "nbIotNotAllowed":<int>, "enhancedCoverageNotAllowed":<int>, "nrSecondaryRatEutranNotAllowed":<int>, "unlicensedSpectrumSecondaryRatNotAllowed":<int>, "nr5gsNotAllowed":<int> |O||
|amfUmts|AuthenticationManagementField в сети UMTS (3GPP TS 33.102) |O|String|
|amfLte|AuthenticationManagementField в сети LTE |O|String|
|amfIms|AuthenticationManagementField в сети IMS |O|String|

**Пример**
Профиль абонента с ID=1, привязанными телесервисами, дополнительными сервисами, PDP и EPS контекстами и QoS профилями.
```bash
$ cat /usr/protei/Protei_HLR_API/config/profiles.json 
[
    {
        "Profile_id": 1,
        "TeleServices": [ 17, 18, 33, 34 ],
        "Active_SS": [ 17, 65, 66, 81 ],
        "NotActive_SS": [ 33, 41, 42, 43, 146, 154 ],
        "SS_TeleServices": [ 16 ],
        "PDP_DATA": [ { "context-id": 1, "type": "f121" } ],
        "EPS_CONTEXTS": [ { "context-id": 1 } ],
        "EPS_DATA" : {
         "ueMaxDl" : 100000000,
         "ueMaxUl" : 100000000,
         "ratType" : 1004,
         "defContextId" : 1
         },
        "qosGprsId": 1,
        "qosEpsId": 1
    }
]
```


## Просмотр профиля абонента
### get_profile
Возвращает текущий профиль абонента.

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|

**Пример**
Просмотр профиля абонента c IMSI 101010000001000 
```bash
$ get_profile 101010000001000 
{
  "status": "OK",
  "imsi": "101010000001000",
  "msisdn": "1010100100",
  "administrative_state": 2,
  "forbid_reg": 0,
  "roaming_not_allowed": 0,
  "pdp-data": [],
  "eps-context-data": [
    {
      "eps_context_id": 1,
      "service_selection": "internet",
      "vplmnDynamicAddressAllowed": 0,
      "qosClassId": 9,
      "pdnGwType": 1,
      "pdnType": 2
    },
    {
      "eps_context_id": 2,
      "service_selection": "ims",
      "vplmnDynamicAddressAllowed": 0,
      "qosClassId": 5,
      "allocateRetPriority": 9,
      "pdnGwType": 1,
      "apnOiReplacement": "mnc001.mcc001.gprs",
      "maxDl": 100000000,
      "maxUl": 100000000,
      "pdnType": 2
    },
    {
      "eps_context_id": 3,
      "service_selection": "internet3",
      "vplmnDynamicAddressAllowed": 0,
      "pdnGwType": 1,
      "pdnType": 2
    }
  ],
  "eps-data": [
    {
      "ueMaxDl": 100000000,
      "ueMaxUl": 100000000,
      "ratFreqPriorId": 6,
      "defContextId": 1
    }
  ],
  "csi-list": [],
  "ssData": [],
  "ssForw": [],
  "ssBarring": [],
  "lcsPrivacy": [],
  "lcsMolr": [],
  "teleserviceList": [],
  "bearerserviceList": [],
  "roaming-sgsn-info": {
    "version": 0,
    "dtregistered": "2020-06-01_11:23:33",
    "ispurged": 0,
    "dmMmeHost": "mmec1.mmegi2.mme.epc.mnc1.mcc1.3gppnetwork.org",
    "dmMmeRealm": "epc.mnc1.mcc1.3gppnetwork.org",
    "is-purged-eps-mme": 0,
    "is-purged-eps-sgsn": 0,
    "srvccMme": 0,
    "voImsMme": 0,
    "vplmn": "00101",
    "sf1Mme": 0,
    "sf2Mme": 134217728,
    "supportedSgsnCamel": 0,
    "supportedSgsnLcs": 0,
    "combinedMmeSgsn": 1
  },
  "defaultForwStatus": 0,
  "whiteLists": [],
  "blackLists": [],
  "lcsId": 0,
  "deactivatePsi": 0,
  "ipSmGw": "",
  "networkAccessMode": 0,
  "qosEpsId": 1
}

```

## Удаление абонента
### del_subscriber
Позволяет удалить профиль абонента.
<br>После проведения процедуры профиль будет полностью удален из базы и недоступен.
<br>Если до удаления статус профиля абонента был unlocked, процедура сопровождается отправкой команды CancelLocation по всем доменам. 

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|

**Пример**
Удаление абонента c IMSI 101010000001000 
```bash
$ del_subscriber 101010000001000 
{
  "status": "OK"
}
```

## Смена IMSI (Замена SIMкарты)
### change_imsi
Позволяет осуществить замену SIM-карты, сменив IMSI в профиле абонента. 
<br> Карта с новым IMSI должна быть заранее загружена в HLR. 
<br> После смены для oldIMSI будет установлен статус профиля 4.

|Parameter|Description|O/M|Version|
|---|---|---|---|
|oldIMSI|Старый IMSI абонента|C|
|MSISDN|MSISDN абонента|C|
|IMSI|Новый IMSI абонента|M|
|Status|Статус профиля абонента после смены|O|

**Пример**
Cмена IMSI для абонента c 101010000001000 на 101010000001002
```bash
$ change_imsi 101010000001000 101010000001002
{
  "status": "OK"
}
```

## Отправка Cancel_Location
### cancel_location
Позволяет отправить Cancel_Location на текущие VLR/SGSN/MME абонента

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|
|Domain| Возможные значения: CS, PS, EPS. По-умолчанию идет отправка по всем доменам  |O|
|reattachRequired| Определяет необходимость проведения процедуры Reattach |O|

**Пример**
Отправка CL в EPS домене для 101010000001000 с необходимостью Reattach
```bash
$ cancel_location 101010000001000 EPS reattach
{
  "status": "OK"
}
```
**Пример**
Отправка CL для 101010000001000 по всем доменам
```bash
$ cancel_location 101010000001000 
{
  "status": "OK"
}
```

## Блокировка и разблокировка профиля абонента
### change_status
Позволяет сменить статус профиля абонента, например заблокировать или снять блокировку профиля.
<br>При переходе из статуса unlocked в любой другой, сопровождается отправкой команды CancelLocation по всем доменам. 

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|
|Status|Статус профиля: <br><ul><li>0 - not provisioned - карта не привязана к MSISDN</li><li>1 - provisioned/locked - карта привязана к MSISDN и заблокирована</li><li>2 - provisioned/unlocked - в обслуживании</li><li>3 - provisioned/suspended - приостановка обслуживания, например, при краже телефона</li><li>4 - terminated - абонент удален</li></ul>|M|

**Пример**
Блокировка профиля абонента 101010000001000
```bash
$ change_status 101010000001000 locked
{
  "status": "OK"
}
```
**Пример**
Разблокировка профиля абонента 101010000001000
```bash
$ change_status 101010000001000 unlocked
{
  "status": "OK"
}
```


## Управление EPS-data абонента
### add_eps
Позволяет привязать EPS-контекст и добавить/изменить связанный с ним статический IP-адрес.

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|
|EPS-ID|EPS context ID|M|
|ipv4 ADDRESS|Статический IPv4|O|
|ipv6 ADDRESS|Статический IPv6|O|
|plmnId ID|Идентификатор PLMN|O|

**Пример**
Привязка EPS-context-ID = 1, связанные с ним IPv4 = 1.1.1.1 и IPv6 = 2222:2222:2222:2222:2222:2222:2222:2222 для сети с PLMN_id = 1 абоненту 101010000001000
```bash
$ add_eps 101010000001000 1 ipv4 1.1.1.1 ipv6 2222:2222:2222:2222:2222:2222:2222:2222 plmnId 1
{
  "status": "OK"
}
```


----------------------------------------------
### del_eps
Позволяет удалить EPS-контекст из профиля абонента.

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|
|EPS-ID|EPS context ID|M|
|plmnId ID|Идентификатор PLMN|O|

**Пример**:
Удаление EPS-context-ID = 1 для сети с PLMN_id = 1 из профиля абонента 101010000001000.
```bash
$ eps_del 101010000001000 1 plmnId 1
{
  "status": "OK"
}
```


## Управление QoS абонента
### add_qos_gprs
Позволяет добавить QoS GPRS в профиль абонента

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|
|QOS-ID|Идентификатор QoS GPRS|M|

**Пример**
Добавление QoS GPRS 1 в профиль абонента 101010000001000
```bash
$ add_qos_gprs  101010000001000 1
{
  "status": "OK"
}
```
### del_qos_gprs
Позволяет удалить QoS GPRS из профиля абонента

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|

**Пример**
Очистка QoS GPRS в профиле абонента 101010000001000
```bash
$ del_qos_gprs  101010000001000 1
{
  "status": "OK"
}
```
### add_qos_eps
Позволяет добавить QoS EPS в профиль абонента

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|
|QOS-ID|Идентификатор QoS EPS|M|

**Пример**
Добавление QoS EPS 1 в профиль абонента 101010000001000
```bash
$ add_qos_eps  101010000001000 1
{
  "status": "OK"
}
```
### del_qos_eps
Позволяет удалить QoS EPS из профиля абонента

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|

**Пример**
Очистка QoS EPS в профиле абонента 101010000001000
```bash
$ del_qos_eps  101010000001000 1
{
  "status": "OK"
}
```
## Управление Черными/Белыми списками абонента
### add_wl
Позволяет добавить один или несколько белых списков в профиль абонента

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|
|WL-LIST|Список идентификаторов WL для добавления|M|

**Пример**
Добавление WL 1 и 2 в профиль абонента 101010000001000
```bash
$ add_wl 101010000001000 1 2
{
  "status": "OK"
}
```

### del_wl
Позволяет удалить один или несколько белых списков из профиля абонента

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|
|WL-LIST|Список идентификаторов BL для удаления|M|

**Пример**
Удаление WL 1 и 2 из профиля абонента 101010000001000
```bash
$ del_wl 101010000001000 1 2
{
  "status": "OK"
}
```
### add_bl
Позволяет добавить один или несколько черных списков в профиль абонента

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|
|BL-LIST|Список идентификаторов BL для добавления|M|

**Пример**
Добавление BL 1 и 2 в профиль абонента 101010000001000
```bash
$ add_bl 101010000001000 1 2
{
  "status": "OK"
}
```

### del_bl
Позволяет удалить один или несколько черных списков из профиля абонента

|Parameter|Description|O/M|Version|
|---|---|---|---|
|IMSI|IMSI абонента|C|
|MSISDN|MSISDN абонента|C|
|BL-LIST|Список идентификаторов BL для удаления|M|

**Пример**
Удаление BL 1 и 2 из профиля абонента 101010000001000
```bash
$ del_bl 101010000001000 1 2
{
  "status": "OK"
}
```
## Управление EPS-Context
### eps_control
Позволяет создать/изменить/удалить EPS-Context

|Parameter|Description|Type|O/M|Version|
|---|---|---|---|---|
|EPS-ID|EPS context identifier|Integer|M||
|COMMAND|create/modify/delete.<br>**Примечание:** при использовании modify необходимо указать все параметры (как при create). Все неуказаные параметры будут null|String|M||
|SERVICE-SELECTION|The APN Network Identifier (per 3GPP TS 23.003, clauses 9.1 & 9.1.1) or the wild card value (per 3GPP TS 23.003, clause 9.2.1, and 3GPP TS 23.008, clause 2.13.6)|String|C||
|PDN-TYPE| Indicates the address type of the PDN.<br><ul><li>0 - IPv4</li><li>1 - IPv6</li><li>2 - IPv4v6</li><li>3 - IPv4_OR_IPv6</li></ul>|Integer|C||
|vplmnDynamicAddressAllowed ISALLOWED|Indicates whether the UE is allowed to use the PDN GW in the domain of the VPLMN. If value is not set, it is not allowed.<br><ul><li>0 - NOTALLOWED, 1 - ALLOWED</li></ul>|Flag|O||
|qosClassId ID|QoS Class Identifier (3GPP TS 23.203 Table 6.1.7.)<br><ul><li>Applicable values: 5-9</ul></li>|Integer|O||
|allocateRetPriority ARP|Allocation Retention Priority.  (3GPP TS 29.212)|Integer|O||
|pdnGwType GW-TYPE|PDN GW type.<br><ul><li>0 - STATIC</li><li>1 - DYNAMIC</li></ul>|Integer|O||
|mip6Ip4 ADDRESS|IPv4 address of the PDN GW|IPv4|O||
|mip6Ip6 ADDRESS|IPv6 address of the PDN GW|IPv6|O||
|mip6AgentHost HOST|The host name of the PDN GW (3GPP TS 29.303, clause 4.3.2)|String|O||
|mip6AgentRealm REALM| Destination-Realm of the PDN GW.<br><ul><li>epc.mnc<MNC>.mcc<MCC>.3gppnetwork.org</ul></li>|String|O||
|visitedNetworkId ID|Identifies the PLMN in which the PDN GW is located|Integer|O||
|chargingCharacteristics CC|EPS PDN Connection Charging Characteristics data|String|O||
|apnOiReplacement APN|Domain name to replace the APN OI (3GPP TS 23.003 and 3GPP TS 29.303.)|String|O||
|maxDl DL|Max Requested Bandwidth DL|Integer|O||
|maxUl UL|Max Requested Bandwidth UL|Integer|O||
|extMaxDl DL|Extended Max Requested Bandwidth DL|Integer|O||
|extMaxUl UL|Extended Max Requested Bandwidth UL|Integer|O||
|preEmptionCapability CAPABILITY|The Pre-emption-Capability IE indicates the pre-emption capability of the request on other E-RABs. (3GPP TS 29.060)|Integer|O||
|preEmptionVulnerability VULNERABILITY|The Pre-emption-Vulnerability IE indicates the vulnerability of the E-RAB to preemption of other E-RABs. (3GPP TS 29.060)|Integer|O||
|mpsPriority MSP|A Multimedia Priority Service bit mask<br><ul><li>Bit 0 - MPS-CS-Priority indicates that the UE is subscribed to the eMLPP or 1x RTT priority service in the CS domain.</li><li>Bit 1 - MPS-EPS-Priority indicates that the UE is subscribed to the MPS in the EPS domain.</li></ul>|Integer|O|2.0.17.0|

**Пример**:
Создание EPS Context со следующими параметрами:
* Context-Identifier = 1
* Service-Selection = APN
* PDN-Type = IPv4 (0)
* VPLMN-Dynamic-Address-Allowed = ALLOWED (1)
* QoS-Class-Identifier = QCI_6 (6)
* Allocation-Retention-Priority-Level = 13
* PDN-GW-Allocation-Type = DYNAMIC (1)
* Max-Requested-Bandwidth-UL = 100000000
* Max-Requested-Bandwidth-DL = 100000000

```bash
$ eps_control 1 create APN 0 vplmnDynamicAddressAllowed 1 qosClassId 6 allocateRetPriority 13 pdnGwType 1 maxDl 100000000 maxUl 100000000 
{
  "status": "OK"
}

```

## Управление PDP-Context
### pdp_control
Позволяет создать/изменить/удалить PDP-Context

|Parameter|Description|Type|O/M|Version|
|---|---|---|---|---|
|PDP-ID|PDP context identifier|Integer|M||
|COMMAND|create/modify/delete. <br>**Примечание:** при использовании modify необходимо указать все параметры (как при create). Все неуказаные параметры будут null|String|M||
|apn|The APN Network Identifier (per 3GPP TS 23.003, clauses 9.1 & 9.1.1) or the wild card value (per 3GPP TS 23.003, clause 9.2.1, and 3GPP TS 23.008, clause 2.13.6)|String|C||
|vplmnAddressAllowed|VPLMN Address Allowed. Indicates whether the UE is allowed to use the APN in the domain of the VPLMN. If value is not set, it is not allowed.<br><ul><li>0 - NOTALLOWED, 1 - ALLOWED</li></ul>|Flag|O||
|extPdpAddress|Extended PDP-Address (it may contain an IPv4 or an IPv6 address)|Integer|O||
|extPdpType|Extended PDP-Type (3GPP TS 29.002, clause 7.6.2.44A).<br><ul><li>f18d</li></ul>|Integer|O||
|pdpChargingCharacteristics|PDP Charging Characteristics(3GPP TS 32.215, clause 5.6)|Integer|O||
|qosSubscribed|QoS-Subscribed (3GPP TS 29.002 version 15.6.0 page 401)<br>https://www.etsi.org/deliver/etsi_ts/129000_129099/129002/15.06.00_60/ts_129002v150600p.pdf|Integer|O||
|extQosSubscribed|Ext-QoS-Subscribed  (3GPP TS 29.002 version 15.6.0 page 401)<br>https://www.etsi.org/deliver/etsi_ts/129000_129099/129002/15.06.00_60/ts_129002v150600p.pdf|Integer|O||
|ext2QosSubscribed|Ext2-QoS-Subscribed  (3GPP TS 29.002 version 15.6.0 page 401)<br>https://www.etsi.org/deliver/etsi_ts/129000_129099/129002/15.06.00_60/ts_129002v150600p.pdf|Integer|O||
|ext3QosSubscribed|Ext3-QoS-Subscribed  (3GPP TS 29.002 version 15.6.0 page 401)<br>https://www.etsi.org/deliver/etsi_ts/129000_129099/129002/15.06.00_60/ts_129002v150600p.pdf|Integer|O||
|ext4QosSubscribed|Ext4-QoS-Subscribed  (3GPP TS 29.002 version 15.6.0 page 401)<br>https://www.etsi.org/deliver/etsi_ts/129000_129099/129002/15.06.00_60/ts_129002v150600p.pdf|Integer|O||




**Пример**:
Создание PDP Context со следующими параметрами:
* Context-Identifier = 10
* APN = internet_test
* VPLMN Address Allowed = ALLOWED (1)
* QoS-Subscribed = Hex(239412)
* Ext-QoS-Subscribed= Hex(0x027196fefe7482ffff)

```bash
$ ./pdp_control 10 create apn internet_test vplmnAddressAllowed 1 qosSubscribed 239412 extQosSubscribed 0x027196fefe7482ffff 
{
  "status": "OK"
}

```

## Управление QoS
### qos_gprs_control
Позволяет создать/изменить/удалить GPRS QoS-профиль

|Parameter|Description|Type|O/M|Version|
|---|---|---|---|---|
|QOS-GPRS-ID|QOS GPRS identifier|Integer|M||
|COMMAND|create/modify/delete.<br>**Примечание:** при использовании modify необходимо указать все параметры (как при create). Все неуказаные параметры будут null|String|M||
|qos QOS|octet of QoS-Subscribed|String|O||
|extqos QOS|octet of Ext-QoS-Subscribed|String|O||
|ext2qos QOS|octet of Ext2-QoS-Subscribed|String|O||
|ext3qos QOS|octet of Ext3-QoS-Subscribed|String|O||
|ext4qos QOS|octet of Ext4-QoS-Subscribed|String|O||

**Пример**:
Создание QoS GPRS со следующими параметрами:
* QoS-Identifier = 1
* QoS-Subscribed = 0000000000
* Ext-QoS-Subscribed = 0000000001
* Ext2-QoS-Subscribed = 0000000002
* Ext3-QoS-Subscribed = 0000000003
* Ext4-QoS-Subscribed = 0000000004
```bash
$ qos_gprs_control 1 create qos 0000000000 extqos 0000000001 ext2qos 0000000002 ext3qos 0000000003 ext4qos 0000000004
{
  "status": "OK"
}

```

### qos_gprs_list
Выводит GPRS QoS-профиль

|Parameter|Description|Type|O/M|Version|
|---|---|---|---|---|
|QOS-GPRS-ID|QOS GPRS identifier|Integer|M||

**Пример**:
Просмотр GPRS QoS 1
```bash
$ qos_gprs_list 1
{
  "status": "OK",
  "qosGprs": {
    "id": 1,
    "qosSubscribed": "0000000000",
    "extQosSubscribed": "0000000001",
    "ext2QosSubscribed": "0000000002",
    "ext3QosSubscribed": "0000000003",
    "ext4QosSubscribed": "0000000004"
  }
}
```

### qos_eps_control
Позволяет создать/изменить/удалить EPS QoS-профиль

|Parameter|Description|Type|O/M|Version|
|---|---|---|---|---|
|QOS-EPS-ID|QOS EPS identifier|Integer|M||
|COMMAND|create/modify/delete.<br>**Примечание:** при использовании modify необходимо указать все параметры (как при create). Все неуказаные параметры будут null|String|M||
|qosClassId ID|QoS Class Identifier (3GPP TS 23.203 Table 6.1.7.)<br><ul><li>Applicable values: 5-9</ul></li>|Integer|O||
|allocateRetPriority ARP|Allocation Retention Priority.  (3GPP TS 29.212)|Integer|O||
|maxDl DL|Max Requested Bandwidth DL|Integer|O||
|maxUl UL|Max Requested Bandwidth UL|Integer|O||
|extMaxDl DL|Extended Max Requested Bandwidth DL|Integer|O||
|extMaxUl UL|Extended Max Requested Bandwidth UL|Integer|O||
|preEmptionCapability CAPABILITY|The Pre-emption-Capability IE indicates the pre-emption capability of the request on other E-RABs. (3GPP TS 29.060)|Integer|O||
|preEmptionVulnerability VULNERABILITY|The Pre-emption-Vulnerability IE indicates the vulnerability of the E-RAB to preemption of other E-RABs. (3GPP TS 29.060)|Integer|O||

**Пример**:
Создание EPS Context со следующими параметрами:
* QoS-Identifier = 1
* QoS-Class-Identifier = QCI_6 (6)
* Allocation-Retention-Priority-Level = 13
* Max-Requested-Bandwidth-UL = 100000000
* Max-Requested-Bandwidth-DL = 100000000

```bash
$ qos_eps_control 1 create  qosClassId 6 allocateRetPriority 13 maxDl 100000000 maxUl 100000000
{
  "status": "OK"
}

```
### qos_eps_list
Выводит EPS QoS-профиль

|Parameter|Description|Type|O/M|Version|
|---|---|---|---|---|
|QOS-EPS-ID|QOS EPS identifier|Integer|M||

**Пример**:
Просмотр EPS QoS 1
```bash
$ qos_eps_list 1
{
  "status": "OK",
  "qosEps": {
    "id": 1,
    "qosClassId": 6,
    "allocateRetPriority": 13,
    "maxDl": 100000000,
    "maxUl": 100000000
  }
}

```
## Управление BlackList

### bl_plmn_control
Позволяет добавить/удалить маску PLMN из BL

|Parameter|Description|O/M|Version|
|---|---|---|---|
|NAME|Название BlackList|M|
|ACTION| Add/Delete |M|
|PLMN_MASK|Regexp маска PLMN|M|
|country COUNTRY|Название страны|O|
|network NETWORK|Название сети|O|

**Пример**
Просмотр BlackList 1
```bash
$ bl_plmn_control BL Add '.(5)' country ALL network ANY
{
  "status": "OK"
}

```
### bl_vlr_control
Позволяет добавить/удалить маску VLR из BL

|Parameter|Description|O/M|Version|
|---|---|---|---|
|NAME|Название BlackList|M|
|ACTION| Add/Delete |M|
|VLR_MASK|Regexp маска VLR|M|
|country COUNTRY|Название страны|O|
|network NETWORK|Название сети|O|

**Пример**
Просмотр BlackList 1
```bash
$ bl_vlr_control BL Add '.(0,22)' country ALL network ANY
{
  "status": "OK"
}

```

### bl_list
Выводит список VLR и PLMN привязанных к черному списку

|Parameter|Description|O/M|Version|
|---|---|---|---|
|ID|Идентификатор BlackList|C|
|NAME|Название BlackList|C|

**Пример**
Просмотр BlackList 1
```bash
$ bl_list BL
{
  "status": "OK",
  "blackList": {
    "id": 1,
    "name": "BL",
    "vlr_masks": [
      {
        "mask": ".(0,22)",
        "country": "ALL",
        "network": "ANY"
      }
    ],
    "plmn_masks": [
      {
        "mask": ".(5)",
        "country": "ALL",
        "network": "ANY"
      }
    ]
  }
}

```
## Управление ограничениями технологий радиодоступа
### ard_control

Позволяет установить/снять Access Restriction Data

| Parameter             | Description                                                   | O/M | Version |
|-----------------------|---------------------------------------------------------------|-----|---------|
| IMSI                  | IMSI абонента                                                 | С   |         |
| MSISDN                | MSISDN абонента                                               | C   |         |
| AccessRestrictionData | Технология, на которую устанавливается запрет.                | O   |         |

Возможные значения ARD (3GPP TS 29.002):

| AccessRestrictionData         | Порядковый номер бита, отвечающий за запрет |
|-------------------------------|---------------------------------------------|
| utranNotAllowed               | (0)                                         |
| geranNotAllowed               | (1)                                         |
| ganNotAllowed                 | (2)                                         |
| i-hspa-evolutionNotAllowed    | (3)                                         |
| wb-e-utranNotAllowed          | (4)                                         |
| ho-toNon3GPP-AccessNotAllowed | (5)                                         |
| nb-iotNotAllowed              | (6)                                         |
| enhancedCoverageNotAllowed    | (7)                                         |

**Пример**

Установить запрет для UTRAN и I-HSPA:
```bash
$ ard_control 101010000001000 1 0 0 1 0 0 0 0
{
  "status": "OK"
}
```

Снять установленные запреты:
```bash
$ ard_control 101010000001000 delete
{
  "status": "OK"
}

```
## Управление операторскими баррингами
### odb_control

Позволяет установить/снять операторские ограничения на услуги

| Parameter         | Description                                                   | O/M | Version |
|-------------------|---------------------------------------------------------------|-----|---------|
| IMSI              | IMSI абонента                                                 | С   |         |
| MSISDN            | MSISDN абонента                                               | C   |         |
| Subscriber Status | <li>0 - Service Granted</li> <li>1 - ODB активны</li>         | M   |         |
| Action            | <li>0 - Запрет не активен</li> <li>1 - Запрет активен</li>    | O   |         |
| ODB-GeneralData   | Категория, на которую можно установить запрет.                | O   |         |

Возможные значения ODB (3GPP TS 29.002):

| ODB-GeneralData                                                  | Порядковый номер бита, отвечающий за запрет |
|------------------------------------------------------------------|---------------------------------------------|
| allOG-CallsBarred                                                | (0)                                         |
| internationalOGCallsBarred                                       | (1)                                         |
| internationalOGCallsNotToHPLMN-CountryBarred                     | (2)                                         |
| interzonalOGCallsBarred                                          | (6)                                         |
| interzonalOGCallsNotToHPLMN-CountryBarred                        | (7)                                         |
| interzonalOGCallsAndInternationalOGCallsNotToHPLMN-CountryBarred | (8)                                         |
| premiumRateInformationOGCallsBarred                              | (3)                                         |
| premiumRateEntertainementOGCallsBarred                           | (4)                                         |
| ss-AccessBarred                                                  | (5)                                         |
| allECT-Barred                                                    | (9)                                         |
| chargeableECT-Barred                                             | (10)                                        |
| internationalECT-Barred                                          | (11)                                        |
| interzonalECT-Barred                                             | (12)                                        |
| doublyChargeableECT-Barred                                       | (13)                                        |
| multipleECT-Barred                                               | (14)                                        |
| allPacketOrientedServicesBarred                                  | (15)                                        |
| roamerAccessToHPLMN-AP-Barred                                    | (16)                                        |
| roamerAccessToVPLMN-AP-Barred                                    | (17)                                        |
| roamingOutsidePLMNOG-CallsBarred                                 | (18)                                        |
| allIC-CallsBarred                                                | (19)                                        |
| roamingOutsidePLMNIC-CallsBarred                                 | (20)                                        |
| roamingOutsidePLMNICountryIC-CallsBarred                         | (21)                                        |
| roamingOutsidePLMN-Barred                                        | (22)                                        |
| roamingOutsidePLMN-CountryBarred                                 | (23)                                        |
| registrationAllCF-Barred                                         | (24)                                        |
| registrationCFNotToHPLMN-Barred                                  | (25)                                        |
| registrationInterzonalCF-Barred                                  | (26)                                        |
| registrationInterzonalCFNotToHPLMN-Barred                        | (27)                                        |
| registrationInternationalCF-Barred                               | (28)                                        |

**Пример**

Установить ограничения на все исходящие вызовы allOG-CallsBarred (0):
```bash
odb_control 101010000001000 1 1 0
Чт июн 18 14:20:36 MSK 2020
{
  "status":"OK"
}
```

## Изменение MSISDN
### ch_msisdn

Позволяет сменить MSISDN существующему абоненту

| Parameter  | Description           | O/M | Version |
|------------|-----------------------|-----|---------|
| IMSI       | IMSI абонента         | С   |         |
| MSISDN     | MSISDN абонента       | C   |         |
| NEW_MSISDN | новый MSISDN абонента | O   |         |

**Пример**
```bash
$ ch_msisdn 101010000001000 1010100124 1010100100
{
  "status": "OK"
}
```
Добавить MSISDN абоненту у которого не привязан MSISDN:
```bash
$ ch_msisdn 101010000001000 1010100100
{
  "status": "OK"
}
```
Удалить MSISDN:
### del_msisdn
```bash
$ del_msisdn 101010000001000
{
  "status": "OK"
}
```
## Изменение режима доступа к сети (NAM, Network Access Mode)
(3GPP TS 23.008):

| Parameter           | Description                                                                               | O/M | Version |
|---------------------|-------------------------------------------------------------------------------------------|-----|---------|
| IMSI                | IMSI абонента                                                                             | С   |         |
| MSISDN              | MSISDN абонента                                                                           | C   |         |
| NAM |возможные значения:<ul><li>2 - только домен CS (non-GPRS/EPS)</li> <li>1 - только домен PS (GPRS/EPS)</li> <li>0 - оба типа сети</li>|  M   |         |

**Пример**

Разрешить абоненту доступ только к VLR:
### ch_nam
```bash
$ ch_nam 101010000001000 2
Чт июн 18 14:48:01 MSK 2020
{
  "status":"OK"
}
```
