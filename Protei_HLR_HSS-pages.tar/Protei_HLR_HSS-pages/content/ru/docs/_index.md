---
title: "Документация"
description: "Protei HLR/HSS"
weight: 2
menu:
    main:
        weight: 15
---

### Актуальные версии продукта:

[Официальное описание на сайте protei.ru](https://protei.ru/products/cs-core/hlr)
[Страница проекта в wiki](https://wiki.protei.ru/doku.php?id=protei:mobile:hlr)