---
title : "Настройка лицензии"
description : ""
weight : 1

---

Функционал, который управляется лицензией:
  * UserLocation - запрос на получение местоположения абонента


Алгоритм генераци лицензии
  1. Запустить LicenceDaemon под рутом
  2. Запустить GenerateLicence с параметром UserLocation
  3. В hlr_ap.properties заполнить
     * licence.key = результат скрипта GenerateLicence
     * licence.param = UserLocation

Все скрипты лежат в /install/Protei_HLR/license/licence
