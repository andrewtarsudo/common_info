---
title : "Получение"
description : "GET: /eps/{id}"
weight : 2
---

# Получение

*  __endpoint: /eps/{id}__
*  __method: GET__

## Запрос

* empty body


## Ответ

* [body](../body)

### Example
```json
{
    "id": 1,
    "serviceSelection":"test.protei.ru",
    "vplmnDynamicAddressAllowed":1,
    "qosClassId":6,
    "allocateRetPriority":4,
    "maxDl":1000,
    "maxUl":1000,
    "pdnType":1,
    "preEmptionCapability":1,
    "preEmptionVulnerability":1
}
```



