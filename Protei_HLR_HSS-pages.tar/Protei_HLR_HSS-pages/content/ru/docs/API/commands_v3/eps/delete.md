---
title : "Удаление"
description : "DELETE: /eps/{id}"
weight : 4
---

# Удаление

*  __endpoint: /eps/{id}__
*  __method: DELETE__

## Запрос

* empty body

## Ответ

* empty body




