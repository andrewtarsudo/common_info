---
title : "Создание"
description : "POST: /eps"
weight : 1
---

*  __endpoint: /eps__
*  __method: POST__

# Создание

## Запрос

* [body](../body)

### Example
```json
{    
    "id":1,
    "serviceSelection":"test.protei.ru",
    "vplmnDynamicAddressAllowed":1,
    "qosClassId":6,
    "allocateRetPriority":4,
    "maxDl":1000,
    "maxUl":1000,
    "pdnType":1,
    "preEmptionCapability":1,
    "preEmptionVulnerability":1
}
```

## Ответ

* [body](../body)

### Example
```json
{
    "id": 1,
    "serviceSelection":"test.protei.ru",
    "vplmnDynamicAddressAllowed":1,
    "qosClassId":6,
    "allocateRetPriority":4,
    "maxDl":1000,
    "maxUl":1000,
    "pdnType":1,
    "preEmptionCapability":1,
    "preEmptionVulnerability":1
}
```

