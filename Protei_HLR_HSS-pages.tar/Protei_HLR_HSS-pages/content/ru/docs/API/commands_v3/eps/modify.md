---
title : "Изменение"
description : "PATCH: /eps/{id} PUT: /eps/{id}"
weight : 3
---

# Частичное изменение

*  __endpoint: /eps/{id}__
*  __method: PATCH__

## Запрос

* [body](../body)

### Example
```json
{
    "serviceSelection":"test.protei.ru",
    "vplmnDynamicAddressAllowed":1,
    "qosClassId":6,
    "allocateRetPriority":4,
    "maxDl":1000,
    "maxUl":1000,
    "pdnType":1,
    "preEmptionCapability":1,
    "preEmptionVulnerability":1
}
```

## Ответ

* [body](../body)

### Example
```json
{
    "id":1,
    "qosClassId":6,
    "allocateRetPriority":4,
    "maxDl":1000,
    "maxUl":1000,
    "preEmptionCapability":1,
    "preEmptionVulnerability":1
}
```

# Полное изменение

*  __endpoint: /eps/{id}__
*  __method: PUT__

## Запрос

* [body](../body)

### Example
```json
{
    "serviceSelection":"test.protei.ru",
    "vplmnDynamicAddressAllowed":1,
    "qosClassId":6,
    "allocateRetPriority":4,
    "maxDl":1000,
    "maxUl":1000,
    "pdnType":1,
    "preEmptionCapability":1,
    "preEmptionVulnerability":1
}
```

## Ответ

* [body](../body)

### Example
```json
{
    "id":1,
    "qosClassId":6,
    "allocateRetPriority":4,
    "maxDl":1000,
    "maxUl":1000,
    "preEmptionCapability":1,
    "preEmptionVulnerability":1
}
```


