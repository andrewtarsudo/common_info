---
title : "Изменение"
description : "PATCH: /qos-gprs/{id} PUT: /qos-gprs/{id}"
weight : 3
---

# Частичное изменение

*  __endpoint: /qos-gprs/{id}__
*  __method: PATCH__

## Запрос

* [body](../body)

### Example
```json
{
  "qosSubscribed":"124214",
  "extQosSubscribed":"035F38",
  "ext2QosSubscribed":"035F3834ACEC"
}
```

## Ответ

* [body](../body)

### Example
```json
{
  "id":1,
  "qosSubscribed":"124214",
  "extQosSubscribed":"035F38",
  "ext2QosSubscribed":"035F3834ACEC"
}
```

# Полное изменение

*  __endpoint: /qos-gprs/{id}__
*  __method: PUT__

## Запрос

* [body](../body)

### Example
```json
{
  "qosSubscribed":"124214",
  "extQosSubscribed":"035F38",
  "ext2QosSubscribed":"035F3834ACEC"
}
```

## Ответ

* [body](../body)

### Example
```json
{
  "id":1,
  "qosSubscribed":"124214",
  "extQosSubscribed":"035F38",
  "ext2QosSubscribed":"035F3834ACEC"
}
```

