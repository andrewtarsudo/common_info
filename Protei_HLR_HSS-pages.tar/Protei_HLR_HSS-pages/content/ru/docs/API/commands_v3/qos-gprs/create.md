---
title : "Создание"
description : "POST: /qos-gprs"
weight : 1
---

*  __endpoint: /qos-gprs__
*  __method: POST__

# Создание

## Запрос

* [body](../body)

### Example
```json
{
    "id":1,
    "qosSubscribed":"124214",
    "extQosSubscribed":"035F38",
    "ext2QosSubscribed":"035F3834ACEC"
}
```

## Ответ

* [body](../body)

### Example
```json
{
    "id":1,
    "qosSubscribed":"124214",
    "extQosSubscribed":"035F38",
    "ext2QosSubscribed":"035F3834ACEC"
}
```

