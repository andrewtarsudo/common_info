---
title : "Удаление"
description : "DELETE: /qos-gprs/{id}"
weight : 4
---

# Удаление

*  __endpoint: /qos-gprs/{id}__
*  __method: DELETE__

## Запрос

* empty body

## Ответ

* empty body



