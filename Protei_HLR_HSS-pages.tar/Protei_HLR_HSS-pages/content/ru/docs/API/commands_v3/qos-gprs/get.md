---
title : "Получение"
description : "GET: /qos-gprs/{id}"
weight : 2
---

# Получение

*  __endpoint: /qos-gprs/{id}__
*  __method: GET__

## Запрос

* empty body

## Ответ

* [body](../body)

### Example
```json
{
  "id":1,
  "qosSubscribed":"124214",
  "extQosSubscribed":"035F38",
  "ext2QosSubscribed":"035F3834ACEC"
}
```



