---
title : "Создание"
description : "POST: /qos-eps"
weight : 1
---

*  __endpoint: /qos-eps__
*  __method: POST__

# Создание

## Запрос

* [body](../body)


### Example
```json
{
    "id":1,
    "qosClassId":6,
    "allocateRetPriority":4,
    "maxDl":1000,
    "maxUl":1000,
    "preEmptionCapability":1,
    "preEmptionVulnerability":1
}
```

## Ответ

* [body](../body)

### Example
```json
{
    "id":1,
    "qosClassId":6,
    "allocateRetPriority":4,
    "maxDl":1000,
    "maxUl":1000,
    "preEmptionCapability":1,
    "preEmptionVulnerability":1
}
```

