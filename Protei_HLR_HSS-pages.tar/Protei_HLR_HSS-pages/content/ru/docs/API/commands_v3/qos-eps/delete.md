---
title : "Удаление"
description : "DELETE: /qos-eps/{id}"
weight : 4
---

# Удаление

*  __endpoint: /qos-eps/{id}__
*  __method: DELETE__

## Запрос

* empty body

## Ответ

* empty body




