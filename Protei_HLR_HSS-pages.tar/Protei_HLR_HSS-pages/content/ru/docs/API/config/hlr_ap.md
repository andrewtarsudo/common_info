---
title : "hlr_ap.properties"
description : "Файл настройки работы приложения"
weight : 4
---


 Name | Description | Type | Value | Default | O/M | P/R | Example
:-----|:-----------------|------|------|---------|-----|-----|-----
hlr.enable | Взаимодействие с HLR Core | boolean |  | true | O | R
hlr.direction | Имя направления, в которое слать omi команды | String | | | O | R | hlr
hlr.list | Список имен соединений, в которое слать omi команды | [String] | | | O | R | hlr1, hlr2
hlr.auth.enabled | Использование авторизации | boolean |  | false | O | R
hlr.auth.system.login | Системный логин | String |  |  | O | R
hlr.licenceKey | Лицензионный ключ | String |  |  | O | P
hlr.licenceParam | Лицензионный параметр | String |  |  | O | P
db.countTryReslveDeadlock | Количество повторов транзакции, если она завершается дедлоком в базе | int |  |  | O | R
