---
title : "profiles.json"
description : "Файл с шаблонами абонентских профилей"
weight : 4
---

[Формат шаблона](../../commands/entities/profiletemplate)

