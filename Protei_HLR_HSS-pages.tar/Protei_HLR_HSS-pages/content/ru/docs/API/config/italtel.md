---
title : "italtel.properties"
description : "Файл настройки работы модуля взаимодействия с italtel"
weight : 4
---


 Name | Description | Type | Value | Default | O/M | P/R | Example
:-----|:-----------------|------|------|---------|-----|-----|-----
httpServer.address | ip адрес платформы italtel | String |  | "0.0.0.0" | O | P
httpServer.port | Порт платформы italtel | int |  | 80 | O | P

