---
title : "Конфигурация"
description : ""
weight : 4

---

#### Используемые стандартные конфигурационные файлы
* [logback.xml](https://wiki.protei.ru/doku.php?id=protei:doc:support:intellectual_services:faq:java_logback)
* [winter.properties (core)](https://wiki.protei.ru/doku.php?id=protei:cpe:winter:core)
* [winter.properties (alarm)](https://wiki.protei.ru/doku.php?id=protei:cpe:winter:alarm)
* [jdbc.xml](https://wiki.protei.ru/doku.php?id=protei:cpe:winter:jdbc)
* [omi.xml](https://wiki.protei.ru/doku.php?id=protei:cpe:winter:omi)

#### Используемые конфигурационные файлы HLR/HSS API
