---
title : "GetGroup"
description : "Получение группы"
weight : 4
---

## endpoint: /ProfileService/GetGroup

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
name | \<String\> | Conditional | Имя группы || TM_SUBSCRIBER_GROUP.STRNAME
id | \<int\> | Conditional | ID группы || TM_SUBSCRIBER_GROUP.NID


### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
group | [\<Group\>](../entities/group) | Mandatory ||| TM_SUBSCRIBER_GROUP


### Example
```json
{
    "name":"gr"
}
```
