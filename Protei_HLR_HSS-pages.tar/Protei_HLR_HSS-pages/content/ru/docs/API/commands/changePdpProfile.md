---
title : "ChangePdpProfile"
description : "Изменение профиля PDP"
weight : 4
---

## endpoint: /ProfileService/ControlPdpProfile

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
action | \<String\> | Mandatory || create/modify/delete | 
pdpProfile | [\<PdpProfile\>](../entities/pdpprofile) | Mandatory ||| TM_PDP_DATA
force | \<Boolean\> | Optional | Принудительное удаление сущности, в случае, если она привязана к абонентскому профилю || 

### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "action":"create",
    "pdpProfile":
    {
        "context-id":1,
        "apn":"test.protei.ru",
        "vplmnAddressAllowed":1,
        "qosSubscribed":"123456",
        "extQosSubscribed":"123456789",
        "pdpChargingCharacteristics":"0800"
    }
}
```



