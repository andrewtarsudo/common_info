---
title : "ChangeGroup"
description : "Изменение группы"
weight : 4
---

## endpoint: /ProfileService/ChangeGroup

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
action | \<String\> | Mandatory || create/modify/delete | 
group | [\<Group\>](../entities/group) | Mandatory ||| TM_SUBSCRIBER_GROUP
force | \<Boolean\> | Optional | Принудительное удаление сущности, в случае, если она привязана к абонентскому профилю || 

### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "action":"create",
    "group":
    {
        "name":"gr",
        "diamRealm":"protei.ru",
        "diamError":5444,
        "gtList":
        [
            {
                "hlrId":1,
                "diamHost":"hss1.protei.ru"
            },
            {
                "hlrId":2,
                "diamHost":"hss2.protei.ru"
            }
        ]
    }
}
```



