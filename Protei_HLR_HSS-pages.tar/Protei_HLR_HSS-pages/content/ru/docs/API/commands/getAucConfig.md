---
title : "GetAucConfig"
description : "Получение параметров AuC"
weight : 4
---

## endpoint: /ProfileService/GetAucConfig

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
op | \<Boolean\> | Optional ||| 
tk | \<Boolean\> | Optional ||| 
c | \<Boolean\> | Optional ||| 
r | \<Boolean\> | Optional ||| 


### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
opParams | [[\<OpParam\>](../entities/opparam)] | Optional ||| TM_OP
tkParams | [[\<TkParam\>](../entities/tkparam)] | Optional ||| TM_TK
cParams | [[\<CParam\>](../entities/cparam)] | Optional ||| TM_AUC_C
rParams | [[\<RParam\>](../entities/rparam)] | Optional ||| TM_AUC_R


### Example
```json
{
    "op":true,
    "tk":true,
    "c":true,
    "r":true
}
```


