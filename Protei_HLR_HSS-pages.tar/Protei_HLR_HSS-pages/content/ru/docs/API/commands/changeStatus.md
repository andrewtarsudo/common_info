---
title : "ChangeStatus"
description : "Изменение статуса абонента"
weight : 4
---

## endpoint: /SubscriberService/ChangeStatus

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
imsi | \<String\> | Conditional | IMSI | | TM_SUBSCRIBER_PROFILE.STRIMSI
msisdn | \<String\>  | Conditional | MSISDN | | TM_SUBSCRIBER_PROFILE.STRMSISDN
status | \<int\> | Mandatory | Статус абонента | 0-(NOT_PROVISIONED), 1-(SUSPENDED), 2-(UNLOCKED), 3-(LOCKED), 4-(TERMINATED) | TM_SUBSCRIBER_PROFILE.NADMINISTRATIVE_STATE


### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "imsi":"250010000001",
    "status":1
}
```


