---
title : "ChangeChargingInformation"
description : "Управление Charging Information"
weight : 4
---

## endpoint: /ProfileService/ControlChargingInformation

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Action | \<String\> | Mandatory | create/modify/delete
ChargingInformation | [\<ChargingInformation\>](../entities/charginginformation) | Mandatory | | | TM_IMS_CHARGING_INFO |
Force | \<Boolean\> | Optional | Принудительное удаление сущности, в случае, если она привязана к абонентскому профилю


### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "Action":"create",
    "ChargingInformation":
    {
        "Name":"ci",
        "PriEcf":"priecf@ims.protei.ru",
        "SecEcf":"sececf@ims.protei.ru",
        "PriCcf":"priccf@ims.protei.ru",
        "SecCcf":"secccf@ims.protei.ru"
    }
}
```


