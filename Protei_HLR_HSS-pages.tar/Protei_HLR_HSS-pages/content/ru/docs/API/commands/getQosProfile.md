---
title : "GetQosProfile"
description : "Получеине профиля QoS"
weight : 4
---

## endpoint: /ProfileService/GetQosProfile

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
action | \<String\> | Mandatory || create/modify/delete | 
qosGprsId | \<int\> | Conditional ||| TM_QOS_GPRS.NID
qosEpsId | \<int\> | Conditional ||| TM_QOS_EPS.NID

### Response

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
qosGprs | [\<QosGprs\>](../entities/qosgprs) | Conditional ||| TM_QOS_GPRS
qosEps | [\<QosEps\>](../entities/qoseps) | Conditional ||| TM_QOS_EPS

### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "qosEpsId":1
}
```




