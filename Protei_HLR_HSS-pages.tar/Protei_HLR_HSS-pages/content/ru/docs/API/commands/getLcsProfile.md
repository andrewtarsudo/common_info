---
title : "GetLcsProfile"
description : "Упарвление профилем LCS"
weight : 4
---

## endpoint: /ProfileService/ChangeLcsProfile

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory | | | TM_ROAMING_LCS_GMLC.NID, TM_ROAMING_LCS_PRIVACY.NID, TM_ROAMING_LCS_MOLR.NID

### Reply
Element/Attribute | Type | Mandatory | Description | DB
:-----|:-----------------|------|------|--------
status | \<int\> | Mandatory | The status of the request | 
lcsProfile | [\<LcsProfile\>](../entities/lcsprofile) | Optional | | 


### Example
```json
{
    "id":1
}
```








