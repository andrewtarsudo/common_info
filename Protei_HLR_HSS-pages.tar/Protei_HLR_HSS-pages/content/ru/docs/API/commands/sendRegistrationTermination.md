---
title : "SendRegistrationTermination"
description : "Отмена регистарции в сетях IMS"
weight : 4
---

## endpoint: /SubscriberService/SendRegistrationTermination

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
impi | \<String\> | Conditional | IMPI | | TM_IMS_PRIVATE_IDENTITY.STRPRIVATE_USER_ID
impu | \<String\>  | Conditional | IMPU | | TM_IMS_PUBLIC_IDENTITY.STR_PUBLIC_IDENTITY

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "impi":"250010000001@ims.protei.ru"
}
```
