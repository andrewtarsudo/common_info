---
title : "GetSifcSet"
description : "Get Shared IFC Set"
weight : 4
---

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Id | \<int\> | Mandatory | |  | TM_IMS_SIFC_SET.NID


### Response

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
status | \<int\> | Mandatory | | | 
SIfcSet | [\<SIfcSet\>](../entities/sifcset) | Optional | | | TM_IMS_SIFC_SET

### Example
```json
{
    "Id":1
}
```


