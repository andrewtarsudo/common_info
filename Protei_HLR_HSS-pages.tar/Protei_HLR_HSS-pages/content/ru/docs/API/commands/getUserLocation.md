---
title : "GetUserLocation"
description : "Получение местоположения абонента"
weight : 4
---

## endpoint: /SubscriberService/GetUserLocation

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
imsi | \<String\> | Conditional | IMSI | | TM_SUBSCRIBER_PROFILE.STRIMSI
msisdn | \<String\>  | Conditional | MSISDN | | TM_SUBSCRIBER_PROFILE.STRMSISDN
imei | \<String\> | Conditional | IMEI | | TM_EIR.STRIMEI
epsUserState | \<Boolean\> | Optional |  | | 
epsLocationInformation | \<Boolean\> | Optional |  | | 
epsCurrentLocation | \<Boolean\> | Optional |  | | 


### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
epsUserState | [\<EpsUserState\>](../entities/epsuserstate) | Optional | 
epsLocationInformation | [\<EpsLocationInformation\>](../entities/epslocationinformation) | Optional | 

### Example
```json
{
    "imsi":"250010000000001",
    "epsUserState":true,
    "epsLocationInformation":true,
    "epsCurrentLocation":true
}
```





