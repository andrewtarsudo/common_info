---
title : "GetChargingInformation"
description : "Получение Charging Information"
weight : 4
---

## endpoint: /ProfileService/GetChargingInformation

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Name | \<String\> | Mandatory | | | TM_IMS_CHARGING_INFO.STNAME


### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
ChargingInformation | [\<ChargingInformation\>](../entities/charginginformation) | Mandatory | | | TM_IMS_CHARGING_INFO |

### Example
```json
{
    "Name":"ci"
}
```



