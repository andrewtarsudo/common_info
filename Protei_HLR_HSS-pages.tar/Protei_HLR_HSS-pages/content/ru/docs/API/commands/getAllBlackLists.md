---
title : "GetAllBlackLists"
description : "Получение всех черных списков"
weight : 4
---

## endpoint: /ProfileService/GetAllBlackLists

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------


### Reply
Element/Attribute | Type | Mandatory | Description | DB
:-----|:-----------------|------|------|--------
status | \<int\> | Mandatory | The status of the request | 
blackList | [\<BalckList\>](../entities/blacklist) | Mandatory | | TM_BLACKLIST_VLR



### Example
```json
{}
```







