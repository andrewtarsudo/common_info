---
title : "GetCapabilitiesSet"
description : "Получение набора возможностей"
weight : 4
---

## endpoint: /ProfileService/GetCapabilitiesSet

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Action | \<String\> | Mandatory | create/modify/delete
SetId | \<int\> | Mandatory | | | TM_IMS_CAPABILITIES_SET.NID_SET |


### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
CapabilitiesSet | [\<CapabilitySet\>](../entities/capabilityset) | Mandatory | | | TM_IMS_CAPABILITIES_SET |

### Example
```json
{
    "SetId":1
}
```


