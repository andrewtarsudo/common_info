---
title : "GetImsSubscription"
description : "Получение IMS подпиской"
weight : 4
---

## endpoint: /ProfileService/GetImsSubscription

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Conditional | 
name | \<String\> | Conditional | 
impi | \<String\> | Conditional | 
impu | \<String\> | Conditional | 
imsi | \<String\> | Conditional | 
msisdn | \<String\> | Conditional | 
full | \<Boolean\> | Optional | 

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
name | \<String\> | Mandatory |
prefferedScscsSetId | \<int\> | Conditional | Если full != true
capabilitySetId | \<int\> | Conditional | Если full != true
chargingInformationName | \<String\> | Conditional | Если full != true
impis | [\<String\>] | Conditional | Если full != true
impus | [\<String\>] | Conditional | Если full != true
implicitlyRegisteredSet | [[\<ImplicitlySet\>](../entities/implicitlyregisteredset)] | Conditional | Если full != true
prefferedScscsSet | [\<PrefferedScscsSet\>](../entities/prefferedscscfset) | Conditional | Если full == true
capabilitySet | [\<CapabilitySet\>](../entities/capabilitiesset) | Conditional | Если full == true
chargingInformation | [\<ChargingInformation\>](../entities/charginginformation) | Conditional | Если full == true
imsProfiles | [[\<ImsProfile\>](../entities/imsprofile)] | Conditional | Если full == true
serviceProfiles | [[\<ServiceProfile\>](../entities/serviceprofile)] | Conditional | Если full == true
sccAsName | \<String\> | Optional |


### Example
```json
{
    "name":"imsu",
    "full":true
}
```

