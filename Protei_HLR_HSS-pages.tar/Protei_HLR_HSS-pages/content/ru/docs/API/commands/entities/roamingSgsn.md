---
title : "RoamingSgsn"
description : "Roaming SGSN"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
sgsn | \<String\> | Optional | Номер SGSN | | TM_ROAMING_SGSN.STRSGSN_NUMBER
sgsnAddress | \<String\> | Optional | Адрес SGSN | | TM_ROAMING_SGSN.STRSGSN_ADDRESS
sgsnAreaRestricted | \<int\> | Optional | Индикатор того, что пользователя запрещено регестрироваться в зоне, в которой он находится | | TM_ROAMING_SGSN.DM_LSGSN_AREARESTRICTED
vGmlc | \<String\> | Optional | Номер GMLC | | TM_ROAMING_SGSN.STRVGMLC
version | \<int\> | Optional | Версия MAP | | TM_ROAMING_SGSN.NVERSION
dtregistered | \<timestamp\> | Optional | Время регистрации абонента | | TM_ROAMING_SGSN.DTREGISTERED
ispurged | \<int\> | Optional | Индикатор того, что абонент был удален из SGSN | | TM_ROAMING_SGSN.LIS_PURGED
dtpurged | \<timestamp\> | Optional | Время удаления абонента из SGSN | | TM_ROAMING_SGSN.DTPURGED
supportedSgsnCamel | \<int\> | Optional | Поддерживаемые фазы Camel | | TM_ROAMING_SGSN.NSUPPORTED_SGSN_CAMEL_PHASES
supportedSgsnLcs | \<int\> | Optional | Поддерживаемые фазы LCS | | TM_ROAMING_SGSN.NSUPPORTED_SGSN_LCS
ueLcsNotSupported | \<int\> | Optional | Индикатор того, что пользователь не поддерживает LCS | | TM_ROAMING_SGSN.NLCS_NOT_SUPPORTED
dmMmeHost | \<String\> | Optional | MME Host | | TM_ROAMING_SGSN.DM_STR_MMEHOST
dmMmeRealm | \<String\> | Optional | MME Realm | | TM_ROAMING_SGSN.DM_STR_MMEREALM
vGmlcMme | \<String\> | Optional | GMLC MME Address | | TM_ROAMING_SGSN.STRMME_VGMLC
dmSgsnHost | \<String\> | Optional | SGSN Host | | TM_ROAMING_SGSN.DM_STR_SGSNHOST
dmSgsnRealm | \<String\> | Optional | SGSN Realm | | TM_ROAMING_SGSN.DM_STR_SGSNREALM
vGmlcSgsn | \<String\> | Optional | GMLC SGSN Address | | TM_ROAMING_SGSN.STRSGSN_VGMLC
is-purged-eps-mme | \<int\> | Optional | Индикатор того, что абонент был удален из MME | | TM_ROAMING_SGSN.DM_LIS_PURGED_MME
dt-purged-eps-mme | \<timestamp\> | Optional | Время удаления абонента из MME | | TM_ROAMING_SGSN.DM_DTPURGED_MME
is-purged-eps-sgsn | \<int\> | Optional | Индикатор того, что абонент был удален из SGSN 4G | | TM_ROAMING_SGSN.DM_LIS_PURGED_SGSN
dt-purged-eps-sgsn | \<timestamp\> | Optional | Время удаления абонента из SGSN 4G | | TM_ROAMING_SGSN.DM_DTPURGED_SGSN
srvccMme | \<int\> | Optional | Поддержка SRVCC на MME | | TM_ROAMING_SGSN.DM_NSRVCC_MME
srvccSgsn | \<int\> | Optional | Поддержка SRVCC на SGSN 4G | | TM_ROAMING_SGSN.DM_NSRVCC_SGSN
voImsMme | \<int\> | Optional | Поддержка VoIMS на MME | | TM_ROAMING_SGSN.DM_NVOIMS_MME
voImsSgsn | \<int\> | Optional | Поддержка VoIMS на SGSN 4G | | TM_ROAMING_SGSN.DM_NVOIMS_SGSN
vplmn | \<String\> | Optional | PLMN сети 4G | | TM_ROAMING_SGSN.DM_STR_VPLMN
sf1Mme | \<int\> | Optional | Список функциональностей, поддерживаемых MME | | TM_ROAMING_SGSN.NMME_SF1
sf2Mme | \<int\> | Optional | Список функциональностей, поддерживаемых MME | | TM_ROAMING_SGSN.NMME_SF2
sf1Sgsn | \<int\> | Optional | Список функциональностей, поддерживаемых SGSN 4G | | TM_ROAMING_SGSN.NSGSN_SF1
sf2Sgsn | \<int\> | Optional | Список функциональностей, поддерживаемых SGSN 4G | | TM_ROAMING_SGSN.NSGSN_SF2
combinedMmeSgsn | \<int\> | Optional | Индикатор того, что абонент зарегестрирован на комбинированном MME/SGSN | | TM_ROAMING_SGSN.NMME_SGSN
supportGprs | \<int\> | Optional | Индикатор того, что MME/SGSN поддерживает GPRS | | TM_ROAMING_SGSN.NSUPPORT_GPRS
