---
title : "UssdCsi"
description : "USSD CSI"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory | ID CSI | | TM_CAMEL_U_CSI.NID
csiActive | \<int\> | Optional | | | TM_CAMEL_U_CSI.NCSIACTIVE
csiCriterias | [[\<UssdCsiCriteria\>](../ussdcsicriteria)] | Optional | | | TM_CAMEL_U_CSI_CRITERIA

### Example
```json
{
    "id":1,
    "csiActive":1,
    "csiCriterias":
    [
        {
            "ussd":"*100#",
            "gsmScfAddress":"32147642342",
            "destinationReference":1
        }
    ]
}
```





