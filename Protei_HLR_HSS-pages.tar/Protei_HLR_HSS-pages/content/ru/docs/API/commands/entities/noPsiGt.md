---
title : "NoPsiGt"
description : "No Psi GT"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
maskVlr | \<String\> | Mandatory | Маска VLR || TM_NOPSIGTMASK.STRVLR_MASK
delete | \<Boolean\> | Optional |  || 


### Example
```json
{
    "maskVlr":"235"
}
```

