---
title : "Permission"
description : "Разрешения пользователей"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
permissions | \<String\> | Mandatory | Список разрешений, задается в формате "ADRW" | A-add, D-delete, R-read, W-write, E-control external entities | TM_APIUSER_PERMISSION.STRPERMISSIONS |
groupId | \<int\> | Conditional | | | TM_APIUSER.NGROUP_ID |
groupName | \<String\> | Conditional | | | TM_APIUSER.NGROUP_ID |
delete | \<Boolean\> | Optional | | |  |

### Response

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
status | \<int\> | Mandatory | | | 

### Example
```json
{
    "permissions":"RW",
    "groupName":"gr1"
}
```


