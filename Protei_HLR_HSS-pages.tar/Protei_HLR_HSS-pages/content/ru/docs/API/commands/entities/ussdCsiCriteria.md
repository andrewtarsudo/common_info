---
title : "UssdCsiCriteria"
description : "USSD CSI Criteria"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ussd | \<String\> | Mandatory | | | TM_CAMEL_U_CSI_CRITERIA.STR_USSD
gsmScfAddress | \<String\> | Mandatory | | | TM_CAMEL_U_CSI_CRITERIA.STRGSM_SCFADDRESS
destinationReference | \<int\> | Mandatory | | | TM_CAMEL_U_CSI_CRITERIA.NDEST_REFERENCE
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "ussd":"*100#",
    "gsmScfAddress":"32147642342",
    "destinationReference":1
}
```

