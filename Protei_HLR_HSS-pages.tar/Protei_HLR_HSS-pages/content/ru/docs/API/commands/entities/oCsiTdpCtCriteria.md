---
title : "OCsiTdpCtCriteria"
description : "O CSI TDP CT Criteria"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
callTypeCriteria | \<int\> | Mandatory | | | TM_CAMEL_O_TDP_CT_CRITERIA.NCALLTYPECRITERIA
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "callTypeCriteria":1
}
```
