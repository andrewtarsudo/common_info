---
title : "Impu"
description : "IMPU"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Identity | \<String\> | Mandatory | Публичный идентификатор пользователя  IMS | | TM_IMS_PUBLIC_IDENTITY.STR_PUBLIC_IDENTITY
Type | \<int\> | Mandatory | | | TM_IMS_PUBLIC_IDENTITY.NTYPE
BarringIndication | \<int\> | Mandatory | Запрет вызова | 0/1 | TM_IMS_PUBLIC_IDENTITY.NBARRING
CanRegister | \<int\> | Optional | Возможность регистрации | 0/1 | TM_IMS_PUBLIC_IDENTITY.NCAN_REGISTER
ServiceProfileName | \<String\> | Optional | Имя сервис-профиля | | TM_IMS_PUBLIC_IDENTITY.STRNAME_SP
WildcardPsi | \<int\> | Optional | Шаблон публичного идентификатора сервиса | | TM_IMS_PUBLIC_IDENTITY.STRWILDCARD_PSI
PsiActivation | \<int\> | Optional | | | TM_IMS_PUBLIC_IDENTITY.NPSI_ACTIVATION
Default | \<int\> | Optional | Индикатор того, что идентификатор является дефолтным в наборе. Используется только при упарвлении набором публичных идетификаторов | | TM_IMS_PUBLIC_IDENTITY.NDEFAULT
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "Identity":"sip:79000000001@ims.protei.ru",
    "BarringIndication":0,
    "Type":0,
    "CanRegister":1,
    "ServiceProfileName":"sp"
}
```