---
title : "SMS Registration Info"
description : "Информация о регистрации на IP-SM-GW"
weight : 4
---


Element/Attribute | Type | Mandatory | DB
:-----------------|:-----|-----------|-------
ipSmGwNumber | \<String\> | Optional | TM_SMS_REGISTRATION.STRIP_SM_GW_NUMBER
ipSmGwHost | \<String\> | Optional | TM_SMS_REGISTRATION.STRIP_SM_GW_HOST
ipSmGwRealm | \<String\> | Optional | TM_SMS_REGISTRATION.STRIP_SM_GW_REALM

### Example
```json
{
    "ipSmGwNumber":"12345789",
    "ipSmGwHost":"ipsmgw.ims.protei.ru",
    "ipSmGwRealm":"ims.protei.ru"
}
```





