---
title : "ChargingInformation"
description : "IMS Charging Information"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Name | \<String\> | Mandatory | Имя профиля | | TM_IMS_CHARGING_INFO.STRNAME
PriEcf | \<String\> | Optional | Primary Event Charging Function Name | | TM_IMS_CHARGING_INFO.STRPRI_ECF
SecEcf | \<String\> | Optional | Secondary Event Charging Function Name | | TM_IMS_CHARGING_INFO.STRSEC_ECF
PriCcf | \<String\> | Optional | Primary Charging Collection Function Name | | TM_IMS_CHARGING_INFO.STRPRI_CCF
SecCcf | \<String\> | Optional | Secondary Charging Collection Function Name | | TM_IMS_CHARGING_INFO.STRSEC_CCF


### Example
```json
{
    "Name":"ci",
    "PriEcf":"priecf@ims.protei.ru",
    "SecEcf":"sececf@ims.protei.ru",
    "PriCcf":"priccf@ims.protei.ru",
    "SecCcf":"secccf@ims.protei.ru"
}
```

