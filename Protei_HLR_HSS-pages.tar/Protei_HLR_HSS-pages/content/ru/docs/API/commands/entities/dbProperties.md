---
title : "DbProperties"
description : "Настройки одключения к базе данных"
weight : 4
---

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
user | \<String\> | Mandatory | 
password | \<String\> | Mandatory | Передается в зашифрованном виде
url | \<String\> | Mandatory | 


### Example
```json
{
    "user":"hlr",
    "password":"bGsnHXypyew=",
    "url":"jdbc:mysql://localhost:3306/HLR"
}
```
