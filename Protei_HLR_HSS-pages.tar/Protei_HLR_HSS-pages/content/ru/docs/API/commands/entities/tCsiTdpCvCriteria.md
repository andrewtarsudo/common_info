---
title : "TCsiTdpCvCriteria"
description : "T CSI TDP  Criteria"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
causeValue | \<int\> | Mandatory | | | TM_CAMEL_T_TDP_CV_CRITERIA.NCAUSEVALUE
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "causeValue":1
}
```
