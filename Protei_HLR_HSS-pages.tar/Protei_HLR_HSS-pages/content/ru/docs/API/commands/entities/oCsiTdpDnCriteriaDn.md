---
title : "OCsiTdpDnCriteriaDn"
description : "O CSI TDP DN Criteria DN"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
destNumber | \<String\> | Mandatory | | | TM_CAMEL_O_TDP_DN_CRITERIA_DN.STRDESTNUMBER
delete | \<Boolean\> | Optional | | | 


### Example
```json
{
    "destNumber":"123456789"
}
```
