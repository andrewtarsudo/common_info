---
title : "PdpData"
description : "PDP Data"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
context-id | \<int\> | Conditional | ID PDP-контекста (Должно используется при создании абонента) | | TM_SUBSCRIBER_PDP.NPDP_CONTEXTID
context-ids | [\<int\>] | Conditional | ID PDP-контекстов (Може использоваться при изменении абонента) | | TM_SUBSCRIBER_PDP.NPDP_CONTEXTID
type | \<String\> | Mandatory | Тип PDP | | TM_SUBSCRIBER_PDP.STRPDP_TYPE
address | \<String\> | Optional | Адрес для привязки контекста | | TM_SUBSCRIBER_PDP.STRPDP_ADDRESS
delete | \<Boolean\> | Optional | | | 


### Example
```json
{
    "context-id":1,
    "type":"f121",
    "address":"192.168.1.22"
}
```
