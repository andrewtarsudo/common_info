---
title : "RoamingScscf"
description : "Roaming S-CSCF"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
scscfName | \<String\> | Mandatory | Имя S-CSCF | | TM_IMS_ROAMING_SCSCF.STRSCSCF_NAME
host | \<String\> | Optional | Diameter Host S-CSCF | | TM_IMS_ROAMING_SCSCF.STR_HOST
realm | \<String\> | Optional | Diameter Realm S-CSCF | | TM_IMS_ROAMING_SCSCF.STR_REALM
state | \<int\> | Optional | Состояние регистрации | | TM_IMS_ROAMING_SCSCF.NSTATE
reassignmentPendingFlag | \<int\> | Optional | Флаг переназначения S-CSCF | | TM_IMS_ROAMING_SCSCF.NREASSIG_FLAG
sf1  | \<int\> | Optional | Поддерживаемые функцинальности | | TM_IMS_ROAMING_SCSCF.NSF1
dtRegistered | \<timestamp\> | Optional | Время регистрации абонента | | TM_IMS_ROAMING_SCSCF.DTREGISTERED

### Example
```json
{
    "scscfName":"scscf",
    "host":"scscf.ims.protei.ru",
    "realm":"ims.protei.ru",
    "state":1
}
```

