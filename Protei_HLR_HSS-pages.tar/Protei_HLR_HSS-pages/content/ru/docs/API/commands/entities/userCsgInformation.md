---
title : "UserCsgInformation"
description : "User Csg Information"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
csgId | \<int\> | Optional |  | |
csgAccessMode | \<int\> | Optional |  | |
csgMembershipIndication | \<int\> | Optional |  | |


### Example
```json
{

    "csgId":1,
    "csgAccessMode":2,
    "csgMembershipIndication":3
}
```




