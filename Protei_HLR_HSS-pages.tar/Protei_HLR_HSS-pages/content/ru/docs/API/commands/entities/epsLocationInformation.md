---
title : "EpsLocationInformation"
description : "Местоположение абонента по EPS домену"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
mmeLocationInformation | [\<MmeLocationInformation\>](../mmelocationinformation) | Optional |  | | 
sgsnLocationInformation | [\<SgsnLocationInformation\>](../sgsnlocationinformation)  | Optional |  | | 


### Example
```json
{
    "mmeLocationInformation":
    {
        "ageOfLocationInformation":1,
        "eUtranCellGlobalIdentity": "00f1102b2d1010",
        "trackingAreaIdentity": "00f1100001"
    }
}
```

