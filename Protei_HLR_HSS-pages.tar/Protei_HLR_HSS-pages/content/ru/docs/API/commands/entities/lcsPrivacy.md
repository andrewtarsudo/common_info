---
title : "LcsPrivacy"
description : "LCS Privacy"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ssCode | \<int\> | Mandatory | | | TM_ROAMING_LCS_PRIVACY.NSS_CODE
ssStatus | \<int\> | Mandatory | | | TM_ROAMING_LCS_PRIVACY.NSS_STATUS
notificationToMsUser | \<int\> | Optional | | | TM_ROAMING_LCS_PRIVACY.NNOTIFICATIONTOMSUSER
ecList | [[\<LcsPrivacyEc\>](../lcsprivacyec)] | Optional | | | TM_ROAMING_LCS_PRIVACY_EC
plmnList | [[\<LcsPrivacyPlmn\>](../lcsprivacyplmn)] | Optional | | | TM_ROAMING_LCS_PRIVACY_PLMN
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "ssCode":16,
    "ssStatus":5,
    "notificationToMsUser":1,
    "ecList":
    [
        {
            "gmlcRestriction":0,
            "notificationToMsUser":1,
            "externalAddress":"1245135"
        }
    ],
    "plmnList":
    [
        {
            "clientExternalId":1
        }
    ]
}
```









