---
title : "SsCsiCriteria"
description : "SS CSI Criteria"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ssCode | \<int\> | Mandatory | | | TM_CAMEL_SS_CSI_CRITERIA.NSS_CODE
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "ssCode":16
}
```
