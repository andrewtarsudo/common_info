---
title : "QosEps"
description : "QoS EPS Profile"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
qosClassId | \<int\> | Optional |  | | TM_QOS_EPS.NQOS_CLASS_ID
allocateRetPriority | \<int\> | Optional |  | | TM_QOS_EPS.NALLOC_RET_PRIOR
maxDl | \<int\> | Optional |  | | TM_QOS_EPS.NMAX_DL
maxUl | \<int\> | Optional |  | | TM_QOS_EPS.NMAX_UL
extMaxDl | \<int\> | Optional | | | TM_QOS_EPS.NEXT_MAX_DL
extMaxUl | \<int\> | Optional | | | TM_QOS_EPS.NEXT_MAX_UL
preEmptionCapability | \<int\> | Optional |  | | TM_QOS_EPS.NPRE_EMPTION_CAPABILITY
preEmptionVulnerability | \<int\> | Optional |  | | TM_QOS_EPS.NPRE_EMPTION_VULNERABILITY
name | \<String\> | Optional |  | Имя профиля | TM_QOS_EPS.STRNAME


### Example
```json
{
    "qosClassId":6,
    "allocateRetPriority":4,
    "maxDl":1000,
    "maxUl":1000,
    "preEmptionCapability":1,
    "preEmptionVulnerability":1
}
```



