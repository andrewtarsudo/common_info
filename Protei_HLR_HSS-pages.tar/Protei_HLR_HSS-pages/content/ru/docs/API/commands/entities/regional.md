---
title : "Regional"
description : "Regional"
weight : 4
---

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
name | \<String\> | Mandatory | Имя региона
plmns | [[\<Plmn\>](../plmnzc)] | Optional | Список PLMN
ccndcs | [[\<Ccndc\>](../ccndczc)]  | Optional | Список CCNDC

### Example
```json
{   
    "name":"rus",
    "plmns":
    [
        {
            "plmn":"25001",
            "zoneCodes":
            [
                {
                    "zoneCode":1
                },
                {
                    "zoneCode":2
                }
            ]
        }
    ],
    "ccndcs":
    [
        {
            "ccndc":"7901",
            "zoneCodes":
            [
                {
                    "zoneCode":2
                },
                {
                    "zoneCode":3
                }
            ]
        }
    ]
}
```


