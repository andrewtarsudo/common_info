---
title : "SsBarring"
description : "Ss Barring"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ss_Code | \<int\> | Mandatory | | 144-148,153-155 | TM_PROVISIONED_SS.NSS_CODE
ss_Status | \<int\> | Mandatory | | | TM_PROVISIONED_SS.NSS_STATUS
tele_service | [\<int\>] | Optional | | 0,16,32,96,112,128,144 | TM_PROVISIONED_SS_BS.NBASICSERVICE, NSERVICETYPE = 1
bearer_service | [\<int\>] | Optional | | | TM_PROVISIONED_SS_BS.NBASICSERVICE, NSERVICETYPE = 0


### Example
```json
{
    "ss_Code":154,
    "ss_Status":5,
    "tele_service":[0,16,32]
}
```