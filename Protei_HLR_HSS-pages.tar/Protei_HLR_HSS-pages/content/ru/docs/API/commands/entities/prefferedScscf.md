---
title : "PrefferedScscf"
description : "Preffered S-CSCF"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ScscfName | \<String\> | Mandatory | Имя S-CSCF | | TM_IMS_PREFFERED_SCSCF.STR_SCSCF_NAME
Priority | \<int\> | Mandatory | Приоритет | | TM_IMS_PREFFERED_SCSCF.NPRIORITY
Delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "ScscfName":"scscf1",
    "Priority":1
}
```


