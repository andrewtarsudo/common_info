---
title : "TriggerPoint"
description : "Trigger Point"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ConditionTypeCNF | \<int\> | Mandatory | | | TM_IMS_TRIGGER_POINTS.NCONDITIONAL_TYPE_CNF
Spt | [[\<Spt\>](../spt)] | Mandatory | | | TM_IMS_SERVICE_POINT_TRIGGER

### Example
```json
{
    "ConditionTypeCNF":1,
    "Spt":
    [
        {
            "Group":1,
            "Method":"INVITE",
            "SessionCase":1,
            "ConditionNegated":2,
            "Type":3,
            "RequestUri":"http://ims.protei.ru/spt1",
            "Header":"header",
            "Content":"headerContent",
            "SdpLine":"sdpLine",
            "SdpLineContent":"sdpLineContent",
            "RegistrationType":1
        }  
    ]    
}
```
