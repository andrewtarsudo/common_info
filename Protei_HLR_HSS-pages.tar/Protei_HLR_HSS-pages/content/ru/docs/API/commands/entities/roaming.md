---
title : "Roaming"
description : "Roaming"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
vlr | \<String\> | Optional | Номер VLR | | TM_ROAMING.STRVLR_NUMBER
msc | \<String\> | Optional | Номер MSC | | TM_ROAMING.STRMSC_NUMBER
mscAreaRestricted | \<int\> | Optional | Индикатор того, что пользователя запрещено регестрироваться в зоне, в которой он находится | | TM_ROAMING.LMSC_AREARESTRICTED
vGmlc | \<String\> | Optional | Номер GMLC | | TM_ROAMING.STRVGMLC
supportedVlrCamel | \<int\> | Optional | Поддерживаемые фазы Camel | | TM_ROAMING.NSUPPORTED_VLR_CAMEL_PHASES
supportedVlrLcs | \<int\> | Optional | Поддерживаемые фазы LCS | | TM_ROAMING.NSUPPORTED_VLR_LCS
ueLcsNotSupported | \<int\> | Optional | Индикатор того, что пользователь не поддерживает LCS | | TM_ROAMING.NLCS_NOT_SUPPORTED
version | \<int\> | Optional | Версия MAP | | TM_ROAMING.NVERSION
dtregistered | \<timestamp\> | Optional | Время регистрации абонента | | TM_ROAMING.DTREGISTERED
ispurged | \<int\> | Optional | Индикатор того, что абонент был удален из VLR | | TM_ROAMING.LIS_PURGED
dtpurged | \<timestamp\> | Optional | Время удаления абонента из VLR | | TM_ROAMING.DTPURGED
