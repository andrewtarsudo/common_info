---
title : "SIfcSet"
description : "Set Of Shared Initial Filter Criterias"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Id | \<int\> | Mandatory | | | TM_IMS_SIFC_SET.NID
Ifcs | [[\<Ifc\>](../ifc)] | Mandatory | | | TM_IMS_IFC
Delete | \<Boolean\> | Optional | | | 


### Example
```json
{
    "Id":1,
    "Ifcs":
    [
        {
           "Name":"set1_ifc1",
            "Priority":1,
            "ApplicationServerName":"as",
            "ProfilePartIndicator":1,
            "TriggerPoint":
            {
                "ConditionTypeCNF":1,
                "Spt":
                [
                    {
                        "Group":1,
                        "Method":"INVITE",
                        "SessionCase":1,
                        "ConditionNegated":2,
                        "Type":3,
                        "RequestUri":"http://ims.protei.ru/spt1",
                        "Header":"header",
                        "Content":"headerContent",
                        "SdpLine":"sdpLine",
                        "SdpLineContent":"sdpLineContent",
                        "RegistrationType":1
                    }  
                ]
            } 
        }
    ]
}
```
