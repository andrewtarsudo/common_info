---
title : "ZoneCode"
description : "Zone Code"
weight : 4
---

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
zoneCode | \<int\> | Mandatory | код зоны
delete | \<Boolean\> | Optional | 

### Example
```json
{
    "zoneCode":2
}
```
