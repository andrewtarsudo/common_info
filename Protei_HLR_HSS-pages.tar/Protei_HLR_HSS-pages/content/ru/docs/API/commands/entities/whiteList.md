---
title : "WhiteList"
description : "White List"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
action            | \<String\>    | Mandatory | | {"create","modify","delete"} |    
name              | \<String\>    | Mandatory | | | TM_WHITELIST_VLR.STRNAME
vlr_masks         | [[\<WLVlrMask\>](../wlvlrmask)]    | Optional | | | TM_WHITELIST_VLR_MASK
plmn_masks        | [[\<WLPlmnMask\>](../wlplmnmask)]   | Optional | | | TM_WHITELIST_PLMN_MASK

### Example
```json
{
    "action":"create",
    "name":"whitelist",
    "vlr_mask":
    [
        {
            "mask":"7689",
            "country":"rus",
            "network":"supertelecom"
        }
    ]
}
```

