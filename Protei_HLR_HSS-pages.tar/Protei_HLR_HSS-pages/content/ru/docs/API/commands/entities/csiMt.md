---
title : "MCsiMt"
description : "M CSI MT"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
mmCode | \<int\> | Mandatory | | | TM_CAMEL_M_CSI_MT.NMM_CODE
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "mmCode":2
}
```
