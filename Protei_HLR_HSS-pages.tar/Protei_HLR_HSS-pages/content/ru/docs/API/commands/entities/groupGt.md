---
title : "GroupGt"
description : "Реальный GT HLR/HSS"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
hlrId | \<int\> | Mandatory | Имя группы | | TM_HLR_GT.NHLR_ID
diamHost | \<String\> | Optional | Diameter Host HSS || TM_HLR_GT.STR_HOST
sccpGt | \<String\> | Optional | SCCP GT HLR || TM_HLR_GT.STRSCCP_GT
delete | \<Boolean\> | Optional |  || 


### Example
```json
{
    "hlrId":1,
    "diamHost":"hss1.protei.ru"
}
```
