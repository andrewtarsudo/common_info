---
title : "OCsiTdpDnCriteriaDnl"
description : "O CSI TDP DN Criteria DNL"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
length | \<int\> | Mandatory | | | TM_CAMEL_O_TDP_DN_CRITERIA_DNL.NLENGTH
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "length":9
}
```

