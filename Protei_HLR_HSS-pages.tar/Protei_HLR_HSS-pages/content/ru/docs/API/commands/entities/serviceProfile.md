---
title : "ServiceProfile"
description : "Service Profile"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Name | \<String\> | Mandatory | | | TM_IMS_SERVICE_PROFILES.STRNAME
CoreNetworkServiceAuthorization | \<int\> | Optional | | | TM_IMS_SERVICE_PROFILES.NCN_SERVICE_AUTH
Ifcs | [[\<Ifc\>](../ifc)] | Optional | | | TM_IMS_IFC
SIfcs | [[\<SIfcSet\>](../sifcset)] | Optional | Нужно указать только ID SIfcSetа, который нужно добавил или удалить из ServiceProfile | | TM_IMS_SIFC_SET


### Example
```json
{
    "Name":"sp",
    "CoreNetworkServiceAuthorization":1,
    "Ifcs":
    [
        {
            "Name":"ifc1",
            "Priority":1,
            "ApplicationServerName":"as",
            "ProfilePartIndicator":1,
            "TriggerPoint":
            {
                "ConditionTypeCNF":1,
                "Spt":
                [
                    {
                        "Group":1,
                        "Method":"INVITE",
                        "SessionCase":1,
                        "ConditionNegated":2,
                        "Type":3,
                        "RequestUri":"http://ims.protei.ru/spt1",
                        "Header":"header",
                        "Content":"headerContent",
                        "SdpLine":"sdpLine",
                        "SdpLineContent":"sdpLineContent",
                        "RegistrationType":1
                    }  
                ]
            }
        }
    ],
    "SIfcs":
    [
        {
            "Id":1
        }
    ]
}
```
