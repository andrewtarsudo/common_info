---
title : "Odb"
description : "ODB"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Alias | Values | DB
:-----------------|:-----|-----------|-------------|--------|--------|-------
SubscriberStatus | \<int\> | Optional | Статус абонента | | 0/1 | TM_ODB.NSUBSCRIBERSTATUS
general | \<int\> | Conditional | Все general odb одним числом | general-list | | TM_ODB.NGENERAL
hplmn | \<int\> | Conditional | Все hplmn odb одним числом | hplmn-list | | TM_ODB.NHPLMN
generalSetList | [\<int\>] | Conditional | Список бит, которые нужно задать 1 (Используется только при вводе) | | | TM_ODB.NGENERAL
hplmnSetList | [\<int\>] | Conditional | Список бит, которые нужно задать 1 (Используется только при вводе) | | | TM_ODB.NHPLMN
generalUnsetList | [\<int\>] | Conditional | Список бит, которые нужно задать 0 (Используется только при вводе) | | | TM_ODB.NGENERAL
hplmnUnsetList | [\<int\>] | Conditional | Список бит, которые нужно задать 0 (Используется только при вводе) | | | TM_ODB.NHPLMN
hl-general-list | [\<int\>] | Optional | Список бит со значением 1 (Используется только при выводе) | | | TM_ODB.NGENERAL
hl-hplmn-list | [\<int\>] | Optional | Список бит со значением 1 (Используется только при выводе) | | | TM_ODB.NHPLMN
