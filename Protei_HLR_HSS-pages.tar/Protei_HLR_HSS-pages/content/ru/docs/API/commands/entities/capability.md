---
title : "Capability"
description : "Capability"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Code | \<int\> | Mandatory | Код | | TM_IMS_CAPABILITY.NCODE
Mandatory | \<int\> | Mandatory | Обязательность | | TM_IMS_CAPABILITY.NMANDATORY
Delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "Code":1,
    "Mandatory":1
}
```


