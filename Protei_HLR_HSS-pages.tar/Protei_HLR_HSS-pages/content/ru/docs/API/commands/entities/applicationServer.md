---
title : "ApplicationServer"
description : "Application Server"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ServerName | \<String\> | Mandatory | | | TM_IMS_APPLICATION_SERVER.STRNAME     
DefaultHandling | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NDEF_HANDLING     
ServiceInfo | \<String\> | Optional | | | TM_IMS_APPLICATION_SERVER.STRSERVICE_INFO     
Host | \<String\> | Optional | | | TM_IMS_APPLICATION_SERVER.STR_HOST     
Realm | \<String\> | Optional | | | TM_IMS_APPLICATION_SERVER.STR_REALM     
RepositoryDataSizeLimit | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NREP_DATA_SIZE_LIM     
Udr | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR        
UdrRepositoryData | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_REP_DATA     
UdrImpu | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_IMPU     
UdrImsUserState | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_IMS_USER_STATE     
UdrScscfName | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_SCSCF_NAME     
UdrIfc | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_IFC     
UdrLocation | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_LOCATION     
UdrUserState | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_USER_STATE     
UdrChargingInfo | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_CHARGING_INFO     
UdrMsisdn | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_MSISDN     
UdrPsiActivation | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_PSI_ACTIVATION     
UdrDsai | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_DSAI     
UdrAliasesRepositoryData | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NUDR_ALIASES_REP_DATA     
Pur | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NPUR     
PurRepositoryData | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NPUR_REP_DATA     
PurPsiActivation | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NPUR_PSI_ACTIVATION     
PurDsai | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NPUR_DSAI     
PurAliasesRepositoryData | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NPUR_ALIASES_REP_DATA     
Snr | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NSNR        
SnrRepositoryData | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NSNR_REP_DATA     
SnrImpu | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NSNR_IMPU     
SnrImsUserState | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NSNR_IMS_USER_STATE     
SnrScscfName | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NSNR_SCSCF_NAME     
SnrIfc | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NSNR_IFC     
SnrPsiActivation | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NSNR_PSI_ACTIVATION     
SnrDsai | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NSNR_DSAI     
SnrAliasesRepositoryData | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NSNR_ALIASES_REP_DATA     
IncludeRegisterResponse | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NINCLUDE_REG_RESP     
IncludeRegisterRequest | \<int\> | Optional | | | TM_IMS_APPLICATION_SERVER.NINCLUDE_REG_REQ

### Example
```json
{
    "ServerName":"as",
    "DefaultHandling":1,
    "ServiceInfo":"serviceInfo",
    "Host":"as.ims.protei.ru",
    "Realm":"ims.protei.ru",
    "RepositoryDataSizeLimit":1000,
    "Udr":0,
    "Pur":0,
    "Snr":0,
    "UdrRepositoryData":1,
    "UdrImpu":1,
    "UdrImsUserState":1,
    "UdrScscfName":1,
    "UdrIfc":1,
    "UdrLocation":1,
    "UdrUserState":1, 
    "UdrChargingInfo":1,
    "UdrMsisdn":1,
    "UdrPsiActivation":1,
    "UdrDsai":1,
    "UdrAliasesRepositoryData":1,
    "PurRepositoryData":0, 
    "PurPsiActivation":0,
    "PurDsai":0,
    "PurAliasesRepositoryData":0,
    "SnrRepositoryData":0,
    "SnrImpu":0,
    "SnrImsUserState":0, 
    "SnrScscfName":0,
    "SnrIfc":0,
    "SnrPsiActivation":0,
    "SnrDsai":0,
    "SnrAliasesRepositoryData":0, 
    "IncludeRegisterResponse":1,
    "IncludeRegisterRequest":1
}
```
