---
title : "RegionalZoneCodeLink"
description : "Regional Zone CodeLinke"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
name | \<String\> | Conditional | Имя региона | | TM_REGIONAL.STRNAME
id | \<int\> | Conditional | ID региона | | TM_REGIONAL.NID, TM_SUB_2_REGIONAL.NREGIONAL_ID
delete | \<Boolean\> | Optional | | | 


### Example
```json
{
    "name":"rus",
    "delete":true
}
```
