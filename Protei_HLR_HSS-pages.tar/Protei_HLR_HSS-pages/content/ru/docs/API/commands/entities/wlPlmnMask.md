---
title : "WhiteListPlmnMask"
description : "White List PLMN Mask"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
mask            | \<String\>    | Mandatory | | | TM_WHITELIST_PLMN_MASK.STRMASK
country              | \<String\>    | Mandatory | | | TM_WHITELIST_PLMN_MASK.STRCOUNTRY
network              | \<String\>    | Mandatory | | | TM_WHITELIST_PLMN_MASK.STRNETWORK
action          | \<int\>   | Optioanl  | | 0 - (create/modify), 1 - (delete) | 

### Example
```json
{
    "mask":"25001",
    "country":"rus",
    "network":"supertelecom"
}
```

