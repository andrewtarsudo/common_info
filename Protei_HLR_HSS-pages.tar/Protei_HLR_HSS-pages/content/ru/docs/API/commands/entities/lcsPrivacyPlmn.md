---
title : "LcsPrivacyPlmn"
description : "LCS Privacy PLMN"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
clientExternalId | \<int\> | Mandatory | | | TM_ROAMING_LCS_PRIVACY_PLMN.NCLIENTEXTERNALID
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "clientExternalId":1
}
```










