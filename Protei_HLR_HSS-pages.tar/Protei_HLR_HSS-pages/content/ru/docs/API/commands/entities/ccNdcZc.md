---
title : "CcNdc"
description : "Country code, Network destination code"
weight : 4
---

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
ccndc | \<String\> | Mandatory | CCNDC
zoneCodes | [[\<ZoneCode\>](../zonecode)] | Mandatory | Список кодов зон
delete | \<Boolean\> | Optional | 

### Example
```json
{   
    "ccndc":"7901",
    "zoneCodes":
    [
        {
            "zoneCode":2
        },
        {
            "zoneCode":3
        }
    ]
}
```