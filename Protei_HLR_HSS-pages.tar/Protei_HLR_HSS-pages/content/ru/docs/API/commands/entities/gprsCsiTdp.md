---
title : "GprsCsiTdp"
description : "GPRS CSI TDP"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
tdpId | \<int\> | Mandatory | ID TDP | | TM_CAMEL_GPRS_CSI_TDP.NTDP_ID
serviceKey | \<int\> | Mandatory | | | TM_CAMEL_GPRS_CSI_TDP.NSERVICEKEY
gsmScfAddress | \<String\> | Optional | | | TM_CAMEL_GPRS_CSI_TDP.STRGSMSCF_ADDRESS
defaultHandling | \<int\> | Optional | | | TM_CAMEL_GPRS_CSI_TDP.NDEFAULTCALLHANDLING   
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "tdpId":1,
    "serviceKey":1,
    "gsmScfAddress":"78924813183138",
    "defaultHandling":2
}
```
