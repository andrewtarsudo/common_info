---
title : "ProfileTemplate"
description : "Profile Template"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB     | Version
:-----------------|:-----|-----------|-------------|--------|--------|-----------
Profile_id | \<int\>  | Mandatory | Identifier of profile from config |  |
category | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NCATEGORY 
DefaultForwardingNumber | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRDEFAULTFORWARDINGNUMBER 
DefaultForwardingStatus | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NDEFAULTFORWARDINGSTATUS
Group_ID | \<int\> | Optional | |  | TM_SUBSCRIBER_PROFILE.NGROUPID
deactivatePsi | \<int\> | Optional | |  | TM_SUBSCRIBER_PROFILE.NDEACTIVATEPSI
baocWithoutCamel | \<int\>  | Optional | |  | TM_SUBSCRIBER_PROFILE.NBAOC_WITHOUTCAMEL
qosGprsId | \<int\>  | Optional | id профиля QoS для Gprs | | TM_SUBSCRIBER_PROFILE.NQOS_GPRS_ID
qosEpsId | \<int\>  | Optional | id профиля QoS для Eps | | TM_SUBSCRIBER_PROFILE.NQOS_EPS_ID
roamingNotAllowed | \<int\>  | Optional | запрет роаминга | | TM_SUBSCRIBER_PROFILE.NROAMINGNOTALLOWED 
accessRestrictionData | [\<AccessRestrictionData\>](../accessrestrictiondata) | Optional | Access restrition data | | TM_SUBSCRIBER_PROFILE.NACCESSRESTRICTIONDATA
periodicLauTimer | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NPERIODICLAU_TIMER
periodicRauTauTimer | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NPERIODICRAU_TAU_TIMER
SCA | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRSCA
ueUsageType | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NUE_USAGE_TYPE
HSM_ID | \<int\> | Optional | | | TM_AUC.NHSM_ID
OP_ID | \<int\> | Optional | | | TM_AUC.NOP_ID
TK_ID | \<int\> | Optional | | | TM_AUC.NTK_ID
AucC_ID | \<int\> | Optional | | | TM_AUC.NC_ID
AucR_ID | \<int\> | Optional | | | TM_AUC.NR_ID
amfUmts | \<String\> | Optional | | | TM_AUC.STRAMF_UMTS
amfLte | \<String\> | Optional | | | TM_AUC.STRAMF_LTE
amfIms | \<String\> | Optional | | | TM_AUC.STRAMF_IMS
EPS_DATA | [\<EpsData\>](../epsdata) | Optional | |  | TM_DM_SUBSCRIBER_EPS
LCS_ID | \<int\> | Optional | |  | TM_LCS_SUBSCRIBER.NLCS_ID
PDP_DATA | [[\<PdpData\>](../pdpdata)] | Optional | | | TM_SUBSCRIBER_PDP
EPS_CONTEXTS | [[\<LinkEpsData\>](../linkepsdata)] | Optional | | | TM_DM_SUBSCRIBER_EPS_CONTEXT
O_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 0; NSUB_TYPE = 0;)
T_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 1; NSUB_TYPE = 0;)
SMS_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 2;)
GPRS_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 3;)
M_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 4;)
D_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 5; NSUB_TYPE = 0;)
USSD_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 8;)
O_IM_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 0; NSUB_TYPE = 2;)
VT_IM_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 1; NSUB_TYPE = 3;)
D_IM_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 5; NSUB_TYPE = 2;)
TeleServices | [\<int\>] | Optional | | | TM_TELESERVICE
BearerServices | [\<int\>] | Optional | | | TM_BEARERSERVICE
WL_DATA | [\<int\>] | Optional | | | TM_SUB_2_WL
BL_DATA | [\<int\>] | Optional | | | TM_SUB_2_BL
regionalZoneCodes | [[\<RegionalZoneCodeLink\>](../regionalzonecodelink)] | Optional | | |  | TM_SUB_2_REGIONAL
csi-list | [[\<CsiLink\>](../csilink)] | Optional | | | TM_CAMEL_SUBSCRIBER | 2.0.34.0
Active_SS | [\<int\>] | Optional | Список сервисов, которые будут активны после добавления | | TM_PROVISIONED_SS_DATA, TM_PROVISIONED_SS_FORW, TM_PROVISIONED_SS_CALL_BARR
NotActive_SS | [\<int\>] | Optional | Список сервисов, которые будут неактивны после добавления | | TM_PROVISIONED_SS_DATA, TM_PROVISIONED_SS_FORW, TM_PROVISIONED_SS_CALL_BARR
Forced_SS | [\<int\>] | Optional | Список сервисов, которые будут активны после добавления, но абонент не сможет изменить их статус | | TM_PROVISIONED_SS_DATA, TM_PROVISIONED_SS_FORW, TM_PROVISIONED_SS_CALL_BARR
SS_TeleServices | [\<int\>] | Optional | Телесервисы, относящиеся к Active_SS, NotActive_SS, Forced_SS | | TM_PROVISIONED_SS_DATA, TM_PROVISIONED_SS_FORW, TM_PROVISIONED_SS_CALL_BARR
icsIndicator | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NICS_INDICATOR
Forwarding | [\<SsForw\>](../ssforwarding)  | Optional | |  | TM_PROVISIONED_SS_FORW

### Example
```json
{
    "Profile_id":1,
    "category":10,
    "DefaultForwardingNumber":"867349752",
    "DefaultForwardingStatus":7,
    "EPS_DATA":
    {
        "defContextId":1,
        "ueMaxDl":10000,
        "ueMaxUl":10000
    },
    "EPS_CONTEXTS":
    [
        {
            "context-id":2,
            "ipv4":"192.168.1.22",
            "plmnId":"25001"
        }
    ],
    "PDP_DATA":
    [
        {
            "context-id":1,
            "type":"0080"
        }
    ],
}
```
