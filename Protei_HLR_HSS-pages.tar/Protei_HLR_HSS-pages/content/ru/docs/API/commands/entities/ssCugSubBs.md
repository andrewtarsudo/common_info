---
title : "SsCugSubBs"
description : "Ss CUG Sub BS"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
serviceType | \<int\> | Mandatory | | | TM_PROVISIONED_SS_CUG_SUB_BS.NSERVICETYPE 
basicService | \<String\> | Mandatory | | | TM_PROVISIONED_SS_CUG_SUB_BS.NBASICSERVICE


### Example
```json
{
    "serviceType":1,
    "basicService":16
}
```
