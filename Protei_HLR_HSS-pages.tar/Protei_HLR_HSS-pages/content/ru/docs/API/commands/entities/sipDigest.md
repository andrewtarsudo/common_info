---
title : "SipDigest"
description : "SIP Digest"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
password | \<String\> | Mandatory | Пароль для SIP Digest | | TM_IMS_DIGEST.STRPASSWORD


### Example
```json
{
   "password":"elephant"
}
```