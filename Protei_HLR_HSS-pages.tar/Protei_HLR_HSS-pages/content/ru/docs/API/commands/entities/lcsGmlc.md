---
title : "LcsGmlc"
description : "LCS GMLC"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
gmlcNumber | \<String\> | Mandatory | | | TM_ROAMING_LCS_GMLC.STRGMLC_NUMBER
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "gmlcNumber":"2364657"
}
```










