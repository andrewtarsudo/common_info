---
title : "LcsProfile"
description : "Профиль LCS"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory | | | TM_ROAMING_LCS_GMLC.NID, TM_ROAMING_LCS_PRIVACY.NID, TM_ROAMING_LCS_MOLR.NID
gmlcList | [[\<LcsGmlc\>](../lcsgmlc)] | Optional | | | TM_ROAMING_LCS_GMLC
privacyList | [[\<LcsPrivacy\>](../lcsprivacy)] | Optional | | | TM_ROAMING_LCS_PRIVACY
molrList | [[\<LcsMolr\>](../lcsmolr)] | Optional | | | TM_ROAMING_LCS_MOLR

### Example
```json
{
    "id":1,
    "gmlcList":
    [
        {
            "gmlcNumber":"2364657"
        }
    ],
    "privacyList":
    [
        {
            "ssCode":16,
            "ssStatus":5,
            "notificationToMsUser":1,
            "ecList":
            [
                {
                    "gmlcRestriction":0,
                    "notificationToMsUser":1,
                    "externalAddress":"1245135"
                }
            ],
            "plmnList":
            [
                 {
                    "clientExternalId":1
                }
            ]
        }
    ],
    "molrList":
    [
        {
            "ssCode":15,
            "ssStatus":2
        }
    ]
}
```








