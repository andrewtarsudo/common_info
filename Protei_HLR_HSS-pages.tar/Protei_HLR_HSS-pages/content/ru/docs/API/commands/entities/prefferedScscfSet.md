---
title : "PrefferedScscfSet"
description : "Preffered S-CSCF Set"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
SetId | \<int\> | Mandatory | ID набора | | TM_IMS_PREFFERED_SCSCF_SET.NID_SET
Scscfs | [[\<PrefferedScscf\>](../prefferedscscf)] | Mandatory | Список S-CSCF | | TM_IMS_PREFFERED_SCSCF

### Example
```json
{
    "SetId":1,
    "Scscfs":
    [
        {
            "ScscfName":"scscf1",
            "Priority":1
        }
    ]
}
```

