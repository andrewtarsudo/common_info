---
title : "SsCugSub"
description : "Ss CUG Sub"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
index | \<int\> | Mandatory | | | TM_PROVISIONED_SS_CUG_SUB.NINDEX
interLock | \<String\> | Mandatory | | | TM_PROVISIONED_SS_CUG_SUB.STRINTERLOCK
intraOption | \<int\> | Optional | | | TM_PROVISIONED_SS_CUG_SUB.NINTRAOPTION
basicServiceList | [[\<ssCugSubBs\>](../sscugsubbs)] | Optional | | | TM_PROVISIONED_SS_CUG_SUB_BS


### Example
```json
{
    "index":1,
    "interLock":"00001fa5",
    "intraOption":1,
    "basicServiceList":
    [
        {
            "serviceType":1,
            "basicService":16
        },
        {
            "serviceType":1,
            "basicService":31
        }
    ]
}
```
