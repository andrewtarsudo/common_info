---
title : "SgsnLocationInformation"
description : "Местоположение абонента c SGSN"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ageOfLocationInformation | \<int\> | Optional |  | |
currentLocationRetrieved | \<int\> | Optional |  | |
cellGlobalIdentity | \<String\> | Optional |  | | 
geodeticInformation | \<String\> | Optional |  | |
geographicalInformation | \<String\> | Optional |  | |
locationAreaIdentity | \<String\> | Optional |  | |
routingAreaIdentity | \<String\> | Optional |  | |
serviceAreaIdentity | \<String\> | Optional |  | |
userCsgInformation | [\<UserCsgInformation\>](../usercsginformation) | Optional |  | |


### Example
```json
{

    "ageOfLocationInformation":1,
    "cellGlobalIdentity":"00f1102b2d1010",
    "routingAreaIdentity":"00f1100001"
}
```



