---
title : "EmptySubscriber"
description : "Пустой профиль абонента"
weight : 4
---

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
imsi | \<String\> | Mandatory | IMSI
msisdn | \<String\>  | Mandatory | MSISDN
smsc | \<String\>  | Mandatory | SMS number
teleServices | \<String\> | Mandatory | list of TeleserviceCode (format "1,2,3,4")

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "imsi":"250010000001",
    "msisdn":"79000000001",
    "smsc":"1234567890",
    "teleServices":"16,17,21,22"
}
```

