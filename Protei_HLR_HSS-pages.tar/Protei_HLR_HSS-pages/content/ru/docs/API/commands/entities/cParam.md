---
title : "CParam"
description : "Параметр C"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory ||| TM_AUC_C.NID
c | \<String\> | Optional ||| TM_AUC_C.STRAUC_C
delete | \<Boolean\> | Optional ||| 
force | \<Boolean\> | Optional | Принудительное удаление сущности, в случае, если она привязана к абонентскому профилю | | 

### Example
```json
{
    "id":1,
    "с":"123456789009"
}
```

