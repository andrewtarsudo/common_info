---
title : "PdpProfile"
description : "PDP Profile"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
context-id                  | \<int\>    | Mandatory | | | TM_PDP_DATA.NPDP_CONTEXTID
qosSubscribed               | \<String\> | Optional  | | | TM_PDP_DATA.STRQOS_SUBSCRIBED
address                     | \<String\> | Optional  |  Используется только в команде getProfile | | TM_SUBSCRIBER_PDP.STRPDP_ADDRESS 
type                        | \<String\> | Optional  |  Используется только в команде getProfile | | TM_SUBSCRIBER_PDP.STRPDP_TYPE
vplmnAddressAllowed         | \<int\>    | Optional  | | | TM_PDP_DATA.LVPLMN_ADDRESSALLOWED
apn                         | \<String\> | Optional  | | | TM_PDP_DATA.STRAPN
extQosSubscribed            | \<String\> | Optional  | | | TM_PDP_DATA.STREXT_QOS_SUBSCRIBED
pdpChargingCharacteristics  | \<String\> | Optional  | | | TM_PDP_DATA.STRPDP_CHARGINGCHARACTERISTICS
extPdpAddress               | \<String\> | Optional  | | | TM_PDP_DATA.DM_STR_EXTPDP_ADDRESS
extPdpType                  | \<String\> | Optional  | | | TM_PDP_DATA.DM_STR_EXTPDP_TYPE
ext2QosSubscribed           | \<String\> | Optional  | | | TM_PDP_DATA.STREXT2_QOS_SUBSCRIBED 
ext3QosSubscribed           | \<String\> | Optional  | | | TM_PDP_DATA.STREXT3_QOS_SUBSCRIBED
ext4QosSubscribed           | \<String\> | Optional  | | | TM_PDP_DATA.STREXT4_QOS_SUBSCRIBED


### Example
```json
{
    "context-id":1,
    "qosSubscribed":"apn.replace.protei.ru",
    "vplmnAddressAllowed":1,
    "apn":"internet.protei.ru",
    "extQosSubscribed":"035F38",
    "pdpChargingCharacteristics":"0800",
    "ext2QosSubscribed":"035F3834ACEC"
}
```
