---
title : "AccessRestrictionData"
description : "Access Restriction Data"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
utranNotAllowed | \<int\> | Optional | | 0/1 | 
geranNotAllowed | \<int\> | Optional | | 0/1 | 
ganNotAllowed | \<int\> | Optional | | 0/1 | 
iHspaEvolutionNotAllowed | \<int\> | Optional | | 0/1 | 
wbEUtranNotAllowed | \<int\> | Optional | | 0/1 | 
hoToNon3GPPAccessNotAllowed | \<int\> | Optional | | 0/1 | 
nbIotNotAllowed | \<int\> | Optional | | 0/1 | 
enhancedCoverageNotAllowed | \<int\> | Optional | | 0/1 | 
nrSecondaryRatEutranNotAllowed | \<int\> | Optional | | 0/1 | 
unlicensedSpectrumSecondaryRatNotAllowed | \<int\> | Optional | | 0/1 | 
nr5gsNotAllowed | \<int\> | Optional | | 0/1 | 


### Example
```json
{
    "utranNotAllowed":1,
    "geranNotAllowed":1,
    "ganNotAllowed":1,
    "iHspaEvolutionNotAllowed":1,
    "wbEUtranNotAllowed":1,
    "hoToNon3GPPAccessNotAllowed":1,
    "nbIotNotAllowed":1,
    "enhancedCoverageNotAllowed":1,
    "nrSecondaryRatEutranNotAllowed":1,
    "unlicensedSpectrumSecondaryRatNotAllowed":1,
    "nr5gsNotAllowed":1
}
```
