---
title : "SsForwarding"
description : "Ss Forwarding"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ss_Code | \<int\> | Mandatory | | 32,33,41-44 | TM_PROVISIONED_SS.NSS_CODE
ss_Status | \<int\> | Mandatory | | | TM_PROVISIONED_SS.NSS_STATUS
forwardedToNumber | \<String\> | Optional | | Номер переадресации | TM_PROVISIONED_SS.STRFORWARDNUMBER
forwardSubAddress | \<String\> | Optional | | Адрес переадресации | TM_PROVISIONED_SS.NSUBSCRIPTIONOPTION
longforwardedToNumber | \<String\> | Optional | | Длинный номер переадресации | TM_PROVISIONED_SS.NIMS_SUBSCRIPTIONOPTION
forwardingOptions | \<int\> | Optional | | Опции переадресации | TM_PROVISIONED_SS.NTYPE
noReplyConditionTime | \<int\> | Optional | | Флаг, показывающий, есть ли условие времени ответа | TM_PROVISIONED_SS.NSUBSCRIPTIONOPTION
tele_service | [\<int\>] | Optional | | 0,16,32,96,112,128,144 | TM_PROVISIONED_SS_BS.NBASICSERVICE, NSERVICETYPE = 1
bearer_service | [\<int\>] | Optional | | | TM_PROVISIONED_SS_BS.NBASICSERVICE, NSERVICETYPE = 0


### Example
```json
{
    "ss_Code":42,
    "ss_Status":7,
    "forwardedToNumber":"42513466754",
    "tele_service":[0,16,32]
}
```
