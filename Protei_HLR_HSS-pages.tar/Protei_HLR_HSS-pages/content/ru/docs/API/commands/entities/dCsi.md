---
title : "DCsi"
description : "D CSI"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory | ID CSI | | TM_CAMEL_D_CSI.NID
camelCapabilityHandling | \<int\> | Optional | | | TM_CAMEL_D_CSI.NCAMELCAPABILITYHANDLING
notificationToCse | \<int\> | Optional | | | TM_CAMEL_D_CSI.NNOTIFICATIONTOCSE
csiActive | \<int\> | Optional | | | TM_CAMEL_D_CSI.NCSIACTIVE
csiCriterias | [[\<DCsiCriteria\>](../dcsicriteria)] | Optional | | | TM_CAMEL_D_CSI_CRITERIA


### Example
```json
{
    "id":1,
    "camelCapabilityHandling":3,
    "csiActive":1,
    "csiCriterias":
    [
        {
            "dialledNumber":"111",
            "serviceKey":1,
            "gsmScfAddress":"78924813183138",
            "defaultCallHandling":2
        }
    ]
}
```



