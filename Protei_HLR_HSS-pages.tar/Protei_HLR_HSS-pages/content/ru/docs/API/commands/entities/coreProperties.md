---
title : "CoreProperties"
description : "Функцональности, поддерживаемые на ядре"
weight : 4
---

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
hlr | \<Boolean\> | Mandatory | Поддержка регистрации в сетях 2/3g
hss | \<Boolean\> | Mandatory | Поддержка регистрации в сетях 4g
ims | \<Boolean\> | Mandatory | Поддержка регистрации в сетях ims
lcs | \<Boolean\> | Mandatory | Поддержка функций определения местоположения


### Example
```json
{
    "hlr":true,
    "hss":true,
    "ims":false,
    "lcs":false
}
```

