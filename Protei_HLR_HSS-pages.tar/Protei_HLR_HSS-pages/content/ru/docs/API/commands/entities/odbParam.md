---
title : "OperatorDeterminedBarring"
description : "Operator Determined Barring"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
general-list | [\<int\>] | Optional | Обычные ODB | | TM_ODB.NGENERAL
hplmn-list | [\<int\>] | Optional | Домашние ODB | | TM_ODB.NHPLMN
action | \<int\> | Mandatory | Значение, которое будет подставлено в general-list и hplmn-list в перечисленные биты | 0/1 | 
SubscriberStatus | \<int\> | Optional | Статус абонента | 0/1 | TM_ODB.NSUBSCRIBERSTATUS


### Example
```json
{
    "general-list":[1,6,19],
    "action":1,
    "SubscriberStatus":1
}
```
