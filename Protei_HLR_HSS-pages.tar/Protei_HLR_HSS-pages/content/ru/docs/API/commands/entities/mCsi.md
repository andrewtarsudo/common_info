---
title : "MCsi"
description : "M CSI"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory | ID CSI | | TM_CAMEL_M_CSI.NID
serviceKey | \<int\> | Optional | | | TM_CAMEL_M_CSI.NSERVICEKEY
gsmScfAddress | \<String\> | Optional | | | TM_CAMEL_M_CSI.STRGSMSCF_ADDRESS
notificationToCse | \<int\> | Optional | | | TM_CAMEL_M_CSI.NNOTIFICATIONTOCSE
csiActive | \<int\> | Optional | | | TM_CAMEL_M_CSI.NCSIACTIVE
csiMts | [[\<CsiMt\>](../csimt)] | Optional | | | TM_CAMEL_M_CSI_MT

### Example
```json
{
    "id":1,
    "serviceKey":1,
    "gsmScfAddress":"78924813183138",
    "csiActive":1,
    "csiMts":
    [
        {
            "mmCode":2
        }
    ]
}
```




