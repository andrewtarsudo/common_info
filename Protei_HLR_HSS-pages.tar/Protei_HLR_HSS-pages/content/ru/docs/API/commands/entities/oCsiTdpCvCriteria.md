---
title : "OCsiTdpCvCriteria"
description : "O CSI TDP CV Criteria"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
causeValue | \<int\> | Mandatory | | | TM_CAMEL_O_TDP_CV_CRITERIA.NCAUSEVALUE
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "causeValue":1
}
```
