---
title : "CapabilitiesSet"
description : "Capabilities Set"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
SetId | \<int\> | Mandatory | ID набора | | TM_IMS_CAPABILITIES_SET.NID_SET
Capabilities | [[\<Capability\>](../capability)] | Mandatory | Список возможностей | | TM_IMS_CAPABILITY

### Example
```json
{
    "SetId":1,
    "Capabilities":
    [
        {
            "Code":1,
            "Mandatory":1
        },
        {
            "Code":2,
            "Mandatory":0
        }
    ]
}
```


