---
title : "MmeLocationInformation"
description : "Местоположение абонента c MME"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ageOfLocationInformation | \<int\> | Optional |  | |
currentLocationRetrieved | \<int\> | Optional |  | |
eUtranCellGlobalIdentity | \<String\> | Optional |  | | 
geodeticInformation | \<String\> | Optional |  | |
geographicalInformation | \<String\> | Optional |  | |
trackingAreaIdentity | \<String\> | Optional |  | |
userCsgInformation | [\<UserCsgInformation\>](../usercsginformation) | Optional |  | |


### Example
```json
{

    "ageOfLocationInformation":1,
    "eUtranCellGlobalIdentity":"00f1102b2d1010",
    "trackingAreaIdentity":"00f1100001"
}
```


