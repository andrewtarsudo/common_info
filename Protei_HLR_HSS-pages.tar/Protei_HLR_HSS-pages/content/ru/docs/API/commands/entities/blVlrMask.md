---
title : "BlackListVlrMask"
description : "Black List VLR Mask"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
mask            | \<String\>    | Mandatory | | | TM_BLACKLIST_VLR_MASK.STRMASK
country              | \<String\>    | Mandatory | | | TM_BLACKLIST_VLR_MASK.STRCOUNTRY
network              | \<String\>    | Mandatory | | | TM_BLACKLIST_VLR_MASK.STRNETWORK
action          | \<int\>   | Optioanl  | | 0 - (create/modify), 1 - (delete) | 

### Example
```json
{
    "mask":"7689",
    "country":"rus",
    "network":"supertelecom"
}
```

