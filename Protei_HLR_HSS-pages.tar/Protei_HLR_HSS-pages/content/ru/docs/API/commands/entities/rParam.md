---
title : "RParam"
description : "Параметр R"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory ||| TM_AUC_R.NID
r | \<String\> | Optional ||| TM_AUC_R.STRAUC_R
delete | \<Boolean\> | Optional ||| 
force | \<Boolean\> | Optional | Принудительное удаление сущности, в случае, если она привязана к абонентскому профилю | | 

### Example
```json
{
    "id":1,
    "r":"123456789009"
}
```


