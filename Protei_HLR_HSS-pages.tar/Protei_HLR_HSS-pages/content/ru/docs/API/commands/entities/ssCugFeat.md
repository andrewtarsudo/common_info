---
title : "SsCugFeat"
description : "Ss CUG Feat"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
serviceType | \<int\> | Mandatory | | | TM_PROVISIONED_SS_CUG_FEAT.NSERVICETYPE
basicService | \<int\> | Mandatory | | | TM_PROVISIONED_SS_CUG_FEAT.NBASICSERVICE
cugIndicator | \<int\> | Optional | | | TM_PROVISIONED_SS_CUG_FEAT.NCUG_INDICATOR
interRestriction | \<int\> | Optional | | | TM_PROVISIONED_SS_CUG_FEAT.NINTERRESTRICTION


### Example
```json
{
    "serviceType":1,
    "basicService":16,
    "cugIndicator":1,
    "interRestriction":3
}
```
