---
title : "AucData"
description : "AuC Data"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
opId | \<int\> | Optional | | | TM_AUC.NOP_ID
tkId | \<int\> | Optional | | | TM_AUC.NTK_ID
cId | \<int\> | Optional | | | TM_AUC.NC_ID
rId | \<int\> | Optional | | | TM_AUC.NR_ID
amfUmts | \<String\> | Optional | | | TM_AUC.STRAMF_UMTS
amfLte | \<String\> | Optional | | | TM_AUC.STRAMF_LTE
amfIms | \<String\> | Optional | | | TM_AUC.STRAMF_IMS
resSize | \<int\> | Optional | | | TM_AUC.NRES_SIZE
ckSize | \<int\> | Optional | | | TM_AUC.NCK_SIZE
ikSize | \<int\> | Optional | | | TM_AUC.NIK_SIZE
macSize | \<int\> | Optional | | | TM_AUC.NMAC_SIZE
keccakIterations | \<int\> | Optional | | | TM_AUC.NKECCAK_ITERATIONS

### Example
```json
{
    "opId":1,
    "tkId":1,
    "cId":1,
    "rId":1,
    "amfUmts":"0000",
    "amfUmts":"8000",
    "amfIms":"8001"
}
```
