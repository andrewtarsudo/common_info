---
title : "EpsProfile"
description : "EPS Profile"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
eps_context_id | \<int\> | Mandatory | | | TM_DM_EPS_DATA.NEPS_CONTEXT_ID
service_selection | \<String\> | Optional	| | | TM_DM_EPS_DATA.STRSERVICE_SELECTION
vplmnDynamicAddressAllowed | \<int\> | Optional | | | TM_DM_EPS_DATA.NVPLMN_DYNAMIC_ADDRESS_ALLOWED
qosClassId | \<int\> | Optional |  | | TM_DM_EPS_DATA.NQOS_CLASS_ID
allocateRetPriority | \<int\> | Optional |  | | TM_DM_EPS_DATA.NALLOC_RET_PRIOR
pdnGwType | \<int\> | Optional | | | TM_DM_EPS_DATA.NPDN_GW_TYPE
mip6Ip4 | \<String\> | Optional |  | | TM_DM_EPS_DATA.STRMIP6_IP4
mip6Ip6 | \<String\> | Optional |  | | TM_DM_EPS_DATA.STRMIP6_IP6
mip6AgentHost | \<String\> | Optional |  | | TM_DM_EPS_DATA.STRMIP6_AGENT_HOST
mip6AgentRealm | \<String\> | Optional |  | | TM_DM_EPS_DATA.STRMIP6_AGENT_REALM
visitedNetworkId | \<String\> | Optional |  | | TM_DM_EPS_DATA.STRVISITED_NETWORK_ID
chargingCharacteristics | \<String\> | Optional |  | | TM_DM_EPS_DATA.STR_CHARGING_CHARACTERISTICS
apnOiReplacement | \<String\> | Optional |  | | TM_DM_EPS_DATA.STR_APN_OI_REP
maxDl | \<int\> | Optional |  | | TM_DM_EPS_DATA.NMAX_DL
maxUl | \<int\> | Optional |  | | TM_DM_EPS_DATA.NMAX_UL
extMaxDl | \<int\> | Optional | | | TM_DM_EPS_DATA.NEXT_MAX_DL
extMaxUl | \<int\> | Optional | | | TM_DM_EPS_DATA.NEXT_MAX_UL
pdnType | \<int\> | Optional | | | TM_DM_EPS_DATA.N_PDN_TYPE
preEmptionCapability | \<int\> | Optional |  | | TM_DM_EPS_DATA.NPRE_EMPTION_CAPABILITY
preEmptionVulnerability | \<int\> | Optional |  | | TM_DM_EPS_DATA.NPRE_EMPTION_VULNERABILITY
ip4 | \<String\> | Optional |  Заполняется при выводе результата GetProfile | | TM_DM_SUBSCRIBER_EPS_CONTEXT.STRSTATIC_IP4
ip6 | \<String\> | Optional |  Заполняется при выводе результата GetProfile | | TM_DM_SUBSCRIBER_EPS_CONTEXT.STRSTATIC_IP6
plmnId | \<String\> | Optional |  Заполняется при выводе результата GetProfile | | TM_DM_SUBSCRIBER_EPS_CONTEXT.STRPLMN   


### Example
```json
{
    "eps_context_id":1,
    "service_selection":"test.protei.ru",
    "vplmnDnamicAddressAllowed":1,
    "qosClassId":6,
    "allocateRetPriority":4,
    "maxDl":1000,
    "maxUl":1000,
    "pdnType":1,
    "preEmptionCapability":1,
    "preEmptionVulnerability":1
}
```
