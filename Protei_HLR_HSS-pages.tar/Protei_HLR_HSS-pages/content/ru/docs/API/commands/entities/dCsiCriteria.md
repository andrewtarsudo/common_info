---
title : "DCsiCriteria"
description : "D CSI Criteria"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
dialledNumber | \<String\> | Mandatory | | | TM_CAMEL_D_CSI_CRITERIA.STRDIALLEDNUMBER
serviceKey | \<int\> | Mandatory | | | TM_CAMEL_D_CSI_CRITERIA.NSERVICEKEY
gsmScfAddress | \<String\> | Optional | | | TM_CAMEL_D_CSI_CRITERIA.STRGSMSCF_ADDRESS
defaultHandling | \<int\> | Optional | | | TM_CAMEL_D_CSI_CRITERIA.NDEFAULTCALLHANDLING   
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "dialledNumber":"111",
    "serviceKey":1,
    "gsmScfAddress":"78924813183138",
    "defaultCallHandling":2
}
```
