---
title : "GprsCsi"
description : "GPRS CSI"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory | ID CSI | | TM_CAMEL_GPRS_CSI.NID
camelCapabilityHandling | \<int\> | Optional | | | TM_CAMEL_GPRS_CSI.NCAMELCAPABILITYHANDLING
notificationToCse | \<int\> | Optional | | | TM_CAMEL_GPRS_CSI.NNOTIFICATIONTOCSE
csiActive | \<int\> | Optional | | | TM_CAMEL_GPRS_CSI.NCSIACTIVE
csiTdps | [[\<GprsCsiTdp\>](../gprscsitdp)] | Optional | | | TM_CAMEL_GPRS_CSI_TDP


### Example
```json
{
    "id":1,
    "camelCapabilityHandling":3,
    "csiActive":1,
    "csiTdps":
    [
        {
            "tdpId":1,
            "serviceKey":1,
            "gsmScfAddress":"78924813183138",
            "defaultHandling":2
        }
    ]
}
```



