---
title : "DbConfig"
description : "Конифгурация в БД"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | Default | DB
:-----------------|:-----|-----------|-------------|--------|---------|-------
mwdMaxCount       | \<int\> | Optional  | Максимальное количество MWD (Messages-Waiting-Data) | | 10 | TM_CONFIG.NMWD_MAXCOUNT
maxForward        | \<int\> | Optional  | Максимальное количество переадресаций               | | 0 | TM_CONFIG.NMAX_FORWARD
defaultForwardingOptions | \<int\> | Optional | Опции переадресации по умолчанию | | 0 | TM_CONFIG.NDEFAULTFORWOPTIONS
defaultForwardingType | \<int\> | Optional | Тип переадресации по умолчаию, используется для замены неактивных переадресаций | 0-(CFB, CFNRY), 1-(CFB, CFNRY, CFNRC), 2-(CFNRY)  | 0 | TM_CONFIG.NDEFAULTFORWARDINGTYPE
defaultNoreplyConditionTime | \<int\> | Optional  | Время ожидания ответа по умолчанию | | 0 | TM_CONFIG.NDEFAULTNOREPLYCONDITIONTIME
sqnStart            | \<long\> | Optional  | Начальное значение SQN | \{0; 268435456\} | 0 | TM_CONFIG.NSQN_START
sqnEnd            | \<long\> | Optional  | Конечное значение SQN | \{0; 268435456\} | 268435456 | TM_CONFIG.NSQN_END
sqnStep            | \<int\> | Optional  | Шаг увеличения SQN | | 1 | TM_CONFIG.NSQN_STEP
startIndVlr            | \<int\> | Optional  | Начальное значение идентификатора VLR | \{0;31\} | 0 | TM_CONFIG.NSTARTIND_VLR
endIndVlr            | \<int\> | Optional  | Конечное значение идентификатора VLR | \{0;31\} | 31 | TM_CONFIG.NENDIND_VLR
startIndSgsn            | \<int\> | Optional  | Начальное значение идентификатора SGSN | \{0;31\} | 0 | TM_CONFIG.NSTARTIND_SGSN
endIndSgsn            | \<int\> | Optional  | Конечное значение идентификатора SGSN | \{0;31\} | 31 | TM_CONFIG.NENDIND_SGSN
startIndOther            | \<int\> | Optional  | Начальное значение идентификатора Other | \{0;31\} | 0 | TM_CONFIG.NSTARTIND_OTHER
endIndOther            | \<int\> | Optional  | Конечное значение идентификатора Other | \{0;31\} | 31 | TM_CONFIG.NENDIND_OTHER
roamingAgreement            | \<int\> | Optional  | Поддержка функциональности роаминговых соглашений | 0/1 | 0 | TM_CONFIG.LROAMINGAGREEMENT
activeWhiteList            | \<int\> | Optional  | Поддержка белых списков | 0/1 | 0 | TM_CONFIG.LACTIVEWHITELIST
activeBlackList            | \<int\> | Optional  | Поддержка черных списков | 0/1 | 0 | TM_CONFIG.LACTIVEBLACKLIST
supportOdb            | \<Boolean\> | Optional  | Поддержка ODB | true/false | false | TM_CONFIG.NFEATURES
supportBs            | \<Boolean\> | Optional  | Поддержка BS | true/false | false | TM_CONFIG.NFEATURES
supportTs            | \<Boolean\> | Optional  | Поддержка TS | true/false | false | TM_CONFIG.NFEATURES
supportSsCf            | \<Boolean\> | Optional  | Поддержка SS CF | true/false | false | TM_CONFIG.NFEATURES
supportSsCb            | \<Boolean\> | Optional  | Поддержка SS CB | true/false | false | TM_CONFIG.NFEATURES
supportSs            | \<Boolean\> | Optional  | Поддержка SS | true/false | false | TM_CONFIG.NFEATURES
supportCug            | \<Boolean\> | Optional  | Поддержка CUG | true/false | false | TM_CONFIG.NFEATURES
supportZoneCode            | \<Boolean\> | Optional  | Поддержка ZC | true/false | false | TM_CONFIG.NFEATURES
supportEmlpp            | \<Boolean\> | Optional  | Поддержка EMLPP | true/false | false | TM_CONFIG.NFEATURES
supportVbs            | \<Boolean\> | Optional  | Поддержка VBS | true/false | false | TM_CONFIG.NFEATURES
supportVgcs            | \<Boolean\> | Optional  | Поддержка VGCS | true/false | false | TM_CONFIG.NFEATURES
supportLsa            | \<Boolean\> | Optional  | Поддержка LCS | true/false | false | TM_CONFIG.NFEATURES
supportLcs            | \<Boolean\> | Optional  | Поддержка LCS | true/false | false | TM_CONFIG.NFEATURES
supportMsSs            | \<Boolean\> | Optional  | Поддержка BS SS | true/false | false | TM_CONFIG.NFEATURES
supportPdp            | \<Boolean\> | Optional  | Поддержка PDP | true/false | false | TM_CONFIG.NFEATURES



### Example
```json
{
    "config":
    {
        "mwdMaxCount":1,
        "maxForward":1,
        "sqnStart":1,
        "sqnEnd":1000,
        "sqnStep":1,
        "defaultForwardingOptions":1,
        "defaultForwardingType":1,
        "activeWhiteList":1
    }
}
```

