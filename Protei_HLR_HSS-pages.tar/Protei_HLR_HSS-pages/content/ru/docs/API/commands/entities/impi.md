---
title : "IMPI"
description : "IMS Private Identity"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
impi | \<String\> | Mandatory | |  | TM_IMS_PRIVATE_IDENTITY.STRPRIVATE_USER_ID
delete | \<Boolean\> | Optional | | | 



### Example
```json
{
    "impi":"250010000002@ims.protei.ru"
}
```
