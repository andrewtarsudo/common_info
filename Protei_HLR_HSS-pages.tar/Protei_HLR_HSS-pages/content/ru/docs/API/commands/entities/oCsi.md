---
title : "OCsi"
description : "O CSI"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory | ID CSI | | TM_CAMEL_O_CSI.NID
camelCapabilityHandling | \<int\> | Optional | | | TM_CAMEL_O_CSI.NCAMELCAPABILITYHANDLING
notificationToCse | \<int\> | Optional | | | TM_CAMEL_O_CSI.NNOTIFICATIONTOCSE
csiActive | \<int\> | Optional | | | TM_CAMEL_O_CSI.NCSIACTIVE
csiTdps | [[\<OCsiTdp\>](../ocsitdp)] | Optional | | | TM_CAMEL_O_CSI_TDP


### Example
```json
{
    "id":1,
    "camelCapabilityHandling":3,
    "csiActive":1,
    "csiTdps":
    [
        {
            "tdpId":1,
            "serviceKey":1,
            "gsmScfAddress":"78924813183138",
            "defaultHandling":2
        }
    ]
}
```
