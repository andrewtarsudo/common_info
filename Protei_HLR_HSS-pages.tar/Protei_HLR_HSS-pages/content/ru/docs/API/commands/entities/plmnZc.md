---
title : "Plmn"
description : "Plmn"
weight : 4
---

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
plmn | \<String\> | Mandatory | PLMN
zoneCodes | [[\<ZoneCode\>](../zonecode)] | Mandatory | Список кодов зон
delete | \<Boolean\> | Optional | 

### Example
```json
{   
    "plmn":"25001",
    "zoneCodes":
    [
        {
            "zoneCode":1
        },
        {
            "zoneCode":2
        }
    ]
}
```



