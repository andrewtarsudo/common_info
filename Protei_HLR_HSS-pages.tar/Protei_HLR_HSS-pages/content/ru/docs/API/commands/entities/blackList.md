---
title : "BlackList"
description : "Black List"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
action            | \<String\>    | Mandatory | | {"create","modify","delete"} |    
name              | \<String\>    | Mandatory | | | TM_BLACK_VLR.STRNAME
vlr_masks         | [[\<BLVlrMask\>](../blvlrmask)]    | Optional | | | TM_BLACK_VLR_MASK
plmn_masks        | [[\<BLPlmnMask\>](../blplmnmask)]   | Optional | | | TM_BLACK_PLMN_MASK

### Example
```json
{
    "action":"create",
    "name":"blacklist",
    "vlr_mask":
    [
        {
            "mask":"7689",
            "country":"rus",
            "network":"supertelecom"
        }
    ]
}
```


