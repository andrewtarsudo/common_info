---
title : "EpsData"
description : "EPS Data"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
defContextId | \<int\> | Mandatory | ID EPS-контекста по умолчанию | | TM_DM_SUBSCRIBER_EPS.NDEF_CONTEXT_ID, TM_DM_SUBSCRIBER_EPS_CONTEXT.NEPS_CONTEXT_ID
ueApnOiRep | \<String\> | Optional	| Доменное имя APN OI | | TM_DM_SUBSCRIBER_EPS.STR_UE_APN_OI_REP
ueMaxDl | \<int\> | Optional | Максимальная скорость получения | {1;4294967295} | TM_DM_SUBSCRIBER_EPS.NUE_MAX_DL
ueMaxUl | \<int\> | Optional | Максимальная скорость передачи | {1;4294967295} | TM_DM_SUBSCRIBER_EPS.NUE_MAX_UL
ratType | \<int\> | Optional | Тип радиодоступа | | TM_DM_SUBSCRIBER_EPS.NRAT_TYPE
ratFreqPriorId | \<int\> | Optional | ID приоритетной частоты радиодоступа | | TM_DM_SUBSCRIBER_EPS.NRAT_FREQ_PRIOR_ID
defIpv4 | \<String\> | Optional | ipv4 для привязки контекста по умолчанию | | TM_DM_SUBSCRIBER_EPS_CONTEXT.STRSTATIC_IP4
defIpv6 | \<String\> | Optional | ipv6 для привязки контекста по умолчанию | | TM_DM_SUBSCRIBER_EPS_CONTEXT.STRSTATIC_IP6
extUeMaxDl | \<int\> | Optional | Максимальная скорость получения (for nrSecondaryRAT) | {4294968;4294967295} | TM_DM_SUBSCRIBER_EPS.NEXT_UE_MAX_DL
extUeMaxUl | \<int\> | Optional | Максимальная скорость передачи (for nrSecondaryRAT) | {4294968;4294967295} | TM_DM_SUBSCRIBER_EPS.NEXT_UE_MAX_UL
mpsPriority | \<int\> | Optional |  | {0;3} | TM_DM_SUBSCRIBER_EPS.NMPS_PRIORITY


### Example
```json
{
    "defContextId":1,
    "ueApnOiRep":"apn.replace.protei.ru",
    "ueMaxDl":10000,
    "ueMaxUl":10000,
    "ratType":1004,
    "ratFreqPriorId":6,
    "defIpv4":"192.168.1.22"
}
```
