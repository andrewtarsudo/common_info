---
title : "ImsProfile"
description : "IMS Profile"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
impi | \<String\> | Mandatory | Приватный идентификатор пользователя IMS | | TM_IMS_PRIVATE_IDENTITY.STRPRIVATE_USER_ID
authScheme | \<int\> | Mandatory | Схема аутентификации | 4 - Digest-AKAv1-MD5(MILLENAGE), 5 - SIP Digest, 6 - XOR  | TM_IMS_PRIVATE_IDENTITY.NDEF_AUTH_SCHEME
sipDigest | [\<SipDigest\>](../sipdigest) | Conditional | Обязателен, если authScheme = 5 | | TM_IMS_DIGEST
impus | [[\<Impu\>](../impu)] | Optional | Список публичных идентификаторов пользователя IMS | | TM_IMS_PUBLIC_IDENTITY
implicitlySets | [[\<ImplicitlySet\>](../implicitlyregisteredset)] | Optional | Список наборов публичных идентификаторов пользователя IMS. Указываются только имена наборов. | | TM_IMPLICITLY_REGISTERED_SET
delete | \<Boolean\> | Optional | | |

### Example
```json
{
    "impi":"250010000001@ims.protei.ru",
    "authScheme":5,
    "sipDigest":
    {
       "password":"elephant"
    },
    "impus":
    [
        {
            "Identity":"sip:79000000001@ims.protei.ru",
            "BarringIndication":0,
            "Type":0,
            "CanRegister":1,
            "ServiceProfileName":"sp"
        },
        {
            "Identity":"tel:+79000000001@ims.protei.ru",
            "BarringIndication":0,
            "Type":1,
            "CanRegister":1,
            "WildcardPsi":"tel:+79000000001!.*!",
            "PsiActivation":1,
            "ServiceProfileName":"sp"
        }
    ],
    "implicitlySets":
    [
        {
            "name":"implSet1"
        }
    ]
}
```
