---
title : "LocationInformation"
description : "Местоположение абонента c VLR"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ageOfLocationInformation | \<int\> | Optional |  | |
cellGlobalIdOrServiceAreaIdOrLAI | \<String\> | Optional |  | |
mscNumber | \<String\> | Optional |  | | 
locationInformationEps | [\<MmeLocationInformation\>](../mmelocationinformation) / [\<SgsnLocationInformation\>](../sgsnlocationinformation) | Optional |  | | 



### Example
```json
{

    "ageOfLocationInformation":1,
    "cellGlobalIdOrServiceAreaIdOrLAI":"00f1102b2d1010",
    "mscNumber":"97572782157",
    "locationInformationEps":
    {
        "ageOfLocationInformation":1,
        "eUtranCellGlobalIdentity":"00f1168b2d1234",
        "trackingAreaIdentity":"00f1100001"
    }
}
```




