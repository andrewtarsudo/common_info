---
title : "ServiceTriggerPoint"
description : "Service Trigger Point"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ConditionNegated | \<int\> | Optional | | | TM_IMS_SERVICE_POINT_TRIGGER.NCONDITION_NEGATED 
Group | \<int\> | Optional | | | TM_IMS_SERVICE_POINT_TRIGGER.NGROUPE
Type | \<int\> | Optional | | | TM_IMS_SERVICE_POINT_TRIGGER.NTYPE
RequestUri | \<String\> | Optional | | | TM_IMS_SERVICE_POINT_TRIGGER.STRREQ_URI
Method   | \<String\> | Optional | | | TM_IMS_SERVICE_POINT_TRIGGER.STRMETHOD
Header | \<String\> | Optional | | | TM_IMS_SERVICE_POINT_TRIGGER.STRHEADER
Content | \<String\> | Optional | | | TM_IMS_SERVICE_POINT_TRIGGER.STRHEADER_CONTENT
SessionCase | \<int\> | Optional | | | TM_IMS_SERVICE_POINT_TRIGGER.NSESSION_CASE
SdpLine | \<String\> | Optional | | | TM_IMS_SERVICE_POINT_TRIGGER.STRSDP_LINE
SdpLineContent | \<String\> | Optional | | | TM_IMS_SERVICE_POINT_TRIGGER.STRSDP_LINE_CONTENT
RegistrationType | \<int\> | Optional | | | TM_IMS_SERVICE_POINT_TRIGGER.NREGISTRATION_TYPE
Delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "Group":1,
    "Method":"INVITE",
    "SessionCase":1,
    "ConditionNegated":2,
    "Type":3,
    "RequestUri":"http://ims.protei.ru/spt1",
    "Header":"header",
    "Content":"headerContent",
    "SdpLine":"sdpLine",
    "SdpLineContent":"sdpLineContent",
    "RegistrationType":1
}
```
