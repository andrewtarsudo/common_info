---
title : "QosGprs"
description : "QoS GPRS Profile"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
qosSubscribed               | \<String\> | Optional  | | | TM_QOS_PDP.STRQOS_SUBSCRIBED
extQosSubscribed            | \<String\> | Optional  | | | TM_QOS_PDP.STREXT_QOS_SUBSCRIBED
ext2QosSubscribed           | \<String\> | Optional  | | | TM_QOS_PDP.STREXT2_QOS_SUBSCRIBED 
ext3QosSubscribed           | \<String\> | Optional  | | | TM_QOS_PDP.STREXT3_QOS_SUBSCRIBED
ext4QosSubscribed           | \<String\> | Optional  | | | TM_QOS_PDP.STREXT4_QOS_SUBSCRIBED
name | \<String\> | Optional |  | Имя профиля | TM_QOS_EPS.STRNAME



### Example
```json
{
    "qosSubscribed":"124214",
    "extQosSubscribed":"035F38",
    "ext2QosSubscribed":"035F3834ACEC"
}
```

