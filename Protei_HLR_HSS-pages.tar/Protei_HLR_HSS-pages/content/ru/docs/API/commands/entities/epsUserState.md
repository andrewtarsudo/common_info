---
title : "EpsUserState"
description : "Статус абонента в EPS домене"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
mmeUserState | \<int\> | Optional |  | | 
sgsnUserState | \<int\>  | Optional |  | | 


### Example
```json
{
    "mmeUserState":1
}
```
