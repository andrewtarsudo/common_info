---
title : "OCsiTdpDnCriteria"
description : "O CSI TDP DN Criteria"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
matchType | \<int\> | Mandatory | | | TM_CAMEL_O_TDP_DN_CRITERIA.NMATCHTYPE
csiTdpDnCriteriaDns | [[\<OCsiTdpDnCriteriaDn\>](../ocsitdpdncriteriadn)] | Optional | | | TM_CAMEL_O_TDP_DN_CRITERIA_DN
csiTdpDnCriteriaDnls | [[\<OCsiTdpDnCriteriaDnl\>](../ocsitdpdncriteriadnl)] | Optional | | | TM_CAMEL_O_TDP_DN_CRITERIA_DNL

#### \<OCsiTdpDnCriteriaDn\>
Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
destNumber | \<String\> | Mandatory | | | TM_CAMEL_O_TDP_DN_CRITERIA_DN.STRDESTNUMBER
delete | \<Boolean\> | Optional | | | 

#### \<OCsiTdpDnCriteriaDnl\>
Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
length | \<int\> | Mandatory | | | TM_CAMEL_O_TDP_DN_CRITERIA_DNL.NLENGTH
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "matchType":1,
    "csiTdpDnCriteriaDns":
    [
        {
            "destNumber":"123456789"
        }
    ],
    "csiTdpDnCriteriaDnls":
    [
        {
            "length":9
        }
    ]
}
```
