---
title : "LcsMolr"
description : "LCS MOLR"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ssCode | \<int\> | Mandatory | | | TM_ROAMING_LCS_MOLR.NSS_CODE
ssStatus | \<int\> | Mandatory | | | TM_ROAMING_LCS_MOLR.NSS_STATUS
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "ssCode":15,
    "ssStatus":2
}
```









