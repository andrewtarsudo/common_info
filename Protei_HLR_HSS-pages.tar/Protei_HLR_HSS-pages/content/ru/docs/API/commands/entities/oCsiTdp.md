---
title : "OCsiTdp"
description : "O CSI TDP"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
tdpId | \<int\> | Mandatory | ID TDP | | TM_CAMEL_O_CSI_TDP.NTDP_ID
serviceKey | \<int\> | Mandatory | | | TM_CAMEL_O_CSI_TDP.NSERVICEKEY
gsmScfAddress | \<String\> | Optional | | | TM_CAMEL_O_CSI_TDP.STRGSMSCF_ADDRESS
defaultHandling | \<int\> | Optional | | | TM_CAMEL_O_CSI_TDP.NDEFAULTCALLHANDLING
csiTdpDnCriterias | [[\<OCsiTdpDnCriteria\>](../ocsitdpdncriteria)] | Optional |  | | TM_CAMEL_O_TDP_DN_CRITERIA   
csiTdpBsCriterias | [[\<OCsiTdpBsCriteria\>](../ocsitdpbscriteria)] | Optional |  | | TM_CAMEL_O_TDP_BS_CRITERIA
csiTdpCtCriterias | [[\<OCsiTdpCtCriteria\>](../ocsitdpctcriteria)] | Optional |  | | TM_CAMEL_O_TDP_CT_CRITERIA
csiTdpCvCriterias | [[\<OCsiTdpCvCriteria\>](../ocsitdpcvcriteria)] | Optional |  | | TM_CAMEL_O_TDP_CV_CRITERIA
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "tdpId":1,
    "serviceKey":1,
    "gsmScfAddress":"78924813183138",
    "defaultHandling":2
}
```

