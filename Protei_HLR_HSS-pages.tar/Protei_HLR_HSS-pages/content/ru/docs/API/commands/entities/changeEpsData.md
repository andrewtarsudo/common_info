---
title : "ChangeEpsData"
description : "Change EPS Data"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
data | [\<EpsData\>](../epsdata) | Mandatory | | |
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "data":
    {
        "defContextId":1,
        "ueApnOiRep":"apn.replace.protei.ru",
        "ueMaxDl":10000,
        "ueMaxUl":10000,
        "ratType":1004,
        "ratFreqPriorId":6,
        "defIpv4":"192.168.1.22"
    }
}
```
