---
title : "SmsCsi"
description : "SMS CSI"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory | ID CSI | | TM_CAMEL_SMS_CSI.NID
camelCapabilityHandling | \<int\> | Optional | | | TM_CAMEL_SMS_CSI.NCAMELCAPABILITYHANDLING
notificationToCse | \<int\> | Optional | | | TM_CAMEL_SMS_CSI.NNOTIFICATIONTOCSE
csiActive | \<int\> | Optional | | | TM_CAMEL_SMS_CSI.NCSIACTIVE
csiTdps | [[\<SmsCsiTdp\>](../smscsitdp)] | Optional | | | TM_CAMEL_SMS_CSI_TDP

### Example
```json
{
    "id":1,
    "camelCapabilityHandling":3,
    "csiActive":1,
    "csiTdps":
    [
        {
            "tdpId":1,
            "serviceKey":1,
            "gsmScfAddress":"78924813183138",
            "defaultHandling":2
        }
    ]
}
```


