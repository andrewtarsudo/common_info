---
title : "Ifc"
description : "Initial Filter Criteria"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Name | \<String\> | Mandatory | | | TM_IMS_IFC.STRNAME
Priority | \<int\> | Mandatory | | | TM_IMS_IFC.NPRIORITY
ApplicationServerName | \<String\> | Mandatory | | | TM_IMS_APPLICATION_SERVER.STRNAME
ProfilePartIndicator | \<int\> | Optional | | | TM_IMS_IFC.NPROFILE_PART_IND
TriggerPoint | \<TriggerPoint\>(../triggerpoint) | Optional | | | TM_IMS_TRIGGER_POINTS
ApplicationServer | [\<ApplicationServer\>](../applicationserver) | Optional | Заполняется при выводе результата GetProfile | | TM_IMS_APPLICATION_SERVER
Delete | \<Boolean\> | Optional | | | 


### Example
```json
{
    "Name":"ifc1",
    "Priority":1,
    "ApplicationServerName":"as",
    "ProfilePartIndicator":1,
    "TriggerPoint":
    {
        "ConditionTypeCNF":1,
        "Spt":
        [
            {
                "Group":1,
                "Method":"INVITE",
                "SessionCase":1,
                "ConditionNegated":2,
                "Type":3,
                "RequestUri":"http://ims.protei.ru/spt1",
                "Header":"header",
                "Content":"headerContent",
                "SdpLine":"sdpLine",
                "SdpLineContent":"sdpLineContent",
                "RegistrationType":1
            }  
        ]
    }
}
```
