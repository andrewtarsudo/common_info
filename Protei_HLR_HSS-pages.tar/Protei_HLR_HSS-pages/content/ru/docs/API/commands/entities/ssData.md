---
title : "SsData"
description : "Ss Data"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ss_Code | \<int\> | Mandatory | | 17,18,65,66,81,245 | TM_PROVISIONED_SS.NSS_CODE
ss_Status | \<int\> | Mandatory | | | TM_PROVISIONED_SS.NSS_STATUS
sub_option_type | \<int\> | Optional | Тип характеристика сервиса | (2=cliRestrictionOption/1=overrideCategory) | TM_PROVISIONED_SS.NTYPE
sub_option | \<int\> | Optional | | Характеристика сервиса | TM_PROVISIONED_SS.NSUBSCRIPTIONOPTION
ims_sub_option | \<int\> | Optional | | | TM_PROVISIONED_SS.NIMS_SUBSCRIPTIONOPTION
tele_service | [\<int\>] | Optional | | 0,16,32,96,112,128,144 | TM_PROVISIONED_SS_BS.NBASICSERVICE, NSERVICETYPE = 1
bearer_service | [\<int\>] | Optional | | -1,0,16,32,96,112,128,144 | TM_PROVISIONED_SS_BS.NBASICSERVICE, NSERVICETYPE = 0


### Example
```json
{
    "ss_Code":17,
    "ss_Status":5,
    "sub_option_type":1,
    "sub_option":1,
    "tele_service":[0,16,32]
}
```
