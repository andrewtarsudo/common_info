---
title : "Group"
description : "Абонентская группа"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Optional | ID группы (Генерируется при создании) | | TM_SUBSCRIBER_GROUP.NID
name | \<String\> | Mandatory | Имя группы | | TM_SUBSCRIBER_GROUP.STRNAME
mapGt | \<String\> | Optional | MAP GT HLR | | TM_SUBSCRIBER_GROUP.STRVIRTUAL_GT
diamRealm | \<String\> | Optional | Diameter Realm HSS || TM_SUBSCRIBER_GROUP.STR_REALM
mapError | \<String\> | Optional | Ошибка с которой необходимо завершать UL || TM_SUBSCRIBER_GROUP.NMAP_ERROR
diamError | \<String\> | Optional | Ошибка с которой необходимо завершать UL || TM_SUBSCRIBER_GROUP.NDIAM_ERROR
gtList | [[\<GroupGt\>](../entities/groupgt)] | Optional | Список реальных GT HLR || TM_HLR_GT
noPsiGtList | [[\<NoPsiGt\>](../entities/nopsigt)] | Optional | Список GT, при получение SRI от которых не нужно слать PSI || TM_NOPSIGTMASK

### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "action":"create",
    "group":
    {
        "name":"gr",
        "diamRealm":"protei.ru",
        "diamError":5444,
        "gtList":
        [
            {
                "hlrId":1,
                "diamHost":"hss1.protei.ru"
            },
            {
                "hlrId":2,
                "diamHost":"hss2.protei.ru"
            }
        ]
    }
}
```



