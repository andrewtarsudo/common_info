---
title : "User"
description : "Пользователь сиситемы"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
login | \<String\> | Mandatory | | | TM_APIUSER.STRLOGIN |
password | \<String\> | Mandatory | | | TM_APIUSER.STRPASSWORD |
permissions | [\<Permission\>](../permission) | Optional | | | TM_APIUSER_PERMISSION |

### Response

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
status | \<int\> | Mandatory | | | 

### Example
```json
{
    "login":"alisa",
    "password":"elephant",
    "permissions":
    [
        {
            "permissions":"RW",
            "groupName":"gr1"
        },
        {
            "permissions":"AD",
            "groupName":"gr2"
        }
    ]
}
```

