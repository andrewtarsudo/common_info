---
title : "OpParam"
description : "Параметр OP"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory ||| TM_OP.NID
op | \<String\> | Optional ||| TM_OP.STROP
delete | \<Boolean\> | Optional ||| 
force | \<Boolean\> | Optional | Принудительное удаление сущности, в случае, если она привязана к абонентскому профилю | | 

### Example
```json
{
    "id":1,
    "op":"12345678900987654321123456789009"
}
```
