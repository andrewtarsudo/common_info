---
title : "CsiLink"
description : "CSI Link"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB     | Version 
:-----------------|:-----|-----------|-------------|--------|--------|----------
type-id | \<int\> | Mandatory | ID типа CSI профиля | TypeIds | TM_CAMEL_SUBSCRIBER.NTYPECSI
profile-id | \<int\> | Mandatory | ID CSI профиля | | TM_CAMEL_SUBSCRIBER.NCSI_ID    
preffixGt | \<String\> | Optional | GT для которого будет использоваться данный профиль | | TM_CAMEL_SUBSCRIBER.STRPREFFIX
delete | \<Boolean\> | Optional | При удалении связки с CSI формируется DSD | | | 2.0.34.1 | 

#### TypeIds

ID | Description
:---|:----------
0 | O-CSI
1 | T-CSI
2 | SMS-CSI
3 | GPRS-CSI
4 | M-CSI
5 | D-CSI
6 | TIF-CSI    
7 | SS-CSI
8 | USSD-CSI
9 | O-IM-CSI
10 | VT-IM-CSI
11 | D-IM-CSI


### Example
```json
{
    "type-id":0,
    "profile-id":1,
    "preffixGt":"7900"
}
```
