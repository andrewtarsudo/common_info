---
title : "ImplicitlyRegisteredSet"
description : "Implicitly Registered Set"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
name | \<String\> | Mandatory | Имя набора | | TM_IMPLICITLY_REGISTERED_SET.STRNAME
impus | [[\<Impu\>](../impu)] | Optional | Список публичных идентификаторов пользователя IMS, которые объеденины в набор | | TM_IMS_PUBLIC_IDENTITY
delete | \<Boolean\> | Optional | | | 


### Example
```json
{
    "name":"implicitlyRegisteredSet1",
    "impus":
    [
        {
            "Identity":"simpu1@ims.protei.ru",
            "BarringIndication":0,
            "Type":0,
            "CanRegister":1,
            "ServiceProfileName":"sp"
        },
        {
            "Identity":"simpu2@ims.protei.ru",
            "BarringIndication":0,
            "Type":0,
            "Barring":1,
            "CanRegister":1,
            "ServiceProfileName":"sp"
        }
    ]
}
```

