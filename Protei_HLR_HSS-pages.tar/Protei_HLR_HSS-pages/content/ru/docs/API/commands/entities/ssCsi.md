---
title : "SsCsi"
description : "SS CSI"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory | ID CSI | | TM_CAMEL_SS_CSI.NID
ssNotificationToCse | \<int\> | Optional | | | TM_CAMEL_SS_CSI.NSS_NOTIFICATIONTOCSE
ssCsiActive | \<int\> | Optional | | | TM_CAMEL_SS_CSI.NSS_CSIACTIVE
notificationToCse | \<int\> | Optional | | | TM_CAMEL_SS_CSI.NNOTIFICATIONTOCSE
csiActive | \<int\> | Optional | | | TM_CAMEL_SS_CSI.NCSIACTIVE
gsmScfAddress | \<Stringnt\> | Optional | | | TM_CAMEL_SS_CSI.STRGSMSCF_ADDRESS
csiCriterias | [[\<SsCsiCriteria\>](../sscsicriteria)] | Optional | | | TM_CAMEL_SS_CSI_CRITERIA

### Example
```json
{
    "id":1,
    "camelCapabilityHandling":3,
    "csiActive":1,
    "gsmScfAddress":"78924813183138"
    "csiCriterias":
    [
        {
            "ssCode":16
        }
    ]
}
```




