---
title : "TkParam"
description : "Параметр TK"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
id | \<int\> | Mandatory ||| TM_TK.NID
tk | \<String\> | Optional ||| TM_TK.STRTK
algorithm | \<int\> | Optional || 0 - DES, 1 - AES, 2 - 3DES | TM_TK.NENCALG
delete | \<Boolean\> | Optional ||| 
force | \<Boolean\> | Optional | Принудительное удаление сущности, в случае, если она привязана к абонентскому профилю | | 

### Example
```json
{
    "id":1,
    "tk":"12345678900987654321123456789009",
    "algorithm":0
}
```

