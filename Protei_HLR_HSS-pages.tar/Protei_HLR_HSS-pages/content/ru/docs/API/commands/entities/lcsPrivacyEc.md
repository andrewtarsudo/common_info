---
title : "LcsPrivacyEc"
description : "LCS Privacy EC"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
gmlcRestriction | \<int\> | Optional | | | TM_ROAMING_LCS_PRIVACY_EC.NGMLC_RESTRICTION
notificationToMsUser | \<int\> | Optional | | | TM_ROAMING_LCS_PRIVACY_EC.NNOTIFICATIONTOMSUSER
externalAddress | \<String\> | Mandatory | | | TM_ROAMING_LCS_PRIVACY_EC.STREXTERNALADDRESS
delete | \<Boolean\> | Optional | | | 

### Example
```json
{
    "gmlcRestriction":0,
    "notificationToMsUser":1,
    "externalAddress":"1245135"
}
```










