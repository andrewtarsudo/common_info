---
title : "ImsSubscription"
description : "IMS Subscription"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
name | \<String\> | Mandatory | | | TM_IMS_SUBSCRIPTION.STRNAME
capabilitySetId | \<int\> | Optional | | | TM_IMS_SUBSCRIPTION.NID_CAPABILITY_SET
prefferedScscfSetId | \<int\> | Optional | | | TM_IMS_SUBSCRIPTION.NID_PREFF_SCSCF_SET
chargingInformationName | \<String\> | Optional | | | TM_IMS_SUBSCRIPTION.STRNAME_CHARGING_INFO
sccAsName | \<String\> | Optional | | | TM_IMS_SUBSCRIPTION.STRSCC_AS_NAME
impis | [[\<IMPI\>](../impi)] | Optional | В данной команде указывается только impi | | TM_IMS_PRIVATE_IDENTITY
serviceProfiles | [[\<ServiceProfile\>](../serviceprofile)] | Optional | | | TM_IMS_SERVICE_PROFILES
implicitlyRegisteredSet | [[\<ImplicitlyRegisteredSet\>](../implicitlyregisteredset)] | Optional | | | TM_IMS_PUBLIC_IDENTITY

### Example

```json
{
    "name":"250010000001",
    "capabilitySetId":1,
    "prefferedScscfSetId":1,
    "chargingInformationName":"ci",
    "serviceProfiles":
    [
        {
            "Name":"sp",
            "CoreNetworkServiceAuthorization":1,
            "Ifcs":
            [
                {
                    "Name":"ifc1",
                    "Priority":1,
                    "ApplicationServerName":"as",
                    "ProfilePartIndicator":1,
                    "TriggerPoint":
                    {
                        "ConditionTypeCNF":1,
                        "Spt":
                        [
                            {
                                "Group":1,
                                "Method":"INVITE",
                                "SessionCase":1,
                                "ConditionNegated":2,
                                "Type":3,
                                "RequestUri":"http://ims.protei.ru/spt1",
                                "Header":"header",
                                "Content":"headerContent",
                                "SdpLine":"sdpLine",
                                "SdpLineContent":"sdpLineContent",
                                "RegistrationType":1
                            }  
                        ]
                    }
                }
            ]
        }
    ],
    "implicitlyRegisteredSet":
    [
        {
            "name":"implSet1",
            "impus":
            [
                {
                    "Identity":"sip:protei@ims.protei.ru",
                    "BarringIndication":0,
                    "Type":0,
                    "CanRegister":1,
                    "ServiceProfileName":"sp",
                    "Default":true
                },
                {
                    "Identity":"sip:ntc_protei@ims.protei.ru",
                    "BarringIndication":0,
                    "Type":0,
                    "CanRegister":1,
                    "ServiceProfileName":"sp"
                }
            ]
        }
    ]
}
```
