---
title : "LinkEpsData"
description : "Link Eps Data"
weight : 4
---

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
context-id | \<int\> | Mandatory | ID PDP-контекста | | TM_DM_SUBSCRIBER_EPS_CONTEXT.NEPS_CONTEXT_ID
ipv4 | \<String\> | Optional | ipv4 для привязки контекста | | TM_DM_SUBSCRIBER_EPS_CONTEXT.STRSTATIC_IP4
ipv6 | \<String\> | Optional | ipv6 для привязки контекста | | TM_DM_SUBSCRIBER_EPS_CONTEXT.STRSTATIC_IP6
plmnId | \<String\> | Optional | PLMN для привязки контекста | | TM_DM_SUBSCRIBER_EPS_CONTEXT.STRPLMN_ID
delete | \<Boolean\> | Optional | | | 


### Example
```json
{
    "context-id":2,
    "ipv4":"192.168.1.22",
    "plmnId":"25001"
}
```
