---
title : "TCsiTdpBsCriteria"
description : "T CSI TDP BS Criteria"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
serviceType | \<int\> | Mandatory | | | TM_CAMEL_T_TDP_BS_CRITERIA.NSERVICETYPE
basicService | \<int\> | Mandatory | | | TM_CAMEL_T_TDP_BS_CRITERIA.NBASICSERVICE
delete | \<Boolean\> | Optional | | | 


### Example
```json
{
    "serviceType":1,
    "basiService":16
}
```