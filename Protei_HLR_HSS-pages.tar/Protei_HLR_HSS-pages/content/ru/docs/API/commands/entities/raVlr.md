---
title : "RAVlr"
description : "роаминговое соглашение о поколении CAMEL"
weight : 4
---


Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
vlrMask | \<String\> | Mandatory | | | TM_ROAMING_AGREEMENT.STRVLR
camelPhases | \<int\> | Mandatory | | | TM_ROAMING_AGREEMENT.NCAMELPHASE_MASK
delete | \<Boolean\> | Optinal | | | 


### Example
```json
{
    "vlrMask":"7658",
    "camelPhases":7
}
```





