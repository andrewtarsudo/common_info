---
title : "ChangeRegionalZoneCodeIdentity"
description : "Управление сущностью RegionalZoneCodeIdentity"
weight : 4
---

## endpoint: /ProfileService/ChangeRegionalZoneCodeIdentity

### Request

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
action | \<String\> | Mandatory | create/modify/delete
regional | [\<Regional\>](../entities/regional) | Mandatory |

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{   
    "action":"create",
    "regional":
    {
        "name":"rus",
        "plmns":
        [
            {
                "plmn":"25001",
                "zoneCodes":
                [
                    {
                        "zoneCode":1
                    },
                    {
                        "zoneCode":2
                    }
                ]
            }
        ],
        "ccndcs":
        [
            {
                "ccndc":"7901",
                "zoneCodes":
                [
                    {
                        "zoneCode":2
                    },
                    {
                        "zoneCode":3
                    }
                ]
            }
        ]
    }
}
```
