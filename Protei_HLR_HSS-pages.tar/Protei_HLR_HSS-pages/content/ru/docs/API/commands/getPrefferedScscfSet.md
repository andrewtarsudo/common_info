---
title : "GetPrefferedScscfSet"
description : "Получение набора предпочтительных S-CSCF"
weight : 4
---

## endpoint: /ProfileService/GetPrefferedScscfSet

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Action | \<String\> | Mandatory | create/modify/delete
SetId | \<int\> | Mandatory | | | TM_IMS_PREFFERED_SCSCF_SET.NID_SET |


### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
PrefferedScscfSet | [\<PrefferedScscfSet\>](../entities/prefferedscscfset) | Mandatory | | | TM_IMS_PREFFERED_SCSCF_SET |

### Example
```json
{
    "SetId":1
}
```



