---
title : "AddAndActivateEmptySubscribers"
description : "Создание и активация пустого абонента"
weight : 4
---

## endpoint: /SubscriberService/AddAndActivateEmptySubscribers

### Request

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
subscribers | [[\<EmptySubscriber\>](../entities/emptysubscriber)] | Mandatory | List os subscriber 

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "subscribers":
    [
        {
            "imsi":"250010000001",
            "msisdn":"79000000001",
            "smsc":"1234567890",
            "teleServices":"16,17,21,22"
        },
        ...
        {
            "imsi":"250010000100",
            "msisdn":"79000000100",
            "smsc":"1234567890",
            "teleServices":"16,17,21,22"
        }
    ]
}
```
