---
title : "SendProvideSubscriberInformation"
description : "Запрос информации о регистрации абонента (используется для интеграции с внешними платформами)"
weight : 4
---

## endpoint: /SubscriberService/SendProvideSubscriberInfo

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
imsi | \<String\> | Conditional | IMSI | | TM_SUBSCRIBER_PROFILE.STRIMSI
msisdn | \<String\>  | Conditional | MSISDN | | TM_SUBSCRIBER_PROFILE.STRMSISDN

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
subscriberState | \<int\> | Optional | Состояние абонента
locationInformation | [\<LocationInformation\>](../entities/locationinformation) | Optional | Местоположение абонента


### Example
```json
{
    "imsi":"250010000001"
}
```


