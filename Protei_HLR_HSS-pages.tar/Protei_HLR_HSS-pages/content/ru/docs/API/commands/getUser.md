---
title : "GetUser"
description : "Получение пользователя сиситемы"
weight : 4
---

## endpoint: /ProfileService/GetUser

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
login | \<String\> | Mandatory |  | | TM_APIUSER.STRLOGIN

### Response

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
status | \<int\> | Mandatory | | | 
user | [\<User\>](../entities/user) | Optional | | | TM_APIUSER |

### Example
```json
    "login":"alisa"
```
