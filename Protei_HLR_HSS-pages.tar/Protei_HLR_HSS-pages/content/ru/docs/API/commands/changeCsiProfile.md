---
title : "ChangeCsiProfile"
description : "Изменение CAMEL профиля"
weight : 4
---

## endpoint: /ProfileService/ControlCsiProfile

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
action | \<String\> | Mandatory |  | create/modify/delete | 
oCsi | [\<OCsi\>](../entities/ocsi) | Conditional ||| TM_CAMEL_O_CSI
tCsi | [\<TCsi\>](../entities/tcsi) | Conditional ||| TM_CAMEL_T_CSI
smsCsi | [\<SmsCsi\>](../entities/smscsi) | Conditional ||| TM_CAMEL_SMS_CSI
gprsCsi | [\<GprsCsi\>](../entities/gprscsi) | Conditional ||| TM_CAMEL_GPRS_CSI
mCsi | [\<MCsi\>](../entities/mcsi) | Conditional ||| TM_CAMEL_M_CSI
dCsi | [\<DCsi\>](../entities/dcsi) | Conditional ||| TM_CAMEL_D_CSI
ssCsi | [\<SsCsi\>](../entities/sscsi) | Conditional ||| TM_CAMEL_SS_CSI
ussdCsi | [\<UssdCsi\>](../entities/ussdcsi) | Conditional ||| TM_CAMEL_U_CSI
oImCsi | [\<OCsi\>](../entities/ocsi) | Conditional ||| TM_CAMEL_O_CSI
vtCsi | [\<TCsi\>](../entities/tcsi) | Conditional ||| TM_CAMEL_T_CSI
dImCsi | [\<DCsi\>](../entities/dcsi) | Conditional ||| TM_CAMEL_D_CSI
force | \<Boolean\> | Optional | Принудительное удаление сущности, в случае, если она привязана к абонентскому профилю | | 


### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "imsi":"250010000000001",
    "oCsi":
    {
        "id":1,
        "camelCapabilityHandling":3,
        "csiActive":1,
        "csiTdps":
        [
            {
                "tdpId":1,
                "serviceKey":1,
                "gsmScfAddress":"78924813183138",
                "defaultHandling":2
            }
        ]
    }
}
```
