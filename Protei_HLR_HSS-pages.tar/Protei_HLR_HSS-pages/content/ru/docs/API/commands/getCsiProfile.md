---
title : "GetCsiProfile"
description : "Получение CAMEL профиля"
weight : 4
---

## endpoint: /ProfileService/GetCsiProfile

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
typeId | \<int\> | Mandatory |  |  | 
profileId | \<int\> | Mandatory |  |  | 

### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
oCsi | [\<OCsi\>](../entities/ocsi) | Conditional | TM_CAMEL_O_CSI
tCsi | [\<TCsi\>](../entities/tcsi) | Conditional | TM_CAMEL_T_CSI
smsCsi | [\<SmsCsi\>](../entities/smscsi) | Conditional | TM_CAMEL_SMS_CSI
gprsCsi | [\<GprsCsi\>](../entities/gprscsi) | Conditional | TM_CAMEL_GPRS_CSI
mCsi | [\<MCsi\>](../entities/mcsi) | Conditional | TM_CAMEL_M_CSI
dCsi | [\<DCsi\>](../entities/dcsi) | Conditional | TM_CAMEL_D_CSI
ssCsi | [\<SsCsi\>](../entities/sscsi) | Conditional | TM_CAMEL_SS_CSI
ussdCsi | [\<UssdCsi\>](../entities/ussdcsi) | Conditional | TM_CAMEL_U_CSI
oImCsi | [\<OCsi\>](../entities/ocsi) | Conditional | TM_CAMEL_O_CSI
vtCsi | [\<TCsi\>](../entities/tcsi) | Conditional | TM_CAMEL_T_CSI
dImCsi | [\<DCsi\>](../entities/dcsi) | Conditional | TM_CAMEL_D_CSI

#### TypeIds

ID | Description
:---|:----------
0 | O-CSI
1 | T-CSI
2 | SMS-CSI
3 | GPRS-CSI
4 | M-CSI
5 | D-CSI
6 | TIF-CSI    
7 | SS-CSI
8 | USSD-CSI
9 | O-IM-CSI
10 | VT-IM-CSI
11 | D-IM-CSI

### Example
```json
{
    "typeId":0,
    "profileId":1
}
```
