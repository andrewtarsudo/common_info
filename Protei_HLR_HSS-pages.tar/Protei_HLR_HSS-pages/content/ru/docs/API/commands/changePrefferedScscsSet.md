---
title : "ChangePrefferedScscfSet"
description : "Управление набором предпочтительных S-CSCF"
weight : 4
---

## endpoint: /ProfileService/ChangePrefferedScscfSetSet

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Action | \<String\> | Mandatory | create/modify/delete
PrefferedScscfSet | [\<PrefferedScscfSet\>](../entities/prefferedscscfset) | Mandatory | | | TM_IMS_PREFFERED_SCSCF_SET |


### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "Action":"create",
    "PrefferedScscfSet":
    {
        "SetId":1,
        "Scscfs":
        [
            {
                "ScscfName":"scscf1",
                "Priority":1
            },
            {
                "ScscfName":"scscf2",
                "Priority":2
            }
        ]
    }
}
```


