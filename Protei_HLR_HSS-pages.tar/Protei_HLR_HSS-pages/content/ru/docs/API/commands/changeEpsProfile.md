---
title : "ChangeEpsProfile"
description : "Изменение профиля EPS"
weight : 4
---

## endpoint: /ProfileService/ControlEpsProfile

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
action | \<String\> | Mandatory || create/modify/delete | 
epsProfile | [\<EpsProfile\>](../entities/epsprofile) | Mandatory ||| TM_DM_EPS_DATA
force | \<Boolean\> | Optional | Принудительное удаление сущности, в случае, если она привязана к абонентскому профилю || 

### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "action":"create",
    "epsProfile":
    {
        "eps_context_id":1,
        "service_selection":"test.protei.ru",
        "vplmnDnamicAddressAllowed":1,
        "qosClassId":6,
        "allocateRetPriority":4,
        "maxDl":1000,
        "maxUl":1000,
        "pdnType":1,
        "preEmptionCapability":1,
        "preEmptionVulnerability":1
    }
}
```


