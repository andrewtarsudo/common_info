---
title : "ChangeMsisdn"
description : "Смена MSISDN"
weight : 4
---

## endpoint: /SubscriberService/SetMSISDN

### Request

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
imsi | \<String\> | Mandatory | Текущий IMSI
msisdn | \<String\> | Mandatory | Новый MSISDN
status | \<int\> | Optional | Статус абонента 

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "imsi":"250010000001",
    "msisdn":"79000000002"
}
```


