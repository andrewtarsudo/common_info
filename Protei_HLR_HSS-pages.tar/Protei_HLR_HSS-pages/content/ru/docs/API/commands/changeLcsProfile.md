---
title : "ChangeLcsProfile"
description : "Упарвление профилем LCS"
weight : 4
---

## endpoint: /ProfileService/ChangeLcsProfile

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
action | \<String\> | Mandatory | | ["create","modify","delete"] |
lcsProfile | [\<LcsProfile\>](../entities/lcsprofile) | Optional | | 

### Reply
Element/Attribute | Type | Mandatory | Description | DB
:-----|:-----------------|------|------|--------
status | \<int\> | Mandatory | The status of the request | 


### Example
```json
{
    "action":"create",
    "lcsProfile":
    {
        "id":1,
        "gmlcList":
        [
            {
                "gmlcNumber":"2364657"
            }
        ],
        "privacyList":
        [
            {
                "ssCode":16,
                "ssStatus":5,
                "notificationToMsUser":1,
                "ecList":
                [
                    {
                        "gmlcRestriction":0,
                        "notificationToMsUser":1,
                        "externalAddress":"1245135"
                    }
                ],
                "plmnList":
                [
                    {
                        "clientExternalId":1
                    }
                ]
            }
        ],
        "molrList":
        [
            {
                "ssCode":15,
                "ssStatus":2
            }
        ]
    }
}
```







