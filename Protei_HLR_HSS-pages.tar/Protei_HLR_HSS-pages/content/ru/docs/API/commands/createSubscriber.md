---
title : "AddSubscriber"
description : "Создание абонента"
weight : 4
---

## endpoint: /SubscriberService/AddSubscriber

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
imsi | \<String\> | Mandatory | IMSI | | TM_SUBSCRIBER_PROFILE.STRIMSI
msisdn | \<String\>  | Mandatory | MSISDN | | TM_SUBSCRIBER_PROFILE.STRMSISDN
status | \<int\>  | Mandatory | The subscriber administrative state | 0 ‒ not provisioned (the card is not assigned to MSISDN); 1 ‒ provisioned/locked (the card is assigned to MSISDN and locked); 2 ‒ provisioned/unlocked (in-service); 3 ‒ provisioned/suspended (service is stopped, for example, if the phone was stolen);  4 – terminated (the subscriber is deleted)|TM_SUBSCRIBER_PROFILE.NADMINISTRATIVE_STATE
category | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NCATEGORY 
networkAccessMode | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NNETWORKACCESSMODE 
DefaultForwardingNumber | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRDEFAULTFORWARDINGNUMBER 
DefaultForwardingStatus | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NDEFAULTFORWARDINGSTATUS
groupId | \<int\> | Optional | |  | TM_SUBSCRIBER_PROFILE.NGROUPID
ipSmGwNumber | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRIP_SM_GW_NUMBER
ipSmGwHost | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRIP_SM_GW_HOST
ipSmGwRealm | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRIP_SM_GW_REALM
deactivatePsi | \<int\> | Optional | |  | TM_SUBSCRIBER_PROFILE.NDEACTIVATEPSI
baocWithoutCamel | \<int\>  | Optional | |  | TM_SUBSCRIBER_PROFILE.NBAOC_WITHOUTCAMEL
ForbidReg_WithoutCamel | \<int\>  | Optional | |  | TM_SUBSCRIBER_PROFILE.LFORBIDREG_WITHOUTCAMEL
qosGprsId | \<int\>  | Optional | id профиля QoS для Gprs | | TM_SUBSCRIBER_PROFILE.NQOS_GPRS_ID
qosEpsId | \<int\>  | Optional | id профиля QoS для Eps | | TM_SUBSCRIBER_PROFILE.NQOS_EPS_ID
roamingNotAllowed | \<int\>  | Optional | запрет роаминга | | TM_SUBSCRIBER_PROFILE.NROAMINGNOTALLOWED 
accessRestrictionData | [\<AccessRestrictionData\>](../entities/accessrestrictiondata) | Optional | Access restrition data | | TM_SUBSCRIBER_PROFILE.NACCESSRESTRICTIONDATA
periodicLauTimer | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NPERIODICLAU_TIMER
periodicRauTauTimer | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NPERIODICRAU_TAU_TIMER
SCA | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRSCA
ueUsageType | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NUE_USAGE_TYPE
imrn | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRIMRN
voLte | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NVOLTE
icsIndicator | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NICS_INDICATOR
hlr_profile_id | \<int\>  | Optional | Identifier of [ProfileTemplate](../entities/profiletemplate) from config |  |
algorithm | \<int\> | Mandatory | Algorithm of authentification | 1 - COMP1; 2 - COMP2; 3 - COMP3; 4 - MILLENAGE; 6 - XOR; 7 - TUAK; | TM_AUC.NALGORITM
ki | \<String\>  | Mandatory | Key | for TUAK length 32/64, for other length 32 | TM_AUC.STRKI
opc | \<String\> | Optional | OPC | | TM_AUC.STROPC |
HSM_ID | \<int\> | Optional | | | TM_AUC.NHSM_ID
aucData | [\<AucData\>](../entities/aucdata) | Optional | |  | TM_AUC
ssData | [[\<SsData\>](../entities/ssdata)]  | Optional | | | TM_PROVISIONED_SS, TM_PROVISIONED_SS_BS
ssForw | [[\<SsForw\>](../entities/ssforwarding)]  | Optional | |  | TM_PROVISIONED_SS_FORW
ssBarring | [[\<SsBarring\>](../entities/ssbarring)]  | Optional | | | TM_PROVISIONED_SS_CALL_BARR
ssCugFeat | [[\<SsCugFeat\>](../entities/sscugfeat)]  | Optional | | | TM_PROVISIONED_SS_CUG_FEATURE
ssCugSub | [[\<SsCugSub\>](../entities/sscugsub)]  | Optional | | | TM_PROVISIONED_SS_CUG_SUB, TM_PROVISIONED_SS_CUG_SUB_BS
epsData | [\<EpsData\>](../entities/epsdata) | Optional | |  | TM_DM_SUBSCRIBER_EPS
lcsId | \<int\> | Optional | |  | TM_LCS_SUBSCRIBER.NLCS_ID
PDP_DATA | \<String\> | Optional | DEPRECATED | | TM_SUBSCRIBER_PDP
EPS_CONTEXTS | \<String\> | Optional | DEPRECATED | | TM_DM_SUBSCRIBER_EPS_CONTEXT
pdpData | [[\<PdpData\>](../entities/pdpdata)] | Optional | | | TM_SUBSCRIBER_PDP
link-eps-data | [[\<LinkEpsData\>](../entities/linkepsdata)] | Optional | | | TM_DM_SUBSCRIBER_EPS_CONTEXT
O_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 0; NSUB_TYPE = 0;)
T_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 1; NSUB_TYPE = 0;)
SMS_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 2;)
GPRS_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 3;)
M_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 4;)
D_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 5; NSUB_TYPE = 0;)
USSD_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 8;)
O_IM_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 0; NSUB_TYPE = 2;)
VT_IM_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 1; NSUB_TYPE = 3;)
D_IM_CSI | [\<int\>] | Optional | DEPRECATED | | TM_CAMEL_SUBSCRIBER (NTYPECSI = 5; NSUB_TYPE = 2;)
csi-list | [[\<CsiLink\>](../entities/csilink)] | Optional | | | TM_CAMEL_SUBSCRIBER
TeleServices | [\<int\>] | Optional | | | TM_TELESERVICE
BearerServices | [\<int\>] | Optional | | | TM_BEARERSERVICE
WL_DATA | [\<int\>] | Optional | | | TM_SUB_2_WL
BL_DATA | [\<int\>] | Optional | | | TM_SUB_2_BL
WL_NAMES | [\<String\>] | Optional | | | TM_SUB_WL
BL_NAMES | [\<String\>] | Optional | | | TM_SUB_BL
ODB | [\<ODB\>](../entities/odb) | Optional | | | TM_ODB
odb-param | [\<OdbParam\>](../entities/odbparam) | Optional | DEPRECATED | | TM_ODB
chargingCharacteristics | \<String\> | Optional | | | TM_GPRS_DATA.STRCHARGINGCHARACTERISTICS |
aMsisdn | [\<String\>] | Optional | List of additional MSISDN(SRI,SRIFSM) | | TM_AMSISDN |
link-eps-data | [[\<LinkEpsData\>](../entities/linkepsdata)] | Optional | | | TM_DM_SUBSCRIBER_EPS_CONTEXT
imsProfile | [\<ImsProfile\>](../entities/imsprofile) | Optional | | |  |
imsSubscription | [\<ImsSubscription\>](../entities/imssubscription) | Optional | | |  |
regionalZoneCodes | [[\<RegionalZoneCodeLink\>](../entities/regionalzonecodelink)] | Optional | | |  | TM_SUB_2_REGIONAL


### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "imsi":"250010000001",
    "msisdn":"79000000001",
    "status":2,
    "category":10,
    "networkAccessMode":0,
    "DefaultForwardingNumber":"867349752",
    "DefaultForwardingStatus":7,
    "ipSmGwNumber":"23525252",
    "algorithm":4,
    "ki":"12345678900987654321123456789009",
    "opc":"09876543211234567890098765432112",
    "ssData":
    [
        {
            "ss_Code":17,
            "ss_Status":5,
            "sub_option_type":1,
            "sub_option":1,
            "tele_service":[0,16,32]
        }
    ],
    "ssForw":
    [
        {
            "ss_Code":42,
            "ss_Status":7,
            "forwardedToNumber":"42513466754",
            "tele_service":[0,16,32]
        }
    ],
    "EpsData":
    {
        "defContextId":1,
        "ueMaxDl":10000,
        "ueMaxUl":10000
    },
    "link-eps-data":
    [
        {
            "context-id":2,
            "ipv4":"192.168.1.22",
            "plmnId":"25001"
        }
    ],
    "pdpData":
    [
        {
            "context-id":1,
            "type":"0080"
        }
    ],
    "ODB":
    {
        "generalSetList":[1,6,19],
        "SubscriberStatus":1
    },
    "imsProfile":
    {
        "impi":"250010000001@ims.protei.ru",
        "authScheme":5,
        "sipDigest":
        {
            "password":"elephant"
        },
        "impus":
        [
            {
                "Identity":"sip:79000000001@ims.protei.ru",
                "BarringIndication":0,
                "Type":0,
                "CanRegister":1,
                "ServiceProfileName":"sp"
            },
            {
                "Identity":"tel:+79000000001@ims.protei.ru",
                "BarringIndication":0,
                "Type":1,
                "CanRegister":1,
                "WildcardPsi":"tel:+79000000001!.*!",
                "PsiActivation":1,
                "ServiceProfileName":"sp"
            }
        ],
        "implicitlySets":
        [
            {
                "name":"implSet1"
            }
        ]
    },
    "imsSubscription":
    {
        "name":"250010000001",
        "capabilitySetId":1,
        "prefferedScscfSetId":1,
        "chargingInformationName":"ci",
        "serviceProfiles":
        [
            {
                "Name":"sp",
                "CoreNetworkServiceAuthorization":1,
                "Ifcs":
                [
                    {
                        "Name":"ifc1",
                        "Priority":1,
                        "ApplicationServerName":"as",
                        "ProfilePartIndicator":1,
                        "TriggerPoint":
                        {
                            "ConditionTypeCNF":1,
                            "Spt":
                            [
                                {
                                    "Group":1,
                                    "Method":"INVITE",
                                    "SessionCase":1,
                                    "ConditionNegated":2,
                                    "Type":3,
                                    "RequestUri":"http://ims.protei.ru/spt1",
                                    "Header":"header",
                                    "Content":"headerContent",
                                    "SdpLine":"sdpLine",
                                    "SdpLineContent":"sdpLineContent",
                                    "RegistrationType":1
                                }  
                            ]
                        }
                    }
                ]
            }
        ],
        "implicitlyRegisteredSet":
        [
            {
                "name":"implSet1",
                "impus":
                [
                    {
                        "Identity":"sip:protei@ims.protei.ru",
                        "BarringIndication":0,
                        "Type":0,
                        "CanRegister":1,
                        "ServiceProfileName":"sp",
                        "Default":true
                    },
                    {
                        "Identity":"sip:ntc_protei@ims.protei.ru",
                        "BarringIndication":0,
                        "Type":0,
                        "CanRegister":1,
                        "ServiceProfileName":"sp"
                    }
                ]
            }
        ]
    }
}
```
