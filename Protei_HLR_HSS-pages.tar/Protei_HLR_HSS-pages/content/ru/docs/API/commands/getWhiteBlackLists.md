---
title : "GetWhiteBlackLists"
description : "Получение белых/черных списков"
weight : 4
---

## endpoint: /ProfileService/GetWhiteBlackLists

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
type | \<String\> | Mandatory | Тип списка | ["white";"black"] 
id | \<int\> | Conditional | | | TM_WHITELIST_VLR.NID / TM_WHITELIST_VLR.NID
name | \<String\> | Conditional | | | TM_WHITELIST_VLR.STRNAME / TM_BLACKLIST_VLR.STRNAME

### Reply
Element/Attribute | Type | Mandatory | Description | DB
:-----|:-----------------|------|------|--------
status | \<int\> | Mandatory | The status of the request | 
whiteList | [\<WhiteList\>](../entities/whitelist) | Conditional | | TM_WHITELIST_VLR
blackList | [\<BlackList\>](../entities/blacklist) | Conditional | | TM_BLACKLIST_VLR


### Example
```json
{
    "type":"white",
    "name":"wl_rus"
}
```





