---
title : "ChangeImsSubscription"
description : "Управление IMS подпиской"
weight : 4
---

## endpoint: /ProfileService/ChangeImsSubscription

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
action | \<String\> | Mandatory | create/modify/delete
imsSubscription | [\<ImsSubscription\>](../entities/imssubscription) | Mandatory | | | TM_IMS_SUBSCRIPTION |


### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "action":"create",
    "imsSubscription":
    {
        "name":"imsu",
        "capabilitySetId":1,
        "prefferedScscfSetId":1,
        "chargingInformationName":"ci",
        "serviceProfiles":
        [
            {
                "Name":"sp",
                "CoreNetworkServiceAuthorization":1,
                "Ifcs":
                [
                    {
                        "Name":"ifc1",
                        "Priority":1,
                        "ApplicationServerName":"as",
                        "ProfilePartIndicator":1,
                        "TriggerPoint":
                        {
                            "ConditionTypeCNF":1,
                            "Spt":
                            [
                                {
                                    "Group":1,
                                    "Method":"INVITE",
                                    "SessionCase":1,
                                    "ConditionNegated":2,
                                    "Type":3,
                                    "RequestUri":"http://ims.protei.ru/spt1",
                                    "Header":"header",
                                    "Content":"headerContent",
                                    "SdpLine":"sdpLine",
                                    "SdpLineContent":"sdpLineContent",
                                    "RegistrationType":1
                                }  
                            ]
                        }
                    }
                ]
            }
        ],
        "implicitlyRegisteredSet":
        [
            {
                "name":"implSet1",
                "impus":
                [
                    {
                        "Identity":"sip:protei@ims.protei.ru",
                        "BarringIndication":0,
                        "Type":0,
                        "CanRegister":1,
                        "ServiceProfileName":"sp",
                        "Default":true
                    },
                    {
                        "Identity":"sip:ntc_protei@ims.protei.ru",
                        "BarringIndication":0,
                        "Type":0,
                        "CanRegister":1,
                        "ServiceProfileName":"sp"
                    }
                ]
            }
        ]
    }
}
```
