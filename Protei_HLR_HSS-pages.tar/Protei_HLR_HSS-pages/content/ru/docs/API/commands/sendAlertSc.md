---
title : "SendAlertSc"
description : "Уведомление SC о том, что абонент активен (используется для интеграции с внешними платформами)"
weight : 4
---

## endpoint: /SubscriberService/SendAlertSc

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
imsi | \<String\> | Conditional | IMSI | | TM_SUBSCRIBER_PROFILE.STRIMSI
msisdn | \<String\>  | Conditional | MSISDN | | TM_SUBSCRIBER_PROFILE.STRMSISDN
alertReason | \<int\> | Optional |  | [0,1] | 

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "imsi":"250010000001",
    "alertReason":1
}
```


