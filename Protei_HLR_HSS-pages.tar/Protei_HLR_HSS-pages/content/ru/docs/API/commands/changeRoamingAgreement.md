---
title : "ChangeRoamigAgreement"
description : "Управление роаминговыми соглашениями о поколении CAMEL"
weight : 4
---

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
vlrs | [[\<RAVlr\>](../entities/ravlr)] | Mandatory | | | TM_ROAMING_AGREEMENT


### Response

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
status | \<int\> | Mandatory | | | 


### Example
```json
{
    "vlrs":
    {
        "vlrMask":"7658",
        "camelPhases":7
    }
}
```




