---
title : "ChangeUser"
description : "Управление пользователем сиситемы"
weight : 4
---

## endpoint: /ProfileService/ControlUser

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
action | \<String\> | Mandatory |  | ["create","modify","delete"] |
user | [\<User\>](../entities/user) | Optional | | | TM_APIUSER |

### Response

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
status | \<int\> | Mandatory | | | 

### Example
```json
{
    "action":"create",
    "user":
    {
        "login":"alisa",
        "password":"elephant",
        "permissions":
        [
            {
                "permissions":"RW",
                "groupName":"gr1"
            },
            {
                "permissions":"AD",
                "groupName":"gr2"
            }
        ]
    }
}
```
