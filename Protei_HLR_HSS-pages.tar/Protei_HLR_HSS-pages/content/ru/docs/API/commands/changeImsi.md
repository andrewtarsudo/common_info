---
title : "ChangeImsi"
description : "Смена IMSI"
weight : 4
---

## endpoint: /SubscriberService/ChangeIMSI

### Request

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
oldimsi | \<String\> | Conditional | Текущий IMSI
msisdn | \<String\> | Conditional | Текущий MSISDN
imsi | \<String\> | Mandatory | Новый IMSI
status | \<int\> | Optional | Статус абонента 

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "oldimsi":"250010000001",
    "imsi":"250010000002"
}
```

