---
title : "ChangeDbConfig"
description : "Изменение конифгурации в БД"
weight : 4
---

## endpoint: /ProfileService/ControlConfig

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
config | [\<DbConfig\>](../entities/dbconfig) | Mandatory | | | TM_CONFIG 


### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "config":
    {
        "mwdMaxCount":1,
        "maxForward":1,
        "sqnStart":1,
        "sqnEnd":1000,
        "sqnStep":1,
        "defaultForwardingOptions":1,
        "defaultForwardingType":1,
        "activeWhiteList":1
    }
}
```
