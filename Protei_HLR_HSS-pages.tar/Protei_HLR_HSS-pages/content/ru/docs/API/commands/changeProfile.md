
---
title : "ChangeProfile"
description : "Изменение профиля абонента"
weight : 4
---

## endpoint: /ProfileService/ProfileControl

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
imsi | \<String\> | Conditional | IMSI | | TM_SUBSCRIBER_PROFILE.STRIMSI
msisdn | \<String\>  | Conditional | MSISDN | | TM_SUBSCRIBER_PROFILE.STRMSISDN
newMsisdn | \<String\>  | Optional | MSISDN | | TM_SUBSCRIBER_PROFILE.STRMSISDN
status | \<int\>  | Optional | The subscriber administrative state | |TM_SUBSCRIBER_PROFILE.NADMINISTRATIVE_STATE
category | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NCATEGORY 
networkAccessMode | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NNETWORKACCESSMODE 
DefaultForwardingNumber | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRDEFAULTFORWARDINGNUMBER 
DefaultForwardingStatus | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NDEFAULTFORWARDINGSTATUS
groupId | \<ValueControl\<int\>\> | Optional | |  | TM_SUBSCRIBER_PROFILE.NGROUPID
ipSmGwNumber | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRIP_SM_GW_NUMBER
ipSmGwHost | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRIP_SM_GW_HOST
ipSmGwRealm | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRIP_SM_GW_REALM
deactivatePsi | \<int\> | Optional | |  | TM_SUBSCRIBER_PROFILE.NDEACTIVATEPSI
baocWithoutCamel | \<int\>  | Optional | |  | TM_SUBSCRIBER_PROFILE.NBAOC_WITHOUTCAMEL
forbid_reg | \<int\>  | Optional | |  | TM_SUBSCRIBER_PROFILE.LFORBIDREG_WITHOUTCAMEL
qosGprsId | \<ValueControl\<int\>\>  | Optional | id профиля QoS для Gprs | | TM_SUBSCRIBER_PROFILE.NQOS_GPRS_ID
qosEpsId | \<ValueControl\<int\>\>  | Optional | id профиля QoS для Eps | | TM_SUBSCRIBER_PROFILE.NQOS_EPS_ID
roamingNotAllowed | \<int\>  | Optional | запрет роаминга | | TM_SUBSCRIBER_PROFILE.NROAMINGNOTALLOWED 
accessRestrictionData | [\<AccessRestrictionData\>](../entities/accessrestrictiondata) | Optional | Access restrition data | | TM_SUBSCRIBER_PROFILE.NACCESSRESTRICTIONDATA
periodicLauTimer | \<ValueControl\<int\>\> | Optional | | | TM_SUBSCRIBER_PROFILE.NPERIODICLAU_TIMER
periodicRauTauTimer | \<ValueControl\<int\>\> | Optional | | | TM_SUBSCRIBER_PROFILE.NPERIODICRAU_TAU_TIMER
icsIndicator | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NICS_INDICATOR
amfUmts | \<ValueControl\<String\>\> | Optional | | | TM_AUC.STRAMF_UMTS
amfLte | \<ValueControl\<String\>\> | Optional | | | TM_AUC.STRAMF_LTE
amfIms | \<ValueControl\<String\>\> | Optional | | | TM_AUC.STRAMF_IMS
SCA | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRSCA
ueUsageType | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NUE_USAGE_TYPE
imrn | \<String\> | Optional | | | TM_SUBSCRIBER_PROFILE.STRIMRN
voLte | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NVOLTE
opc | \<String\> | Optional | OPC | | TM_AUC.STROPC |
HSM_ID | \<int\> | Optional | | | TM_AUC.NHSM_ID
ssData | [[\<SsData\>](../entities/ssdata)]  | Optional | | | TM_PROVISIONED_SS, TM_PROVISIONED_SS_BS
ssForw | [[\<SsForw\>](../entities/ssforwarding)]  | Optional | |  | TM_PROVISIONED_SS_FORW
ssBarring | [[\<SsBarring\>](../entities/ssbarring)]  | Optional | | | TM_PROVISIONED_SS_CALL_BARR
ssCugFeat | [[\<SsCugFeat\>](../entities/sscugfeat)]  | Optional | | | TM_PROVISIONED_SS_CUG_FEATURE
ssCugSub | [[\<SsCugSub\>](../entities/sscugsub)]  | Optional | | | TM_PROVISIONED_SS_CUG_SUB, TM_PROVISIONED_SS_CUG_SUB_BS
eps-data | [\<ChangeEpsData\>](../entities/changeepsdata) | Optional | |  | TM_DM_SUBSCRIBER_EPS
lcsId | \<ValueControl\<int\>\> | Optional | |  | TM_LCS_SUBSCRIBER.NLCS_ID
EPS_CONTEXTS | \<String\> | Optional | DEPRECATED | | TM_DM_SUBSCRIBER_EPS_CONTEXT
pdp-data | [\<PdpData\>](../entities/pdpdata) | Optional | | | TM_SUBSCRIBER_PDP
link-eps-data | [[\<LinkEpsData\>](../entities/linkepsdata)] | Optional | | | TM_DM_SUBSCRIBER_EPS_CONTEXT
csi-list | [[\<Csi\>](../entities/csilink)] | Optional | | | TM_CAMEL_SUBSCRIBER
teleserviceList | [\<int\>] | Optional | | | TM_TELESERVICE
teleservicesToAdd | [\<int\>] | Optional | | | TM_TELESERVICE
teleservicesToDelete | [\<int\>] | Optional | | | TM_TELESERVICE
bearerserviceList | [\<int\>] | Optional | | | TM_BEARERSERVICE
bearerservicesToAdd | [\<int\>] | Optional | | | TM_BEARERSERVICE
bearerservicesToDelete | [\<int\>] | Optional | | | TM_BEARERSERVICE
whiteListIds | [\<int\>] | Optional | | | TM_SUB_WL
whiteListIdsToAdd | [\<int\>] | Optional | | | TM_SUB_WL
whiteListIdsToDelete | [\<int\>] | Optional | | | TM_SUB_WL
blackListIds | [\<int\>] | Optional | | | TM_SUB_BL
blackListIdsToAdd | [\<int\>] | Optional | | | TM_SUB_BL
blackListIdsToDelete | [\<int\>] | Optional | | | TM_SUB_BL
whiteListNames | [\<String\>] | Optional | | | TM_SUB_WL
whiteListNamesToAdd | [\<String\>] | Optional | | | TM_SUB_WL
whiteListNamesToDelete | [\<String\>] | Optional | | | TM_SUB_WL
blackListNames | [\<String\>] | Optional | | | TM_SUB_BL
blackListNamesToAdd | [\<String\>] | Optional | | | TM_SUB_BL
blackListNamesToDelete | [\<String\>] | Optional | | | TM_SUB_BL
ODB | [\<ODB\>](../entities/odb) | Optional | | | TM_ODB
odb-param | [\<OdbParam\>](../entities/odbparam) | Optional | DEPRECATED | | TM_ODB
chargingCharacteristics | \<ValueControl\<String\>\> | Optional | | | TM_GPRS_DATA.STRCHARGINGCHARACTERISTICS |
aMsisdn | [\<ValueControl\<String\>\>] | Optional | List of additional MSISDN(SRI,SRIFSM) | | TM_AMSISDN |
imsProfile | [\<ImsProfile\>](../entities/imsprofile) | Optional | | |  |
imsSubscription | [\<ImsSubscription\>](../entities/imssubscription) | Optional | | |  |
regionalZoneCodes | [[\<RegionalZoneCodeLink\>](../entities/regionalzonecodelink)] | Optional | | |  | TM_SUB_2_REGIONAL


#### \<ValurControl\<T\>\>
Element/Attribute | Type | Mandatory | Description | Values
:-----------------|:-----|-----------|-------------|--------
value | \<T\> | Optional | |
delete | \<Boolean\> | Optional | |


### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "imsi":"250010000001",
    "status":2,
    "category":10,
    "networkAccessMode":0,
    "DefaultForwardingNumber":"867349752",
    "DefaultForwardingStatus":7,
    "ipSmGwNumber":"23525252",
    "ssData":
    [
        {
            "ss_Code":17,
            "ss_Status":5,
            "sub_option_type":1,
            "sub_option":1,
            "tele_service":[0,16,32]
        },
        {
            "ss_Code":65,
            "ss_Status":5
        }
    ],
    "ssForw":
    [
        {
            "ss_Code":42,
            "ss_Status":7,
            "forwardedToNumber":"42513466754",
            "tele_service":[0,16,32]
        }
    ],
    "EpsData":
    {
        "defContextId":1,
        "ueMaxDl":10000,
        "ueMaxUl":10000
    },
    "link-eps-data":
    [
        {
            "context-id":2,
            "ipv4":"192.168.1.22",
            "plmnId":"25001"
        }
    ],
    "PdpData":
    [
        {
            "context-id":1,
            "type":"0080"
        }
    ],
    "ODB":
    {
        "generalSetList":[1,6,19],
        "generalUnsetList":[2,5],
        "SubscriberStatus":1
    },
    "imsProfile":
    {
        "impi":"250010000001@ims.protei.ru",
        "authScheme":5,
        "sipDigest":
        {
        "password":"elephant"
        },
        "impus":
        [
            {
                "Identity":"sip:79000000001@ims.protei.ru",
                "BarringIndication":0,
                "Type":0,
                "CanRegister":1,
                "ServiceProfileName":"sp"
            },
            {
                "Identity":"tel:+79000000001@ims.protei.ru",
                "BarringIndication":0,
                "Type":1,
                "CanRegister":1,
                "WildcardPsi":"tel:+79000000001!.*!",
                "PsiActivation":1,
                "ServiceProfileName":"sp"
            }
        ],
        "implicitlySets":
        [
            {
                "name":"implSet1"
            }
        ]
    },
    "imsSubscription":
    {
        "name":"250010000001",
        "capabilitySetId":1,
        "prefferedScscfSetId":1,
        "chargingInformationName":"ci",
        "serviceProfiles":
        [
            {
                "Name":"sp",
                "CoreNetworkServiceAuthorization":1,
                "Ifcs":
                [
                    {
                        "Name":"ifc1",
                        "Priority":1,
                        "ApplicationServerName":"as",
                        "ProfilePartIndicator":1,
                        "TriggerPoint":
                        {
                            "ConditionTypeCNF":1,
                            "Spt":
                            [
                                {
                                    "Group":1,
                                    "Method":"INVITE",
                                    "SessionCase":1,
                                    "ConditionNegated":2,
                                    "Type":3,
                                    "RequestUri":"http://ims.protei.ru/spt1",
                                    "Header":"header",
                                    "Content":"headerContent",
                                    "SdpLine":"sdpLine",
                                    "SdpLineContent":"sdpLineContent",
                                    "RegistrationType":1
                                }  
                            ]
                        }
                    }
                ]
            }
        ],
        "implicitlyRegisteredSet":
        [
            {
                "name":"implSet1",
                "impus":
                [
                    {
                        "Identity":"sip:protei@ims.protei.ru",
                        "BarringIndication":0,
                        "Type":0,
                        "CanRegister":1,
                        "ServiceProfileName":"sp",
                        "Default":true
                    },
                    {
                        "Identity":"sip:ntc_protei@ims.protei.ru",
                        "BarringIndication":0,
                        "Type":0,
                        "CanRegister":1,
                        "ServiceProfileName":"sp"
                    }
                ]
            }
        ]
}
```
