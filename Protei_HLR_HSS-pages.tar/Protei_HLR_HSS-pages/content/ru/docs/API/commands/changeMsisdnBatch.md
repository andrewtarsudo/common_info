---
title : "ChangeMsisdnBatch"
description : "Смена MSISDN у списка абонентов"
weight : 4
---

## endpoint: /SubscriberService/SetMSISDNBatch

### Request

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
requests | [[\<ChangeMSISDN\>](../changemsisdn)] | Mandatory | 
skipIfNotFound | \<Boolean\> | Mandatory | Пропустить несуществующие IMSI

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "requests":
    [
        {
            "imsi":"250010000001",
            "msisdn":"79100000001"
        },
        {
            "imsi":"250010000002",
            "msisdn":"79100000002"
        }
    ],
    "skipIfNotFound":true
```



