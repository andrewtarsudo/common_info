---
title : "GetProperties"
description : "Получение настроек Core и API"
weight : 4
---

## endpoint: /InternalService/GetProperties

### Request
Empty request

### Response
Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
db    |  [\<DbProperties\>](../entities/dbproperties) | Mandatory | Настройки подключения к базе данных
core    |  [\<CoreProperties\>](../entities/coreproperties) | Mandatory | Функциональности, поддерживаемые на ядре


### Example response
```json
{
    "db":
    {
        "user":"hlr",
        "password":"bGsnHXypyew=",
        "url":"jdbc:mysql://localhost:3306/HLR"
    },
    "core":
    {
        "hlr":true,
        "hss":true,
        "ims":false,
        "lcs":false
    }
}
```
