---
title : "GetProfile"
description : "Получение профиля абонента"
weight : 4
---

## endpoint: /ProfileService/GetProfile

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
imsi | \<String\> | Conditional | IMSI | | TM_SUBSCRIBER_PROFILE.STRIMSI
msisdn | \<String\>  | Conditional | MSISDN | | TM_SUBSCRIBER_PROFILE.STRMSISDN
impi | \<String\> | Conditional | IMPI | | TM_IMS_PRIVATE_IDENTITY.STRPRIVATE_USER_ID
impu | \<String\> | Conditional | IMPU | | TM_IMS_PUBLIC_IDENTITY.STR_PUBLIC_IDENTITY
status | \<Boolean\> | Optional | | | 
forbid_reg | \<Boolean\> | Optional | | | 
odb-param | \<Boolean\> | Optional | | | 
pdp-data | \<Boolean\> | Optional | | | 
eps-context-data | \<Boolean\> | Optional | | | 
eps-data | \<Boolean\> | Optional | | | 
csi-list | \<Boolean\> | Optional | | | 
ssData | \<Boolean\> | Optional | | | 
ssForw | \<Boolean\> | Optional | | | 
ssBarring | \<Boolean\> | Optional | | | 
teleserviceList | \<Boolean\> | Optional | | | 
bearerserviceList | \<Boolean\> | Optional | | | 
roaming-info | \<Boolean\> | Optional | | | 
roaming-sgsn-info | \<Boolean\> | Optional | | | 
defaultForw | \<Boolean\> | Optional | | | 
whiteLists | \<Boolean\> | Optional | | |  	
blackLists | \<Boolean\> | Optional | | |  	
lcs | \<Boolean\> | Optional | | |  	
tk | \<Boolean\> | Optional | | |  	
group | \<Boolean\> | Optional | | |  	
deactivatePsi | \<Boolean\> | Optional | | |  	
baocWithoutCamel | \<Boolean\> | Optional | | |  	
ipSmGw | \<Boolean\> | Optional | | |  	
networkAccessMode | \<Boolean\> | Optional | | |  	
fullWBL | \<Boolean\> | Optional | | |  	
fullCSI | \<Boolean\> | Optional | | |  	
qosGprsId | \<Boolean\> | Optional | | |  	
qosEpsId | \<Boolean\> | Optional | | |  	
accessRestrictionData | \<Boolean\> | Optional | | |  	
chargingCharacteristics | \<Boolean\> | Optional | | |  	
ims | \<Boolean\> | Optional | | |  	
imsFull | \<Boolean\> | Optional | | |
roaming-scscf-info | \<Boolean\> | Optional | | |
aMsisdn | \<Boolean\> | Optional | | |  	
periodicLauTimer | \<Boolean\> | Optional | | |  	
periodicRauTauTimer | \<Boolean\> | Optional | | | 	
HSM_ID | \<Boolean\> | Optional | | |  	
opc | \<Boolean\> | Optional | | |  	
ueUsageType | \<Boolean\> | Optional | | |  	
lastActivity | \<Boolean\> | Optional | | |  	
SCA | \<Boolean\> | Optional | | |  	
category | \<Boolean\> | Optional | | |  
icsIndicator | \<Boolean\> | Optional | | |  
all | \<Boolean\> | Optional | | |  



### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
imsi | \<String\> | Mandatory | TM_SUBSCRIBER_PROFILE.STRIMSI
msisdn | \<String\> | Optional | TM_SUBSCRIBER_PROFILE.STRMSISDN
administrative_state | \<int\> | Optional | TM_SUBSCRIBER_PROFILE.NADMINISTRATIVE_STATE
forbid_reg | \<int\> | Optional | TM_SUBSCRIBER_PROFILE.LFORBIDREG_WITHOUTCAMEL
roaming_not_allowed | \<int\> | Optional | TM_SUBSCRIBER_PROFILE.NROAMINGNOTALLOWED
odb-param | [\<ODB\>](../entities/odb) | Optional | TM_ODB
pdp-data | [[\<PdpProfile\>](../entities/pdpprofile)] |	Optional | TM_PDP_DATA
eps-context-data |	[[\<EpsProfile\>](../etities/epsprofile)] | Optional | TM_DM_SUBSCRIBER_EPS_CONTEXT
eps-data | [\<EpsData\>](../entities/epsdata) | Optional | TM_DM_SUBSCRIBER_EPS
csi-list | [[\<CsiLink\>](../entities/csilink)] | Optional | TM_CAMEL_SUBSCRIBER
oCsi-list | [[\<OCsi\>](../entities/ocsi)] | Optional | TM_CAMEL_O_CSI
tCsi-list | [[\<TCsi\>](../entities/tcsi)] | Optional | TM_CAMEL_T_CSI
smsCsi-list | [[\<SmsCsi\>](../entities/smscsi)] | Optional | TM_CAMEL_SMS_CSI
gprsCsi-list | [[\<GprsCsi\>](../entities/gprscsi)] | Optional | TM_CAMEL_GPRS_CSI
mCsi-list | [[\<MCsi\>](../entities/mcsi)] | Optional | TM_CAMEL_M_CSI
dCsi-list | [[\<DCsi\>](../entities/dcsi)] | Optional | TM_CAMEL_D_CSI
ssCsi-list | [[\<SsCsi\>](../entities/sscsi)] | Optional | TM_CAMEL_SS_CSI
oImCsi-list | [[\<OCsi\>](../entities/ocsi)] | Optional | TM_CAMEL_O_CSI
vtCsi-list | [[\<TCsi\>](../entities/tcsi)] | Optional | TM_CAMEL_T_CSI
dImCsi-list | [[\<DCsi\>](../entities/dcsi)] | Optional | TM_CAMEL_D_CSI
ssData | [[\<SsData\>](../entities/ssdata)] | Optional | TM_PROVISIONED_SS
ssForw | [[\<SsForw\>](../entities/ssFfrwarding)] | Optional | TM_PROVISIONED_SS_FORW
ssBarring | [[\<SsBarring\>](../entities/ssbarring)] | Optional | TM_PROVISIONED_SS_CALL_BARR
lcsPrivacy | [[\<LcsPrivacy>\]()] | Optional | TM_ROAMING_LCS_PRIVACY
lcsMolr | [[\<LcsMolr>\]()] | Optional | TM_ROAMING_LCS_MOLR
teleserviceList | [\<int\>] | Optional | TM_TELESERVICE.NTELESERVICECODE
bearerserviceList | [\<int\>] | Optional | TM_BEARERSERVICE.NBEARERSERVICECODE
roaming-info | [\<RoamingInfo\>](../entities/roaming) | Optional | TM_ROAMING
roaming-sgsn-info | [\<RoamingSgsnInfo\>](../entities/roamingsgsn) | Optional | TM_ROAMING_SGSN
defaultForwNumber | \<String\> | Optional | Tm_Subscriber_Profile.strDefaultForwardingNumber
defaultForwStatus | \<int\> | Optional | Tm_Subscriber_Profile.nDefaultForwardingStatus
whiteLists | [[\<WhiteList\>](../entities/whitelist)] | Optional | 
blackLists | [[\<BlackList\>](../entities/blacklist)] | Optional | 
lcsId | \<int\> | Optional | Tm_Subscriber_Profile.nLcsID
tkId | \<int\> | Optional | tm_AUC.tkID
groupId | \<int\> | Optional | Tm_Subscriber_Profile.nGroupId
deactivatePsi | \<int\> | Optional | Tm_Subscriber_Profile.nDeactivatePSI
baocWithoutCamel | \<int\> | Optional | Tm_Subscriber_Profile.nBAOC_WithoutCamel
ipSmGwNumber | \<String\> | Optional | Tm_Subscriber_Profile.strIP_SM_GW_NUMBER
ipSmGwHost | \<String\> | Optional | Tm_Subscriber_Profile.strIP_SM_GW_HOST
ipSmGwRealm | \<String\> | Optional | Tm_Subscriber_Profile.strIP_SM_GW_REALM
smsRegistrationInfo | [\<SmsRegistrationInfo>\](../entities/smsregistrationinfo) | Optional | TM_SMS_REGISTRATION
networkAccessMode | \<int\> | Optional | Tm_Subscriber_Profile.nNetworkAccessMode
qosGprsId | \<int\> | Optional | Tm_Subscriber_Profile.NQOS_GRPS_ID
qosEpsId | \<int\> | Optional | Tm_Subscriber_Profile.NQOS_EPS_ID
accessRestrictionData | [\<AccessRestrictionData\>](../entities/accessrestrictiondata) | Optional | TM_SUBSCRIBER_PROFILE.NACCESSRESTRICTIONDATA
chargingCharacteristics | \<String\> | Optional | Tm_Gprs_Data.STRCHARGINGCHARACTERISTICS
imsSubscription | [\<ImsSubscription\>](../entities/imssubscription) | Optional | 
imsUserData | \<String\> | Optional | 		
roaming-scscf-info | [[\<RoamingScscfInfo\>](../entities/roamingscscfinfo)] | Optional |  		
aMsisdn | [\<String\>] | Optional | 
periodicLauTimer | \<int\> | Optional |  	
periodicRauTauTimer | \<int\> | Optional |  	
HSM_ID | \<int\> | Optional |  	
opc | \<String\> | Optional | 	
ueUsageType | \<Integer\> | Optional | 	
lastActivity | \<DateTime\>  |	Optional 		
SCA | \<String\>  |	Optional 		
category | \<int\> |	Optional  |		Tm_Subscriber_Profile.nCategory 
RSD      | [\<String\>] | Optional |
icsIndicator | \<int\> | Optional | | | TM_SUBSCRIBER_PROFILE.NICS_INDICATOR

### Example
```json
{
    "imsi":"250010000000001",
    "all":true
}
```




