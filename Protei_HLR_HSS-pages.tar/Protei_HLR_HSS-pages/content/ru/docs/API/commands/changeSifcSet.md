---
title : "ChangeSifcSet"
description : "Change Shared IFC Set"
weight : 4
---

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Action | \<String\> | Mandatory | | ["create","modify","delete"] | 
SIfcSet | [\<SIfcSet\>](../entities/sifcset) | Optional | | | TM_IMS_SIFC_SET


### Response

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
status | \<int\> | Mandatory | | | 

### Example
```json
{
    "Action":"create",
    "SIfcs":
    [
        {
            "Id":1,
            "Ifcs":
            [
                {
                    "Name":"ifc1",
                    "Priority":1,
                    "ApplicationServerName":"as",
                    "ProfilePartIndicator":1,
                    "TriggerPoint":
                    {
                        "ConditionTypeCNF":1,
                        "Spt":
                        [
                            {
                                "Group":1,
                                "Method":"INVITE",
                                "SessionCase":1,
                                "ConditionNegated":2,
                                "Type":3,
                                "RequestUri":"http://ims.protei.ru/spt1",
                                "Header":"header",
                                "Content":"headerContent",
                                "SdpLine":"sdpLine",
                                "SdpLineContent":"sdpLineContent",
                                "RegistrationType":1
                            }  
                        ]
                    }
                }
            ]
        }
    ]
}
```

