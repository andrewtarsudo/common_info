---
title : "GetRegionalZoneCodeIdentity"
description : "Получение сущности RegionalZoneCodeIdentity"
weight : 4
---

## endpoint: /ProfileService/GetRegionalZoneCodeIdentity

### Request

Element/Attribute | Type | Mandatory | Description 
:-----|:-----------------|------|------
name | \<String\> | Mandatory | 


### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
regional | [\<Regional\>](../entities/regional) | Mandatory |

### Example
```json
{   
    "name":"rus"
}
```

