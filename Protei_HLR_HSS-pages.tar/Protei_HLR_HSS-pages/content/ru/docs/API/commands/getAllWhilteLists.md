---
title : "GetAllWhiteLists"
description : "Получение всех белых списков"
weight : 4
---

## endpoint: /ProfileService/GetAllWhiteLists

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------


### Reply
Element/Attribute | Type | Mandatory | Description | DB
:-----|:-----------------|------|------|--------
status | \<int\> | Mandatory | The status of the request | 
whiteList | [[\<WhiteList\>](../entities/whitelist)] | Conditional | | TM_WHITELIST_VLR



### Example
```json
{}
```






