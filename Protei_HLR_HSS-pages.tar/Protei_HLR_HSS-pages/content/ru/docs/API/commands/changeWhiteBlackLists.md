---
title : "ChangeWhiteBlackLists"
description : "Упарвление белыми/черными списками"
weight : 4
---

## endpoint: /ProfileService/ChangeWhiteBlackLists

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
whiteList | [[\<WhiteList\>](../entities/whitelist)] | Optional | | TM_WHITELIST_VLR
blackList | [[\<BlackList\>](../entities/blacklist)] | Optional | | TM_BLACKLIST_VLR

### Reply
Element/Attribute | Type | Mandatory | Description | DB
:-----|:-----------------|------|------|--------
status | \<int\> | Mandatory | The status of the request | 


### Example
```json
{
    "whiteList":
    [
        {
            "action":"create",
            "id":1,
            "name":"wl_rus",
            "vlr_masks":
            [
                {
                "mask":"7911",
                "country":"rus",
                "network":"mts"
                },
                {
                "mask":"7921",
                "country":"rus",
                "network":"megafon"
                }
            ],
            "plmn_mask":
            [
                {
                "mask":"25001",
                "country":"rus",
                "network":"mts"
                },
                {
                "mask":"25002",
                "country":"rus",
                "network":"megafon"
                },
            ]
        }
    ]
}
```






