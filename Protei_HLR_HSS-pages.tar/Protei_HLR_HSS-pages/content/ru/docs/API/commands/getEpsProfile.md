---
title : "GetEpsProfile"
description : "Получение профиля EPS"
weight : 4
---

## endpoint: /ProfileService/GetEpsProfile

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
context-id | \<int\> | Mandatory ||| TM_DM_EPS_DATA.NEPS_CONTEXT_ID

### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
epsProfile | [\<EpsProfile\>](../entities/epsprofile) | Optional ||| TM_DM_EPS_DATA

### Example
```json
{
    "context-id":1
}
```



