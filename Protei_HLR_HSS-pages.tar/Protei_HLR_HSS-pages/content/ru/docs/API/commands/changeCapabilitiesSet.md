---
title : "ChangeCapabilitiesSet"
description : "Управление набором возможностей"
weight : 4
---

## endpoint: /ProfileService/ChangeCapabilitiesSet

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
Action | \<String\> | Mandatory | create/modify/delete
CapabilitiesSet | [\<CapabilitySet\>](../entities/capabilityset) | Mandatory | | | TM_IMS_CAPABILITIES_SET |


### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "Action":"create",
    "CapabilitiesSet":
    {
        "SetId":1,
        "Capabilities":
        [
            {
                "Code":1,
                "Mandatory":1
            },
            {
                "Code":2,
                "Mandatory":0
            }
        ]
    }
}
```

