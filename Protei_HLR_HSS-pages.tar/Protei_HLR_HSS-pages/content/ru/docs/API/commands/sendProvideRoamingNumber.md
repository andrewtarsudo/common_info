---
title : "SendProvideRoamingNumber"
description : "Запрос роамингового номера (используется для интеграции с внешними платформами)"
weight : 4
---

## endpoint: /SubscriberService/SendProvideRoamingNumber

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
imsi | \<String\> | Conditional | IMSI | | TM_SUBSCRIBER_PROFILE.STRIMSI
msisdn | \<String\>  | Conditional | MSISDN | | TM_SUBSCRIBER_PROFILE.STRMSISDN
gmscAddress | \<String\> | Mandatory | Адрес GMSC |  | 
callReferenceNumber | \<String\> | Mandatory |  | | 

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
msrn | \<String\> | Optional | MS Roaming Number

### Example
```json
{
    "imsi":"250010000001",
    "gmscAddress":"123456789",
    "callReferenceNumber":"9876543210"
}
```

