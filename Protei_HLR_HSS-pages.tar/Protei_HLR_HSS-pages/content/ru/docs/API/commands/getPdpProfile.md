---
title : "GetPdpProfile"
description : "Получение профиля PDP"
weight : 4
---

## endpoint: /ProfileService/GetPdpProfile

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
context-id | \<int\> | Mandatory || TM_PDP_DATA.NID | 

### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
pdpProfile | [\<PdpProfile\>](../entities/pdpprofile) | Mandatory ||| TM_PDP_DATA

### Example
```json
{
    "context-id":1
}
```




