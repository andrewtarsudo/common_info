---
title : "GetRoamigAgreement"
description : "Получение роаминговых соглашений о поколении CAMEL"
weight : 4
---

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
vlrMask | \<String\> | Mandatory | |  | TM_ROAMING_AGREEMENT.STRVLR


### Response

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
status | \<int\> | Mandatory | | | 
vlrs | [[\<RAVlr\>](../entities/ravlr)] | Mandatory | | | TM_ROAMING_AGREEMENT

### Example
```json
{
    "vlrMask":"7658"
}
```



