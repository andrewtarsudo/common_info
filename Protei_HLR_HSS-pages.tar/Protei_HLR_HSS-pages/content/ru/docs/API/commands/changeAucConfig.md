---
title : "ChangeAucConfig"
description : "Изменение параметров AuC"
weight : 4
---

## endpoint: /ProfileService/ChangeAucConfig

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
opParams | [[\<OpParam\>](../entities/opparam)] | Optional ||| TM_OP
tkParams | [[\<TkParam\>](../entities/tkparam)] | Optional ||| TM_TK
cParams | [[\<CParam\>](../entities/cparam)] | Optional ||| TM_AUC_C
rParams | [[\<RParam\>](../entities/rparam)] | Optional ||| TM_AUC_R


### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "opParams":
    [
        {
            "id":1,
            "op":"12345678900987654321123456789009"
        }
    ],
    "tkParams":
    [
        {
            "id":1,
            "tk":"12345678900987654321123456789009",
            "algorithm":0
        }
    ],
    "cParams":
    [
        {
            "id":1,
            "c":"123456789009"
        }
    ],
    "rParams":
    [
        {
            "id":1,
            "r":"123456789009"
        }
    ]
}
```

