---
title : "GetApplicationServer"
description : "Получение сервера приложений"
weight : 4
---

## endpoint: /ProfileService/GetAs

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
ServerName | \<String\> | Mandatory | | | TM_IMS_APPLICATION_SERVER.STRSERVER_NAME




### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
As | [\<ApplicationServer\>](../entities/applicationserver) | Mandatory | | 

### Example
```json
{
    "ServerName":"as"
}
```




