---
title : "SendCancelLocation"
description : "Отмена регистарции в сетях 2/3/4G"
weight : 4
---

## endpoint: /SubscriberService/SendCancelLocation

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
imsi | \<String\> | Conditional | IMSI | | TM_SUBSCRIBER_PROFILE.STRIMSI
msisdn | \<String\>  | Conditional | MSISDN | | TM_SUBSCRIBER_PROFILE.STRMSISDN
domain | \<String\> | Optional | Домен, в котором необходимо отменить регистрацию. Если не указан, отправится запрос по всем доменам | CS-(VLR), PS-(SGSN), EPS-(MME/SGSN4G) | 
reattachRequired | \<Boolean\> | Optional | Запрос перерегистрации | | 

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "imsi":"250010000001",
    "domain":"EPS",
    "reattachRequired":true
}
```
