---
title : "GetGroups"
description : "Получение групп"
weight : 4
---

## endpoint: /ProfileService/GetGroups

### Request

Element/Attribute | Type | Mandatory | Description | Values | Default
:-----------------|:-----|-----------|-------------|--------|---------
full | \<Boolean\> | Optional | Получить в ответе полный профиль групп | true/false | false |


### Reply
Element/Attribute | Type | Mandatory | DB
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request
groups | [[\<Group\>](../entities/group)] | Mandatory ||| TM_SUBSCRIBER_GROUP


### Example
```json
{
}
```

