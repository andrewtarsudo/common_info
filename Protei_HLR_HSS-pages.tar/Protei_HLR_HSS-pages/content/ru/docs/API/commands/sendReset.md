---
title : "SendReset"
description : "Оповещение VLE/SGSN/MME о том, что произошла аварийная перезагрузка"
weight : 4
---

## endpoint: /SubscriberService/SendReset

### Request

Element/Attribute | Type | Mandatory | Description | Values | DB
:-----------------|:-----|-----------|-------------|--------|-------
mmeSgsnMask | \<String\> |  Optional | Префикс имени MME/SGSN4G | | TM_ROAMING_SGSN.DM_STR_MMEHOST / TM_ROAMING_SGSN.DM_STR_SGSNHOST
vlrSgsnMask | \<String\>  | Optional | Префикс номера VLR/SGSN | | TM_ROAMING.STRVLR / TM_ROAMING_SGSN.STRSGSN
imsiPrefix | \<String\> | Conditional | Префикс IMSI, по которым необходимо сформировать запрос (не может быть использовано с prefixLength, groupIds или groupNames) | 
prefixLength | \<int\> | Conditional | Длина префикса IMSI. Все IMSI, по которым нужно будет отправить команду, буду сгруппированы по префиксу, который будет получен на основании длины (не может быть использовано с imsiPrefix, groupIds или groupNames) |
groupIds | [\<int\>] | Conditional | Список id групп, по которым нужно сформировать запрос (не может быть использовано с imsiPrefix, prefixLength или groupNames) |
groupNames | [\<String\>] | Conditional | Список имен групп, по которым нужно сформировать запрос (не может быть использовано с imsiPrefix, prefixLength или groupIds) |

### Reply
Element/Attribute | Type | Mandatory | Description
:-----|:-----------------|------|------
status | \<int\> | Mandatory | The status of the request

### Example
```json
{
    "vlrSgsnMask":"7697",
    "imsiPrefix":"25001"
}
```

