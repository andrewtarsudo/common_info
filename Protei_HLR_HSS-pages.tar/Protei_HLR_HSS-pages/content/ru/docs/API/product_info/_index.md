---
title : "История версий"
description : ""
weight : 1

---
#### 2.0.34.2 (2021-11-09)
[Скачать версию 2.0.34.2](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/318/artifact/hlr_ap.2.0.34.2.tar.gz)

##### Зависимость: HSS.2.2.67.16
[Mobile_HLR-714](https://youtrack.protei.ru/issue/Mobile_HLR-714)([1049897](https://portal.protei.ru/portal/#issues/issue:id=1049897)) ss-ErrorStatus (17) при установке переадресации с телефона
- Basic **Bug**, Заказчик: **Глобал Телеком**
- Добавлена проверка нахождения абонента в роаминге при выставления BIC_Roam (155)

#### 2.0.34.1 (2021-11-02)
[Скачать версию 2.0.34.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/316/artifact/hlr_ap.2.0.34.1.tar.gz)

[Mobile_HLR-728](https://youtrack.protei.ru/issue/Mobile_HLR-728)([1051208](https://portal.protei.ru/portal/#issues/issue:id=1051208)) Описать на гите удаление CSI из профиля абонента
- Basic **Freq**, Заказчик: **SIM Telecom**
- Изменен формат удаление CSI из профиля абонента

[Mobile_HLR-753](https://youtrack.protei.ru/issue/Mobile_HLR-753)([1055501](https://portal.protei.ru/portal/#issues/issue:id=1055501)) Дублируется информация в specificApns
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Добавлено удаление Specific-APN при CancelLocation/Purge/UpdateLocation (при смене VPLMN)

#### 2.0.34.0 (2021-10-28)
[Скачать версию 2.0.34.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/315/artifact/hlr_ap.2.0.34.0.tar.gz)

[Mobile_HLR-763](https://youtrack.protei.ru/issue/Mobile_HLR-763)([1057081](https://portal.protei.ru/portal/#issues/issue:id=1057081)) Добавить csi-list в profiles.json
- Basic **Freq**, Заказчик: **SIM Telecom**
- Добавлена возможность задавать csi-list в profiles.json

#### 2.0.33.11 (2021-10-19)
[Скачать версию 2.0.33.11](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/314/artifact/hlr_ap.2.0.33.11.tar.gz)

##### Зависимость: HSS.2.2.67.13
[Mobile_HLR-700](https://youtrack.protei.ru/issue/Mobile_HLR-700)([1048101](https://portal.protei.ru/portal/#issues/issue:id=1048101),[1050689](https://portal.protei.ru/portal/#issues/issue:id=1050689),[1056254](https://portal.protei.ru/portal/#issues/issue:id=1056254)) Ошибка при выполнении changeImsi HLR.FK_EIR
- Basic **Bug**, Заказчик: **SIM Telecom**
- Добавлено удаление связки IMEI - New IMSI

[Mobile_HLR-755](https://youtrack.protei.ru/issue/Mobile_HLR-755) Рассмотреть ответ на PUR
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Исправлена ошибка в парсинге ShData

[Mobile_HLR-758](https://youtrack.protei.ru/issue/Mobile_HLR-758)([1049157](https://portal.protei.ru/portal/#issues/issue:id=1049157)) You have an error in your SQL syntax
- Basic **Bug**, Заказчик: **Samantel**
- Добавлена проверка наличия параметров в команде на обновление связки с EPS контекстом

[Mobile_HLR-759](https://youtrack.protei.ru/issue/Mobile_HLR-759) Реализовать удаление подписок после получения на PNR ответа с кодом 5001
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлено удаление всех подписок для конкретного AS

#### 2.0.33.9 (2021-09-28)
[Скачать версию 2.0.33.9](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/313/artifact/hlr_ap.2.0.33.9.tar.gz)

[Mobile_HLR-747](https://youtrack.protei.ru/issue/Mobile_HLR-747) operator-communication-waiting отсутствует calling-user-receives-notification-his-call-is-waiting
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлено значение по умолчанию для параметра calling-user-receives-notification-his-call-is-waiting

#### 2.0.33.8 (2021-09-21)
[Скачать версию 2.0.33.8](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/312/artifact/hlr_ap.2.0.33.8.tar.gz)

[Mobile_HLR-745](https://youtrack.protei.ru/issue/Mobile_HLR-745)([1054370](https://portal.protei.ru/portal/#issues/issue:id=1054370)) Установка переадресации с ss_status=3
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Исправлена ошибка в управлении SS-Forwarding-Data

#### 2.0.33.7 (2021-09-20)
[Скачать версию 2.0.33.7](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/311/artifact/hlr_ap.2.0.33.7.tar.gz)

[Mobile_HLR-752](https://youtrack.protei.ru/issue/Mobile_HLR-752) HSS в ответ на UDR, в котором запрашивается MSISDN и impl set, отвечает UDA только с MSISDN
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Исправлена проблема формирования ShUserData с MSISDN и IMSPublicIdentity

#### 2.0.33.6 (2021-09-20)
[Скачать версию 2.0.33.6](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/310/artifact/hlr_ap.2.0.33.6.tar.gz)

[Mobile_HLR-698](https://youtrack.protei.ru/issue/Mobile_HLR-698) Добавить поддержку TUAK в HSS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Изменен размер столбца TM_AUC.STRKI

[Mobile_HLR-748](https://youtrack.protei.ru/issue/Mobile_HLR-748)([1053973](https://portal.protei.ru/portal/#issues/issue:id=1053973)) Всегда выдавать TADSinformation при запросе
- Basic **Freq**, Заказчик: **Esmero**
- Добавлено заполнение IMSVoiceOverPSSessionSupport значением 0, если отсутствует регистрация в EPS

#### 2.0.33.5 (2021-09-17)
[Скачать версию 2.0.33.5](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/309/artifact/hlr_ap.2.0.33.5.tar.gz)

[Mobile_HLR-749](https://youtrack.protei.ru/issue/Mobile_HLR-749)([1053263](https://portal.protei.ru/portal/#issues/issue:id=1053263)) Заполнение TM_ODB.NGENERAL
- Basic **Bug**, Заказчик: **ОАО "Воентелеком"**
- Исправлен триггер заполнения TM_ODB.NGENERAL

#### 2.0.33.4 (2021-09-02)
[Скачать версию 2.0.33.4](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/308/artifact/hlr_ap.2.0.33.4.tar.gz)

[Mobile_HLR-746](https://youtrack.protei.ru/issue/Mobile_HLR-746)([1054698](https://portal.protei.ru/portal/#issues/issue:id=1054698)) Эксепшн на `ProfileControl` после добавления IMS профиля абоненту
- Basic **Bug**, Заказчик: **Esmero**
- Добавлена проверка наличия ServiceProfile при добавлении IMPU

#### 2.0.33.3 (2021-08-23)
[Скачать версию 2.0.33.3](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/307/artifact/hlr_ap.2.0.33.3.tar.gz)

[Mobile_HLR-743](https://youtrack.protei.ru/issue/Mobile_HLR-743) Поддержка совместимости с API.1.1
- Basic **Bug**, Заказчик: **НТЦ Протей**

[Mobile_HLR-741](https://youtrack.protei.ru/issue/Mobile_HLR-741) Включать Temporary Public Identity в PPR
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлено включение Temporary Public Identity в PPR

#### 2.0.33.2 (2021-07-27)
[Скачать версию 2.0.33.2](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/306/artifact/hlr_ap.2.0.33.2.tar.gz)

[Mobile_HLR-691](https://youtrack.protei.ru/issue/Mobile_HLR-691) Управление SMSInformation через Sh
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Доделана выдача адреса SMSC пользователя на IP-SM-GW

[Mobile_HLR-706](https://youtrack.protei.ru/issue/Mobile_HLR-706) Не создается ims профиль через ProfileControl
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Исправлена ошибка добавление IMS подписки без имени.

[Mobile_HLR-729](https://youtrack.protei.ru/issue/Mobile_HLR-729)([1051208](https://portal.protei.ru/portal/#issues/issue:id=1051208)) ORA-00904: "wr": invalid identifier
- Basic **Bug**, Заказчик: **SIM Telecom**
- Исправлены синтаксические ошибки в формировании Oracle запроса.

[Mobile_HLR-730](https://youtrack.protei.ru/issue/Mobile_HLR-730)([1052669](https://portal.protei.ru/portal/#issues/issue:id=1052669)) Отдавать GT IPSMGW в ответе на SRI4SM, если абонент не зарегистрирован
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Добавлена проверка наличия статического номера IP-SM-GW

[Mobile_HLR-731](https://youtrack.protei.ru/issue/Mobile_HLR-731)([1049157](https://portal.protei.ru/portal/#issues/issue:id=1049157)) Пустые строки STRSTATIC_IP4 STRSTATIC_IP6 STRPLMN_ID
- Basic **Bug**, Заказчик: **Samantel**
- Исправлено сохранение в параметров в БД

[Mobile_HLR-732](https://youtrack.protei.ru/issue/Mobile_HLR-732)([1052526](https://portal.protei.ru/portal/#issues/issue:id=1052526)) OP and OPC должны быть опциональными, если задан HSM_ID
- Basic **Bug**, Заказчик: **ОАО "Воентелеком"**
- Параметры OP и OPC сделаны опциональными

#### 2.0.33.1 (2021-07-02)
[Скачать версию 2.0.33.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/305/artifact/hlr_ap.2.0.33.1.tar.gz)

[Mobile_HLR-727](https://youtrack.protei.ru/issue/Mobile_HLR-727)([1051872](https://portal.protei.ru/portal/#issues/issue:id=1051872)) Не отправили DSD после удаления CLIR
- Basic **Bug**, Заказчик: **ЗАО "Админора"**
- Исправлена ошибка формирования DSD

#### 2.0.33.0 (2021-07-02)
[Скачать версию 2.0.33.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/304/artifact/hlr_ap.2.0.33.0.tar.gz)

[Mobile_HLR-720](https://youtrack.protei.ru/issue/Mobile_HLR-720)([1051208](https://portal.protei.ru/portal/#issues/issue:id=1051208)) Ограничить M-CSI для разных сетей
- Basic **Freq**, Заказчик: **SIM Telecom**
- Добавлена выборка M-CSI по GT VLR

#### 2.0.32.10 (2021-07-02)
[Скачать версию 2.0.32.10](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/303/artifact/hlr_ap.2.0.32.10.tar.gz)

[Mobile_HLR-706](https://youtrack.protei.ru/issue/Mobile_HLR-706) Не создается ims профиль через ProfileControl
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена возможность создавать IMS подписку при добавлении IMS профиля абонента

[Mobile_HLR-726](https://youtrack.protei.ru/issue/Mobile_HLR-726)([1051601](https://portal.protei.ru/portal/#issues/issue:id=1051601)) PERMISSION_DENIED при ADD_SUBSCRIBER
- Important **Bug**, Заказчик: **Esmero**
- Добавлен патч для смены прав с RW на RWADE

#### 2.0.32.9 (2021-06-28)
[Скачать версию 2.0.32.9](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/302/artifact/hlr_ap.2.0.32.9.tar.gz)

##### Зависимость: HSS.2.2.67.8
[Mobile_HLR-721](https://youtrack.protei.ru/issue/Mobile_HLR-721)([1047018](https://portal.protei.ru/portal/#issues/issue:id=1047018)) Для карты с аутентификацией в HSM IMS векторы рассчитываются на самом HSS
- Important **Bug**, Заказчик: **НТЦ Протей**
- Добавлена передача hsmId в ответ на запрос аутентификационных данных

[Mobile_HLR-723](https://youtrack.protei.ru/issue/Mobile_HLR-723)([1051589](https://portal.protei.ru/portal/#issues/issue:id=1051589)) Ошибка селекта из БД при `ProfileControl`
- Critical **Bug**, Заказчик: **Esmero**
- Добавлена проверка наличия IMPU в базе, при добавлении новых IMPU

#### 2.0.32.8 (2021-06-08)
[Скачать версию 2.0.32.8](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/301/artifact/hlr_ap.2.0.32.8.tar.gz)

[Mobile_HLR-700](https://youtrack.protei.ru/issue/Mobile_HLR-700)([1048101](https://portal.protei.ru/portal/#issues/issue:id=1048101),[1050689](https://portal.protei.ru/portal/#issues/issue:id=1050689)) Ошибка при выполнении changeImsi HLR.FK_EIR
- Basic **Bug**, Заказчик: **SIM Telecom**
- Исправлена ошибка при работе с Oracle

#### 2.0.32.7 (2021-06-01)
[Скачать версию 2.0.32.7](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/300/artifact/hlr_ap.2.0.32.7.tar.gz)

[Mobile_HLR-713](https://youtrack.protei.ru/issue/Mobile_HLR-713) Запретить выставлять переадресацию на собственный номер симки
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена проверка forwardingToNumber

#### 2.0.32.6 (2021-05-20)
[Скачать версию 2.0.32.6](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/299/artifact/hlr_ap.2.0.32.6.tar.gz)

[Mobile_HLR-709](https://youtrack.protei.ru/issue/Mobile_HLR-709)([1049635](https://portal.protei.ru/portal/#issues/issue:id=1049635)) Выставляем статус 5 для переадресации, если activateSS приходит без него
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Сделана установка статуса 7 для переадресаций в рамках activateSS

#### 2.0.32.5 (2021-05-19)
[Скачать версию 2.0.32.5](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/298/artifact/hlr_ap.2.0.32.5.tar.gz)

[Mobile_HLR-707](https://youtrack.protei.ru/issue/Mobile_HLR-707)([1049157](https://newportal.protei.ru/portal/#issues/issue:id=1049157)) Ошибка 500 Internal Server Error в ответе на /ProfileService/GetProfile
- Basic **Bug**, Заказчик: **Samantel**
- Исправлена ошибка при формировании ответа на ChangeEPS

#### 2.0.32.4 (2021-05-18)
[Скачать версию 2.0.32.4](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/297/artifact/hlr_ap.2.0.32.4.tar.gz)

[Mobile_HLR-710](https://youtrack.protei.ru/issue/Mobile_HLR-710)([1049644](https://portal.protei.ru/portal/#issues/issue:id=1049644)) Не отправили TEL URI IMPU в Cx SAA
- Important **Bug**, Заказчик: **Esmero**
- Исправлена выборка IMPU на шаге DownloadProfile

#### 2.0.32.3 (2021-05-07)
[Скачать версию 2.0.32.3](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/296/artifact/hlr_ap.2.0.32.3.tar.gz)

[Mobile_HLR-705](https://youtrack.protei.ru/issue/Mobile_HLR-705)([1048255](https://newportal.protei.ru/portal/#issues/issue:id=1048255)) Дублируется mCsi-list в GetProfile
- Basic **Bug**, Заказчик: **ООО "Центр 2М"**
- Исправлено формирование json для GetProfileResponse

#### 2.0.32.2 (2021-04-30)
[Скачать версию 2.0.32.2](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/295/artifact/hlr_ap.2.0.32.2.tar.gz)

[Mobile_HLR-701](https://youtrack.protei.ru/issue/Mobile_HLR-701)([1048451](https://newportal.protei.ru/portal/#issues/issue:id=1048451)) Не отправляется ISD на SGSN при Change_MSISDN
- Basic **Bug**, Заказчик: **ООО "Центр 2М"**
- Добавлена отправка ISD на SGSN при смене MSISDN

#### 2.0.32.1 (2021-04-19)
[Скачать версию 2.0.32.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/294/artifact/hlr_ap.2.0.32.1.tar.gz)

[Mobile_HLR-700](https://youtrack.protei.ru/issue/Mobile_HLR-700)([1048101](https://newportal.protei.ru/portal/#issues/issue:id=1048101)) Ошибка при выполнении changeImsi HLR.FK_EIR
- Basic **Bug**, Заказчик: **SIM Telecom**
- Добавлено удаление связки imsi-imei при смене imsi

#### 2.0.32.0 (2021-04-13)
[Скачать версию 2.0.32.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/293/artifact/hlr_ap.2.0.32.0.tar.gz)

[Mobile_HLR-697](https://youtrack.protei.ru/issue/Mobile_HLR-697) Не заполняются MSISDN и IMSI в operation_journal
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлены недостающие параметры в CDR

[Mobile_HLR-698](https://youtrack.protei.ru/issue/Mobile_HLR-698) Добавить поддержку TUAK в HSS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлены параметры для TUAK в команду добавления абонента

[Mobile_HLR-699](https://youtrack.protei.ru/issue/Mobile_HLR-699)([1048077](https://portal.protei.ru/portal/#issues/issue:id=1048077)) На Notify ответ 5012
- Basic **Bug**, Заказчик: **ОАО "Воентелеком"**
- Убрана проверка значения PDN-GW-Allocated-Type из базы, так как роль этого параметра указать MME, каким образом был назначен PGW

#### 2.0.31.0 (2021-03-24)
[Скачать версию 2.0.31.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/292/artifact/hlr_ap.2.0.31.0.tar.gz)

##### Зависимость: HSS.2.2.66.0
[Mobile_HLR-663](https://youtrack.protei.ru/issue/Mobile_HLR-663) Запрос GetUserLocation с msisdn
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Изменена проверка наличия imsi в запросе

[Mobile_HLR-684](https://youtrack.protei.ru/issue/Mobile_HLR-684) После тестов c изменением статуса IMPU, находящегося в impl set и на который подписан AS, перестают обрабатыватьcя API команды для этого impl set
- Basic **Task**, Заказчик: **НТЦ Протей**
- Добавлена проверка не наличие подписки AS

[Mobile_HLR-686](https://youtrack.protei.ru/issue/Mobile_HLR-686) HSS не возвращает Restoration Info, если она запрашивается по barred IMPU
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Убрано ограничение на регистрацию Barred IMPU

[Mobile_HLR-688](https://youtrack.protei.ru/issue/Mobile_HLR-688) HSS отправляет RTR User-Name AVP и Public-Identity AVP, если в API команде указать только IMPI
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Убран поиск зарегистрированных IMPU, если в SendRegistrationTermination IMPU не был явно указан

[Mobile_HLR-690](https://youtrack.protei.ru/issue/Mobile_HLR-690) Добавить поддержку Profile-Update-Request с Data-Reference STN-SR
- Important **Freq**, Заказчик: **НТЦ Протей**
- Переделана логика управления ShUserData

[Mobile_HLR-691](https://youtrack.protei.ru/issue/Mobile_HLR-691) Управление SMSInformation через Sh
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлено управление SMSInformation через Sh. Добавлена таблица TM_SMS_REGISTRATION, для хранения информации о IP-SM-GW

[Mobile_HLR-693](https://youtrack.protei.ru/issue/Mobile_HLR-693)([1047031](https://portal.protei.ru/portal/#issues/issue:id=1047031)) Отбиваются UL из-за переполнения значений NID.TM_MS_STATUS_DATA
- Critical **Bug**, Заказчик: **Телематика**
- Убрано использование таблица TM_MS_STATUS_DATA, ее содержимое дублирует TM_ROAMING

#### 2.0.30.1 (2021-03-02)
[Скачать версию 2.0.30.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/291/artifact/hlr_ap.2.0.30.1.tar.gz)

[Mobile_HLR-679](https://youtrack.protei.ru/issue/Mobile_HLR-679)([1041153](https://newportal.protei.ru/portal/#issues/issue:id=1041153)) Не отправляется ISD/DSD при добавлении/снятии Access Restriction Data через API
- Basic **Bug**, Заказчик: **Телематика**
- Исправлена потеря VLR-Number

#### 2.0.30.0 (2021-03-01)
[Скачать версию 2.0.30.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/290/artifact/hlr_ap.2.0.30.0.tar.gz)

##### Зависимость: HSS.2.2.65.0
[Mobile_HLR-677](https://youtrack.protei.ru/issue/Mobile_HLR-677) Запрос UDR с Data-Reference-List: CSRN и TADSinformation отбивается при отсутствии User-Name AVP
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена команда для проверки ims идентификации и поиску регистрации в сетях umts/lte

[Mobile_HLR-679](https://youtrack.protei.ru/issue/Mobile_HLR-679)([1041153](https://newportal.protei.ru/portal/#issues/issue:id=1041153)) Не отправляется ISD/DSD при добавлении/снятии Access Restriction Data через API
- Basic **Bug**, Заказчик: **Телематика**
- Добавлено заполнение ARD при формировании ISD VLR

[Mobile_HLR-680](https://youtrack.protei.ru/issue/Mobile_HLR-680)([1045482](https://portal.protei.ru/portal/#issues/issue:id=1045482)) Отправка нулей вместо IMSI в returnResultLast sendIMSI
- Basic **Bug**, Заказчик: **Телематика**
- Исправлено формирование ответа на GetIMSI

[Mobile_HLR-681](https://youtrack.protei.ru/issue/Mobile_HLR-681)([1044785](https://newportal.protei.ru/portal/#issues/issue:id=1044785)) GetProfile: вывод названия IFC привязанного к AS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлен вывод имени IFC

[Mobile_HLR-682](https://youtrack.protei.ru/issue/Mobile_HLR-682) При удалении IMS Subscription не удаляются IMPU, которые в него входили
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлен внешний ключ в таблицу TM_IMPLICITLY_REGISTERED_SET

[Mobile_HLR-685](https://youtrack.protei.ru/issue/Mobile_HLR-685) Добавить поддержку параметра ICS-Indicator
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлен столбец TM_SUBSCRIBER_PROFILE.NICS_INDICATOR и управление им

#### 2.0.29.3 (2021-02-12)
[Скачать версию 2.0.29.3](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/289/artifact/hlr_ap.2.0.29.3.tar.gz)

[Mobile_HLR-673](https://youtrack.protei.ru/issue/Mobile_HLR-673) Не отправляется Push-Profile-Request при добавлении/удалении IMPU
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена неявная регистрация нового IMPU, если на момент добавления у абонента была регистрация

#### 2.0.29.2 (2021-02-11)
[Скачать версию 2.0.29.2](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/288/artifact/hlr_ap.2.0.29.2.tar.gz)

[Mobile_HLR-675](https://youtrack.protei.ru/issue/Mobile_HLR-675)([1044689](https://newportal.protei.ru/portal/#issues/issue:id=1044689)) Отправка CL в сторону MME после ранее полученного успешного Purge-UE
- Basic **Bug**, Заказчик: **Телематика**
- Добавлен анализ флага Purge

#### 2.0.29.1 (2021-02-05)
[Скачать версию 2.0.29.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/287/artifact/hlr_ap.2.0.29.1.tar.gz)

[Mobile_HLR-670](https://youtrack.protei.ru/issue/Mobile_HLR-670)([1042728](https://newportal.protei.ru/portal/#issues/issue:id=1042728)) После обновления HLR_API перестал работать get_profile с указанием MSISDN
- Important **Bug**, Заказчик: **SIM Telecom**
- Изменена валидация запроса GetProfile, imsi:"" считается допустимым значением эквивалентным imsi:null

[Mobile_HLR-671](https://youtrack.protei.ru/issue/Mobile_HLR-671)([1042728](https://newportal.protei.ru/portal/#issues/issue:id=1042728)) В ответ на Notify отвечаем unable to comply
- Important **Bug**, Заказчик: **SIM Telecom**
- Исправлено сохранение динамически назначенных PGW

#### 2.0.29.0 (2021-01-20)
[Скачать версию 2.0.29.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/286/artifact/hlr_ap.2.0.29.0.tar.gz)

[Mobile_HLR-660](https://youtrack.protei.ru/issue/Mobile_HLR-660) Адаптация API под HSS WEB TO
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлен столбец STRNAME в TM_QOS_GPRS, TM_QOS_EPS, TM_DM_EPS_DATA, TM_PDP_DATA. Расширен формат управления ODB.Добавлена команда GetProfileBatch (/ProfileService/GetProfileBatch) для получения списка профилей

[Mobile_HLR-661](https://youtrack.protei.ru/issue/Mobile_HLR-661) Добавить ошибку к статусу при неудачном HTTP запросе GetUserLocation
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена проверка SupportedFeatures на стороне API. Добавлено поле errorMessage в HLRResult.

[Mobile_HLR-665](https://youtrack.protei.ru/issue/Mobile_HLR-665) AlertSC после ATM
- Basic **Bug**, Заказчик: **ООО ИК "Сибинтек"**
- Добавлено снятие флага MNRF при активации SCF

#### 2.0.28.1 (2021-01-11)
[Скачать версию 2.0.28.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/284/artifact/hlr_ap.2.0.28.1.tar.gz)

[Mobile_HLR-649](https://youtrack.protei.ru/issue/Mobile_HLR-649) Реализовать механизм обработки Active-APN и Specific-APN
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Исправлен патч Liquibase (Oracle)

#### 2.0.28.0 (2020-12-24)
[Скачать версию 2.0.28.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/283/artifact/hlr_ap.2.0.28.0.tar.gz)

##### Зависимость: HSS.2.2.63.0
[Mobile_HLR-536](https://youtrack.protei.ru/issue/Mobile_HLR-536) ISD на получение EPS User State and/or EPS Location Information
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Исправлена ошибка именования параметра

[Mobile_HLR-649](https://youtrack.protei.ru/issue/Mobile_HLR-649) Реализовать механизм обработки Active-APN и Specific-APN
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлено сохранение Specific-APN при регистрации на MME/SGSN4G

[Mobile_HLR-650](https://youtrack.protei.ru/issue/Mobile_HLR-650) Подписка на IMSPublicIdentity
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена подписка ASов на IMSPublicIdentity + форирование PNR

[Mobile_HLR-651](https://youtrack.protei.ru/issue/Mobile_HLR-651) Изменение ServiceProfile в changeProfile
- Basic **Freq**
- Добавлено изенение ServiceProfile + формирование PPR

[Mobile_HLR-647](https://youtrack.protei.ru/issue/Mobile_HLR-647) Добавить команду на получение конфигурации jdbc
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена обработка конфига с использованием ConnectionData. Изменен формат ответа.

[Mobile_HLR-658](https://youtrack.protei.ru/issue/Mobile_HLR-658) Получение списка доступных групп
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена команда на получение списка групп (/ProfileService/GetGroups)

#### 2.0.27.0 (2020-11-23)
[Скачать версию 2.0.27.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/282/artifact/hlr_ap.2.0.27.0.tar.gz)

[Mobile_HLR-647](https://youtrack.protei.ru/issue/Mobile_HLR-647) Добавить команду на получение конфигурации jdbc
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена команда на получение параметров из jdbc конифгурации (/InternalService/GetJdbcConfig)

#### [2.0.26.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/281/artifact/hlr_ap.2.0.26.1.tar.gz) (2020-11-03)
[Mobile_HLR-642](https://youtrack.protei.ru/issue/Mobile_HLR-642)([1039602](https://newportal.protei.ru/portal/#issues/issue:id=1039602)) Отправлять параметр Roaming Restricted In SGSN, если ODB с ПД не поддерживается SGSN
- Basic **Freq**, Заказчик: **ООО "Центр 2М"**
- Исправлено формирование ISD SGSN при изменении ODB

#### [2.0.26.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/280/artifact/hlr_ap.2.0.26.0.tar.gz) (2020-10-27)
[Mobile_HLR-559](https://youtrack.protei.ru/issue/Mobile_HLR-559) RegionalSubscription (,active)
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- RegionalSubscriptionДобавлена сущность Network, которая содержит RegionalZoneCodeIdentity

[Mobile_HLR-610](https://youtrack.protei.ru/issue/Mobile_HLR-610)([1037066](https://newportal.protei.ru/portal/#issues/issue:id=1037066)) Изменение TM_SUBSCRIBER_PROFILE.NCATEGORY через API
- Basic **Freq**, Заказчик: **ОАО "Воентелеком"**
- Исправлена ошибка в sql-запросе

[Mobile_HLR-607](https://youtrack.protei.ru/issue/Mobile_HLR-607)([1036786](https://newportal.protei.ru/portal/#issues/issue:id=1036786)) Ошибка reportSM-DeliveryStatus
- Basic **Bug**, Заказчик: **SIM Telecom**
- Исправлено формирование ErrorResponse

[Mobile_HLR-624](https://youtrack.protei.ru/issue/Mobile_HLR-624)([1037462](https://newportal.protei.ru/portal/#issues/issue:id=1037462)) Не выводится переменная congestion_status на одном API
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Пересобрано с winter.core.3.0.46

[Mobile_HLR-638](https://youtrack.protei.ru/issue/Mobile_HLR-638)([1038948](https://newportal.protei.ru/portal/#issues/issue:id=1038948)) Ошибки на API
- Important **Bug**, Заказчик: **Телематика**
- Изменен тип параметра ChangeAUCDataRequest.SQN (Integer -> Long)

[Mobile_HLR-639](https://youtrack.protei.ru/issue/Mobile_HLR-639) При смене qosGprsId отправляется пустой ISD в сторону VLR
- Basic **Bug**, Заказчик: **Телематика**
- Добавлена проверка измененных параметров профиля абонента при выборе направления при отправке ISD

[Mobile_HLR-640](https://youtrack.protei.ru/issue/Mobile_HLR-640)([1039491](https://newportal.protei.ru/portal/#issues/issue:id=1039491)) После получения ATI отправляется пустой ISD в сторону MME который ранее присылал Purge
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Исправлен парсинг запроса на PurgeUE. Исправлена ошибка сравнения Integer и Long.

#### [2.0.25.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/279/artifact/hlr_ap.2.0.25.1.tar.gz) (2020-09-30)
[Mobile_HLR-630](https://youtrack.protei.ru/issue/Mobile_HLR-630)([1038085](https://newportal.protei.ru/portal/#issues/issue:id=1038085)) (,30m) Добавить на API команду для обнуления хранимых в памяти данных
- Basic **Task**, Заказчик: **Телематика**
- Исправлена обработка параметра "all"

#### [2.0.25.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/277/artifact/hlr_ap.2.0.25.0.tar.gz) (2020-09-30)
[Mobile_HLR-600](https://youtrack.protei.ru/issue/Mobile_HLR-600)([1032784](https://newportal.protei.ru/portal/#issues/issue:id=1032784)) Косметика патчей 2.0.0.0
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена проверка перед удалением некоторых индексов.

[Mobile_HLR-622](https://youtrack.protei.ru/issue/Mobile_HLR-622) Ошибки No free threads на HLR API.
- Important **Task**, Заказчик: **Телематика**
- Произведена оптимизация API

[Mobile_HLR-627](https://youtrack.protei.ru/issue/Mobile_HLR-627)([1037066](https://newportal.protei.ru/portal/#issues/issue:id=1037066)) Формат NCATEGORY
- Basic **Task**, Заказчик: **ОАО "Воентелеком"**
- Изменен формат столбца TM_SUBSCRIBER_PROFILE.NCATEGORY на TINYINT UNSIGNED

[Mobile_HLR-628](https://youtrack.protei.ru/issue/Mobile_HLR-628) Для GPRS UL убрать запросы в БД CAMEL и Bearer services
- Basic **Task**, Заказчик: **Телематика**

[Mobile_HLR-629](https://youtrack.protei.ru/issue/Mobile_HLR-629) Оптимизация запросов в БД для UL
- Basic **Task**, Заказчик: **Телематика**
- Добавлено поле NFEATURES в TM_CONFIG, которое представляет из себя bitset поддерживаемых сервисов.

[Mobile_HLR-630](https://youtrack.protei.ru/issue/Mobile_HLR-630)([1038085](https://newportal.protei.ru/portal/#issues/issue:id=1038085)) Добавить на API команду для обнуления хранимых в памяти данных
- Basic **Task**, Заказчик: **Телематика**
- endpoint: /ProfileService/ResetProfilesInMemory. Формат команды описан на wiki.

#### [2.0.24.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/276/artifact/hlr_ap.2.0.24.1.tar.gz) (2020-09-16)
[Mobile_HLR-613](https://youtrack.protei.ru/issue/Mobile_HLR-613) Сохранение посчитанного OPC в БД
- Basic **Freq**, Заказчик: **Телематика**
- Исправление патчей liquibase

#### [2.0.24.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/275/artifact/hlr_ap.2.0.24.0.tar.gz) (2020-09-10)
##### Зависимость: HSS.2.2.60.0
[Mobile_HLR-606](https://youtrack.protei.ru/issue/Mobile_HLR-606)([1036326](https://newportal.protei.ru/portal/#issues/issue:id=1036326)) Не подставляем str_realm из subscriber group для Notify
- Basic **Bug**, Заказчик: **Top Connect**
- Добавлена информация о группе при спешном выполнении команды setSd (after NOR)

[Mobile_HLR-612](https://youtrack.protei.ru/issue/Mobile_HLR-612) Считывать настройки из TM_Config при запуске HLR_API или изменении настроек
- Basic **Freq**, Заказчик: **Телематика**
- Реализована сохранение конфига в памяти. Реализовано сохранения в памяти параметров AuC: OP, C, R, TK.

[Mobile_HLR-613](https://youtrack.protei.ru/issue/Mobile_HLR-613) Сохранение посчитанного OPC в БД
- Basic **Freq**, Заказчик: **Телематика**
- Добавлена команда для сохранения OPc. Добавлена команда по управлению AUC.OP, AUC.TK, AUC.C, AUC.R

[Mobile_HLR-623](https://youtrack.protei.ru/issue/Mobile_HLR-623) Хранение в памяти параметров, которые необходимы для генерации векторов аутентификации
- Basic **Freq**, Заказчик: **Телематика**
- Реализовано сохранения в памяти параметров AuC: OP, C, R, TK.

#### [2.0.23.4](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/274/artifact/hlr_ap.2.0.23.4.tar.gz) (2020-09-03)
[Mobile_HLR-606](https://youtrack.protei.ru/issue/Mobile_HLR-606)([1036326](https://newportal.protei.ru/portal/#issues/issue:id=1036326)) Не подставляем str_realm из subscriber group для Notify
- Basic **Bug**, Заказчик: **Top Connect**
- Добавлена информация о группе при формировании команд DIAM IDR/DSR/CL

[Mobile_HLR-609](https://youtrack.protei.ru/issue/Mobile_HLR-609)([1037123](https://newportal.protei.ru/portal/#issues/issue:id=1037123)) Включаем в профиль PDN-GW-Allocation-Type =0 при tm_dm_eps_data.tm_dm_eps_data=NULL в БД
- Basic **Bug**, Заказчик: **SIM Telecom**
- Убрано значение по умолчанию для параметра PDN-GW-Allocation-Type

[Mobile_HLR-610](https://youtrack.protei.ru/issue/Mobile_HLR-610)([1037066](https://newportal.protei.ru/portal/#issues/issue:id=1037066)) Изменение TM_SUBSCRIBER_PROFILE.NCATEGORY через API
- Basic **Freq**, Заказчик: **ОАО "Воентелеком"**
- Добавлено управление параметром category в команды AddSubscriber, ChangeProfile, GetProfile

#### [2.0.23.3](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/272/artifact/hlr_ap.2.0.23.3.tar.gz) (2020-08-31)
[Mobile_HLR-611](https://youtrack.protei.ru/issue/Mobile_HLR-611) Дедлоки на таблиция
- Basic **Bug**, Заказчик: **Телематика**
- Изменены индексы в таблицах TM_PROVISIONED_SS_BS, TM_TELESERVICE и запросы к таблице TM_DM_SUBSCRIBER_EPS_CONTEXT

#### [2.0.23.2](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/271/artifact/hlr_ap.2.0.23.2.tar.gz) (2020-08-13)
[Mobile_HLR-605](https://youtrack.protei.ru/issue/Mobile_HLR-605)([1033264](https://newportal.protei.ru/portal/#issues/issue:id=1033264)) Не добавить IMS профиль с IMS Subscription
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Исправлено добавление ims-части к уже имеющимся абонентам

#### [2.0.23.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/270/artifact/hlr_ap.2.0.23.1.tar.gz) (2020-08-03)
[Mobile_HLR-601](https://youtrack.protei.ru/issue/Mobile_HLR-601)([1032784](https://newportal.protei.ru/portal/#issues/issue:id=1032784)) Почистить warning.log
- Basic **Bug**, Заказчик: **SIM Telecom**
- Исправлено формирование PDA ответа с ошибкой

#### [2.0.23.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/269/artifact/hlr_ap.2.0.23.0.tar.gz) (2020-07-28)
##### Зависимость: HSS.2.2.59.0
[Mobile_HLR-535](https://youtrack.protei.ru/issue/Mobile_HLR-535) ISD на получение статуса доступности UE
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена проверка регистрации абонента на MME/SGSN по команде SubscribeForUeReachability

[Mobile_HLR-597](https://youtrack.protei.ru/issue/Mobile_HLR-597) При обновлении Service-Profile'а в PPR'е в User-Data приходит только один Service-Profile, хотя должен приходить весь набор для ImpRegSet'а
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Исправлено формирование PPR

#### [2.0.22.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/268/artifact/hlr_ap.2.0.22.0.tar.gz) (2020-07-28)
##### Зависимость: HSS.2.2.58.0
[Mobile_HLR-551](https://youtrack.protei.ru/issue/Mobile_HLR-551)([1035527](https://newportal.protei.ru/portal/#issues/issue:id=1035527)) Поддержка сообщения MAP-ANY-TIME Modification в интерфейсе с HSS Italtel
- Basic **Freq**, Заказчик: **Italtel Rus**
- Добавлены команды между HLR.API и HSS Iteltel (Обновление IP-SM-GW,Запрос MME Address, Подписка на доступность польщователя)

[Mobile_HLR-587](https://youtrack.protei.ru/issue/Mobile_HLR-587) Добавить dtregistered и state в roaming-scscf-info
- Basic **Freq**, Заказчик: **Esmero**
- Добавлен столбец DTREGISTERED в TM_IMS_ROAMING_SCSCF. Добавлен вывод state и dtRegistered в getProfile

[Mobile_HLR-590](https://youtrack.protei.ru/issue/Mobile_HLR-590)([1035111](https://newportal.protei.ru/portal/#issues/issue:id=1035111)) Конвертация Oracle БД Global-телеком для работы с HLR_API
- Basic **Freq**, Заказчик: **Глобал Телеком**
- Добавлено удаление дубликатов перед добавлением внешних и уникальных ключей

[Mobile_HLR-591](https://youtrack.protei.ru/issue/Mobile_HLR-591) HSS отправил PPR, в котором в User-Name AVP указал незарегистрированный IMPI
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена проверка статуса связки IMPI-IMPU

[Mobile_HLR-592](https://youtrack.protei.ru/issue/Mobile_HLR-592)([1035352](https://newportal.protei.ru/portal/#issues/issue:id=1035352)) Некорректная работа команды по управлению параметрами в TM_COMFIG
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Исправлена команда по изменения параметров конфига.

[Mobile_HLR-593](https://youtrack.protei.ru/issue/Mobile_HLR-593) С HSS приходит RTR только для одного из зарегистрированных IMPI при запросе отправки RTR по IMPU
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлен поиск IMPI при запросе RTR по shared IMPU

[Mobile_HLR-594](https://youtrack.protei.ru/issue/Mobile_HLR-594) Добавить проверку, чтобы было невозможно создать через API разные AS с одинаковым "Host"
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена проверка на уникальность ApplicationServerHost

#### [2.0.21.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/266/artifact/hlr_ap.2.0.21.1.tar.gz) (2020-07-09)
[Mobile_HLR-542](https://youtrack.protei.ru/issue/Mobile_HLR-542)([1034862](https://newportal.protei.ru/portal/#issues/issue:id=1034862)) Изменение структуру IMS профиля абонента
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена возможность сменить IMS подписку для карты

[Mobile_HLR-588](https://youtrack.protei.ru/issue/Mobile_HLR-588)([1032784](https://newportal.protei.ru/portal/#issues/issue:id=1032784)) Конвертация Oracle БД SIM-телеком для работы с HLR_API
- Basic **Freq**
- Исправлены патчи для Oracle

#### [2.0.21.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/265/artifact/hlr_ap.2.0.21.0.tar.gz) (2020-07-02)
[Mobile_HLR-542](https://youtrack.protei.ru/issue/Mobile_HLR-542)([1034862](https://newportal.protei.ru/portal/#issues/issue:id=1034862)) Изменение структуру IMS профиля абонента
- Basic **Freq**, Заказчик: **НТЦ Протей**
- ServiceProfile перенесен в ImsSubscription.Ifc больше не является общей сущностью, а принадлежит только определенному ServiceProfile.ImplicitlyRegisteredSet перенесен в ImsSubscription.Убраны команды по управлению ServiceProfile, Ifc, ImplicitlyRegisteredSet. Все управление происходит через ImsSubscription.

#### [2.0.20.2](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/263/artifact/hlr_ap.2.0.20.2.tar.gz) (2020-06-23)
[Mobile_HLR-586](https://youtrack.protei.ru/issue/Mobile_HLR-586) NPE при отправки SendCancelLocation без указания domain
- Basic **Bug**, Заказчик: **ООО "Центр 2М"**
- Добавлена проверка на отсутсвие domain в запросе

#### [2.0.20.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/262/artifact/hlr_ap.2.0.20.1.tar.gz) (2020-06-17)
[Mobile_HLR-582](https://youtrack.protei.ru/issue/Mobile_HLR-582) Ошибка в валидации запроса SendCancelLocation
- Basic **Bug**, Заказчик: **ООО "Центр 2М"**
- Исправлена валидация запроса SendCancelLocation

#### [2.0.20.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/261/artifact/hlr_ap.2.0.20.0.tar.gz) (2020-06-16)
##### Зависимость: HSS.2.2.57.0
[Mobile_HLR-560](https://youtrack.protei.ru/issue/Mobile_HLR-560) Расширить функциональность Reset
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Добавлена отправка Reset по groupIdList.

[Mobile_HLR-571](https://youtrack.protei.ru/issue/Mobile_HLR-571) HSS дает зарегистрироваться на Ip-SM-GW при отсутствии телесервисов SMS
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена проверка телесервисов SMS

[Mobile_HLR-572](https://youtrack.protei.ru/issue/Mobile_HLR-572) SRI4SM отбивается при наличии регистрации на IP-SM-GW
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена проверка регистрации на IP_SM_GW

[Mobile_HLR-574](https://youtrack.protei.ru/issue/Mobile_HLR-574) Генерация AlertSC по ATM регистрации на IP-SM-GW
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена проверка наличия MWD, при регистрации на IP_SM_GW

[Mobile_HLR-575](https://youtrack.protei.ru/issue/Mobile_HLR-575) Включать в ответ на ATM в рамках регистрации IP-SM-GW адрес SMSC из профиля
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлен параметр SCA в профиль абонента.

#### 2.0.19.0 (2020-05-27)
[Скачать версию 2.0.19.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/260/artifact/hlr_ap.2.0.19.0.tar.gz)

##### Зависимость: HSS.2.2.56
##### [Mobile_HLR-401](https://youtrack.protei.ru/issue/Mobile_HLR-401) Доработки IMS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Доработка oracle запросов

[Mobile_HLR-538](https://youtrack.protei.ru/issue/Mobile_HLR-538) Добавление Delete Subscriber Data
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлено формирование DSD для PDP

[Mobile_HLR-557](https://youtrack.protei.ru/issue/Mobile_HLR-557) Добавить пользователя в operation journal cdr
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Добавлен вывод имени пользователя в operation journal cdr

[Mobile_HLR-558](https://youtrack.protei.ru/issue/Mobile_HLR-558) Расширение модели управления правами
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Добавлены права A-(Добавление абонента), D-(Удаление абонента), E-(Управление внешними сущностями).Доавдена команда управления пользователями и их паравами.

[Mobile_HLR-561](https://youtrack.protei.ru/issue/Mobile_HLR-561)([1028892](https://newportal.protei.ru/portal/#issues/issue:id=1028892)) Изменить вид вывода результата о загрузке абонентов через Load интерфейс
- Low **Freq**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Возвращен первоначальный формат вывода

[Mobile_HLR-562](https://youtrack.protei.ru/issue/Mobile_HLR-562)([1028892](https://newportal.protei.ru/portal/#issues/issue:id=1028892)) При загрузке абонентов через Load интерфейс если IMSI/MSISDN не уникальны, формировать файл с ошибкой
- Low **Freq**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Возврат причины неуспешности загрузки абонента

[Mobile_HLR-564](https://youtrack.protei.ru/issue/Mobile_HLR-564)([1032784](https://newportal.protei.ru/portal/#issues/issue:id=1032784)) CHANGE_PROFILE_IMSI для IMSI c разными groupId
- Basic **Freq**, Заказчик: **SIM Telecom**
- Добавлена возможность смены IMSI из разных групп

[Mobile_HLR-566](https://youtrack.protei.ru/issue/Mobile_HLR-566)([1032751](https://newportal.protei.ru/portal/#issues/issue:id=1032751)) Добавление абонента без OPC
- Basic **Bug**, Заказчик: **Ariantel**
- Добавлена проверка OP и OPC при создании абонента с Milenage

[Mobile_HLR-567](https://youtrack.protei.ru/issue/Mobile_HLR-567) Некорректный AIA для пользователя без EPS
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена проверка наличия привязки EPS/PDP-контекстов

[Mobile_HLR-569](https://youtrack.protei.ru/issue/Mobile_HLR-569)([1032831](https://newportal.protei.ru/portal/#issues/issue:id=1032831)) CL на SGSN после успешного Purge
- Basic **Bug**, Заказчик: **Глобал Телеком**
- Добавлена проверка на Purge

#### 2.0.18.1 (2020-05-18)
[Скачать версию 2.0.18.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/259/artifact/hlr_ap.2.0.18.1.tar.gz)

[Mobile_HLR-401](https://youtrack.protei.ru/issue/Mobile_HLR-401) Доработки IMS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлено удаление неактуальных записей из БД, перед накатыванием патча

#### 2.0.18.0 (2020-05-14)
[Скачать версию 2.0.18.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/258/artifact/hlr_ap.2.0.18.0.tar.gz)
##### Зависимость: HSS.2.2.55.0
[Mobile_HLR-550](https://youtrack.protei.ru/issue/Mobile_HLR-550) Реализовать поддержку Si интерфейса между IM-SSF и HSS
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Добавлены сущности O-IM-CSI, VT-IM-CSI, D-IM-CSI

[Mobile_HLR-556](https://youtrack.protei.ru/issue/Mobile_HLR-556) Некорректная обработка ATM с MSISDN
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Исправлена блокировка транзакции

#### [2.0.17.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/257/artifact/hlr_ap.2.0.17.0.tar.gz) (2020-05-13)
##### Зависимость: HSS.2.2.54.0
[Mobile_HLR-544](https://youtrack.protei.ru/issue/Mobile_HLR-544) Поддержка GPRS-Subscription-Data AVP
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена передача GPRS-Subscription-Data

[Mobile_HLR-390](https://youtrack.protei.ru/issue/Mobile_HLR-390) Повтор транзакции при получении ошибки DeadLock
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлен параметр конфигурации db.countTryResolveDeadlock

[Mobile_HLR-547](https://youtrack.protei.ru/issue/Mobile_HLR-547) Добавить вывод dtLastSubscriberActivity в get_profile
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Добавден ключ lastActivity в get_profile

[Mobile_HLR-548](https://youtrack.protei.ru/issue/Mobile_HLR-548) UE-Usage-Type Decor
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Реализовано управление параметром ueUsageType

[Mobile_HLR-549](https://youtrack.protei.ru/issue/Mobile_HLR-549) MPS Priority Service в EPS профиль
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Реализовано управление параметром mpsPriority

[Mobile_HLR-553](https://youtrack.protei.ru/issue/Mobile_HLR-553)([1032036](https://newportal.protei.ru/portal/#issues/issue:id=1032036)) Отправлять PSI указывая Calling GT из Subscriber Group
- Basic **Freq**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Добавлена информация о группе в getRoutingInformationResponse

[Mobile_HLR-555](https://youtrack.protei.ru/issue/Mobile_HLR-555) Изменение liquibase патчей
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлены дополнительные параметры для работы автоматического "офлайн"-патчинга

#### [2.0.16.2](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/256/artifact/hlr_ap.2.0.16.2.tar.gz) (2020-04-22)
[Mobile_HLR-401](https://youtrack.protei.ru/issue/Mobile_HLR-401) Доработки по IMS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Исправлена проблема с выборкой IFC без TriggerPoint

[Mobile_HLR-537](https://youtrack.protei.ru/issue/Mobile_HLR-537)([1031447](https://newportal.protei.ru/portal/#issues/issue:id=1031447)) IDR на получение текущего статуса поддержки "IMS Voice over PS Sessions" сетью доступа
- Basic **Freq**, Заказчик: **Esmero**
- Исключено ненужное условие

#### [2.0.16.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/255/artifact/hlr_ap.2.0.16.1.tar.gz) (2020-04-22)
[Mobile_HLR-401](https://youtrack.protei.ru/issue/Mobile_HLR-401) Доработки по IMS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Исправлено условие поиска IFC с UnregTermService

[Mobile_HLR-536](https://youtrack.protei.ru/issue/Mobile_HLR-536) ISD на получение EPS User State and/or EPS Location Information
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Возврат NOT_AVAILABLE, если нет регистрации на MME

#### [2.0.16.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/254/artifact/hlr_ap.2.0.16.0.tar.gz) (2020-04-21)
##### Зависимость: HSS.2.2.53.0
[Mobile_HLR-530](https://youtrack.protei.ru/issue/Mobile_HLR-530) NullPointer при изменении ODB в профиле пользователя
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавил валидацию параметров ODB

[Mobile_HLR-401](https://youtrack.protei.ru/issue/Mobile_HLR-401) Доработки по IMS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавил механизм подписки AS на обновление профиля пользователя и формирование PNR на подписанные ASРеализовал создание фиктивного польсователя, при создании SharedIfcsSet

[Mobile_HLR-534](https://youtrack.protei.ru/issue/Mobile_HLR-534) Ограничение по длине для ueApnOiRep
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Увеличил размер поля до 100 байт

[Mobile_HLR-513](https://youtrack.protei.ru/issue/Mobile_HLR-513)([1023168](https://newportal.protei.ru/portal/#issues/issue:id=1023168)) Оптимизация долгих SQL запросов к БД
- Basic **Freq**, Заказчик: **Тинькофф Мобайл**
- Убрал UPDATE в TM_EIR при каждом запросе. Заменил INSERT ON DUPLICATE KEY UPDATE на INSERT и UPDATE

[Mobile_HLR-275](https://youtrack.protei.ru/issue/Mobile_HLR-275) Перенести команду для инициализации Reset с Load на API
- Basic **Freq**, Заказчик: **НТЦ Протей**

[Mobile_HLR-536](https://youtrack.protei.ru/issue/Mobile_HLR-536) ISD на получение EPS User State and/or EPS Location Information
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавил лицензию на получение местоположения абонента

[Mobile_HLR-537](https://youtrack.protei.ru/issue/Mobile_HLR-537)([1031447](https://newportal.protei.ru/portal/#issues/issue:id=1031447)) IDR на получение текущего статуса поддержки "IMS Voice over PS Sessions" сетью доступа
- Basic **Freq**, Заказчик: **Esmero**
- В GetSdImsResp добавил информацию об MME, если регистарция на MME ществует и если не выставлен VoIMSВ GetShUserDataResp в секции выставялется значение VoIMS, полученное в ответ на IDR, если в базе не сохранено значение

[Mobile_HLR-533](https://youtrack.protei.ru/issue/Mobile_HLR-533) Нет отправки ISD при изменении APN-OI-Replacement
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Поправил формат команды на отправку изменения контекста

[Mobile_HLR-419](https://youtrack.protei.ru/issue/Mobile_HLR-419) Добавить команду для отправки PSI
- Basic **Freq**, Заказчик: **Italtel**
- Добавил новый статус (REMOTE_HOST_UNREACHABLE) в ответ на http-запрос, если на HSS сработал таймер ожидания ответа от удаленного узла

[Mobile_HLR-539](https://youtrack.protei.ru/issue/Mobile_HLR-539) Некорректные значения в ISD при изменении defaultAPN
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Исправил формат передачи APN-профиля

[Mobile_HLR-540](https://youtrack.protei.ru/issue/Mobile_HLR-540) Не находится карта по Temporary public identity
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Убрал проверку на соответсвие идентификаторов на стороне API

#### [2.0.15.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/252/artifact/hlr_ap.2.0.15.0.tar.gz) (2020-04-07)
[Mobile_HLR-326](https://youtrack.protei.ru/issue/Mobile_HLR-326) Добавление лога со считываемой конфигурацией
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавил вывод warn, при некорректности конфига. Убрал дублирование при выводе HLRProfileConfigData

[Mobile_HLR-401](https://youtrack.protei.ru/issue/Mobile_HLR-401) Доработки по IMS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавил сущность SharedIFCSetДобавил параметр UnregTermServiceIndicate в GerSdImsResponse

#### [2.0.14.3](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/250/artifact/hlr_ap.2.0.14.3.tar.gz) (2020-04-03)
##### Зависимость: HSS.2.2.51.5
[Mobile_HLR-452](https://youtrack.protei.ru/issue/Mobile_HLR-452) Поддержка MAP ATSI
- Basic **Freq**, Заказчик: **Italtel**
- Исправление ошибок

[Mobile_HLR-523](https://youtrack.protei.ru/issue/Mobile_HLR-523) Поддержка Wildcarded PSI
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Если PublicIdentity из запроса не найден в TM_IMS_PUBLIC_IDENTITY.STRPUBLIC_ID, то ищем по шаблонам из TM_IMS_PUBLIC_IDENTITY.STRWILDCARD_PSI

[Mobile_HLR-463](https://youtrack.protei.ru/issue/Mobile_HLR-463) Формирование repository data на основании профиля абонента
- Basic **Freq**, Заказчик: **Esmero**
- Добавил провекру наличия 16 или 17 телесервиса, для индикации MMTEL-Services

[Mobile_HLR-525](https://youtrack.protei.ru/issue/Mobile_HLR-525) Временное решение для прохождения входящих вызовов VoLTE абонентов в 2G/3G
- Basic **Bug**, Заказчик: **Esmero**
- Всегда выставляю mmtelIndicate=1 и unregServiceIndicate=1

[Mobile_HLR-528](https://youtrack.protei.ru/issue/Mobile_HLR-528) Все Notify отбиваются с unknownNode
- Basic **Bug**, Заказчик: **Esmero**
- Сделал определение типа узла по соответсвию индетефикаторам, сохраненным в базе

#### [2.0.14.2](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/248/artifact/hlr_ap.2.0.14.2.tar.gz) (2020-03-31)
[Mobile_HLR-522](https://youtrack.protei.ru/issue/Mobile_HLR-522)([1030560](https://newportal.protei.ru/portal/#issues/issue:id=1030560)) Завис API, резкое увеличение утилизации CPU
- Important **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- В winter.jdbc не очищалась переменная queryStatistics

#### [2.0.14.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/247/artifact/hlr_ap.2.0.14.1.tar.gz) (2020-03-27)
[Mobile_HLR-521](https://youtrack.protei.ru/issue/Mobile_HLR-521) Рефакторинг CSI Profile
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Привел именования аналогичных параметров в разных CSI к одному формату

#### [2.0.14.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/246/artifact/hlr_ap.2.0.14.0.tar.gz) (2020-03-25)
##### Зависимость: HSS.2.2.51.4
[Mobile_HLR-400](https://youtrack.protei.ru/issue/Mobile_HLR-400) Использовать разные CSI для разных сетей
- Basic **Freq**, Заказчик: **Esmero**
- Добавил столбец STRPREFFIX в TM_CAMEL_SUBSCRIBERВ SRI используется выборка OCSI по GT GMLC

[Mobile_HLR-372](https://youtrack.protei.ru/issue/Mobile_HLR-372)([1011937](https://newportal.protei.ru/portal/#issues/issue:id=1011937)) Поддержка isVolte и imrn
- Basic **Freq**, Заказчик: **Italtel**
- Отправляется imrn на HSS, если только у абонента отсутсвует регистрация

[Mobile_HLR-515](https://youtrack.protei.ru/issue/Mobile_HLR-515) Привязка EPS контекста к plmn-id
- Basic **Freq**, Заказчик: **Esmero**
- Добавил параметр для привязки plmn-id. Реализовал выборку при формировании списка EPS контекстов

[Mobile_HLR-518](https://youtrack.protei.ru/issue/Mobile_HLR-518)([1030332](https://newportal.protei.ru/portal/#issues/issue:id=1030332)) Добавить HSM_ID в profiles.json
- Basic **Freq**, Заказчик: **ОАО "Воентелеком"**

[Mobile_HLR-520](https://youtrack.protei.ru/issue/Mobile_HLR-520) Обязательные параметры в epsData при добавлении и изменении абонента через API
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Сделал параметры ueMaxDl/ueMaxUl обязательными при добавлении абонентаПри изменении абонента убрал обязательность параметра defContextId, т.к. при изменинии нужно указывать только изменяемые параметры

#### [2.0.13.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/245/artifact/hlr_ap.2.0.13.1.tar.gz) (2020-03-16)
##### Зависимость: HSS.2.2.51.3
[Mobile_HLR-463](https://youtrack.protei.ru/issue/Mobile_HLR-463) Формирование repository data на основании профиля абонента
- Basic **Freq**, Заказчик: **Esmero**
- Добавил формирование MMTel-Services-Extra на основании ssForw и teleservices

[Mobile_HLR-507](https://youtrack.protei.ru/issue/Mobile_HLR-507) В MMTEL-Services-Extra включаются переадресации на + NULL
- Basic **Bug**, Заказчик: **Esmero**
- Убрал добавление переадресаций в sh-user-data, если номер отсутсвует или статус равен 0 или 4

[Mobile_HLR-509](https://youtrack.protei.ru/issue/Mobile_HLR-509) Управление параметрами Subscription через AddSubscriber
- Basic **Freq**, Заказчик: **Esmero**
- Так же добавил такую возможность в changeProfile, только для создания imsProfile

[Mobile_HLR-510](https://youtrack.protei.ru/issue/Mobile_HLR-510) liquibase.exception.DatabaseException: ORA-01779: cannot modify a column which maps to a non key-preserved table
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Поправил патч LB

[Mobile_HLR-511](https://youtrack.protei.ru/issue/Mobile_HLR-511) Запросы TADS Information по IMSI и MSISDN отбиваются с 5001
- Basic **Bug**, Заказчик: **Esmero**
- Добавил получение ShUserData по MSISDN и проверку PrivateIdentity на то, не является ли он IMSI

#### [2.0.13.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/244/artifact/hlr_ap.2.0.13.0.tar.gz) (2020-03-10)
[Mobile_HLR-505](https://youtrack.protei.ru/issue/Mobile_HLR-505)([1029572](https://newportal.protei.ru/portal/#issues/issue:id=1029572)) Добавить загрузку параметра OPC через API
- Basic **Freq**, Заказчик: **ООО "Сонет"**
- Добавил доавление/изменение/удаление/получение opc

#### [2.0.12.6](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/243/artifact/hlr_ap.2.0.12.6.tar.gz) (2020-03-06)
##### Зависимость: HSS.2.2.51.2
[Mobile_HLR-499](https://youtrack.protei.ru/issue/Mobile_HLR-499) Не сохраняется IP_SM_GW из ATM
- Basic **Bug**, Заказчик: **Esmero**
- Добавил сохранение IP_SM_GW

[Mobile_HLR-503](https://youtrack.protei.ru/issue/Mobile_HLR-503) Некорректные ответы в Notification procedure
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавил проверку MME/SGSN identity

[Mobile_HLR-498](https://youtrack.protei.ru/issue/Mobile_HLR-498) Поддержка Coupled-Node-Diameter-ID
- Low **Freq**, Заказчик: **НТЦ Протей**
- Сохранение доп. идентификатора для Combined MME/SGSN и добавление в таблицу флага, что это именно комбинированный MME/SGSN

[Mobile_HLR-506](https://youtrack.protei.ru/issue/Mobile_HLR-506) Некорректное выставление флагов при частичном Purge
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавил проверку парметра PartialPurge перед проверкой на соответсвия иеднтификаторов MME/SGSN

#### [2.0.12.5](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/242/artifact/hlr_ap.2.0.12.5.tar.gz) (2020-03-03)
##### Зависимость HSS.2.2.51.0
Исправлена ситуация с отсутсвием повторного подключения к БД
[Mobile_HLR-488](https://youtrack.protei.ru/issue/Mobile_HLR-488) Спрятать эксепшн о дублирующей записи EPS-профиля
- Low **Task**, Заказчик: **НТЦ Протей**
- Добавил проверку на наличие EPS профиля перед его добавление/изменением/удалением

[Mobile_HLR-493](https://youtrack.protei.ru/issue/Mobile_HLR-493) Некорректное значение CancellationType
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Сохраняли регистрацию как SGSN, если только был SGSN-Number

[Mobile_HLR-492](https://youtrack.protei.ru/issue/Mobile_HLR-492)([1029257](https://newportal.protei.ru/portal/#issues/issue:id=1029257)) Отбили SRI c bearerServiceNotProvisioned
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Не было проверки DeactivatePSI на null, при добавлении пустого профиля абонента DeactivatePSI выставлялся в null

[Mobile_HLR-495](https://youtrack.protei.ru/issue/Mobile_HLR-495)([1029274](https://newportal.protei.ru/portal/#issues/issue:id=1029274)) Отбиваем ATI с teleserviceNotProvisioned
- Basic **Bug**, Заказчик: **ООО "Центр 2М"**
- Добавил версию MAP в GetLocationInfoResponse

[Mobile_HLR-497](https://youtrack.protei.ru/issue/Mobile_HLR-497) Не добавляются impu, если administrative state = 0
- Basic **Bug**, Заказчик: **Esmero**
- Была проверка SubscriberState до измениния imsProfile

#### [2.0.12.4](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/241/artifact/hlr_ap.2.0.12.4.tar.gz) (2020-02-25)
[Mobile_HLR-476](https://youtrack.protei.ru/issue/Mobile_HLR-476)([1024984](https://newportal.protei.ru/portal/#issues/issue:id=1024984)) Проблемы с обновлением схемы oracle на новую версию API
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Добавил патч для oracle + поправил ошибки в oracle некоторых запросах

#### [2.0.12.4](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/241/artifact/hlr_ap.2.0.12.4.tar.gz) (2020-02-21)
[Mobile_HLR-476](https://youtrack.protei.ru/issue/Mobile_HLR-476)([1024984](https://newportal.protei.ru/portal/#issues/issue:id=1024984)) Проблемы с обновлением схемы oracle на новую версию API
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Добавил патч для oracle + поправил ошибки в oracle некоторых запросах

#### [2.0.12.3](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/240/artifact/hlr_ap.2.0.12.3.tar.gz) (2020-02-21)
[Mobile_HLR-487](https://youtrack.protei.ru/issue/Mobile_HLR-487)([1024984](https://newportal.protei.ru/portal/#issues/issue:id=1024984)) Не отдаем t-csi профиль в ответе на SRI при переадресации
- Important **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Не добавляли информацию о CSI в ответ в случае активной переадресации

#### [2.0.12.2](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/238/artifact/hlr_ap.2.0.12.2.tar.gz) (2020-02-19)
[Mobile_HLR-470](https://youtrack.protei.ru/issue/Mobile_HLR-470) Раздельный подсчет суточной и оперативной статистики по абонентам
- Basic **Freq**, Заказчик: **Top Connect** 
- Добавил IMSI ответ на запросы, которые приходили с MSISDN, даже если они завершились неуспешно

[Mobile_HLR-476](https://youtrack.protei.ru/issue/Mobile_HLR-476)([1024984](https://newportal.protei.ru/portal/#issues/issue:id=1024984)) Проблемы с обновлением схемы oracle на новую версию API
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)** 
- Добавил удаление дубликатов из TM_EIR

[Mobile_HLR-482](https://youtrack.protei.ru/issue/Mobile_HLR-482) Унификация, некорректное поведение и исправление описания на wiki
- Basic **Bug**, Заказчик: **НТЦ Протей** 

[Mobile_HLR-483](https://youtrack.protei.ru/issue/Mobile_HLR-483) Возможность просмотра масок WL/BL по ID
- Basic **Freq**, Заказчик: **НТЦ Протей** 
- Добавил в GetWhiteBlackLists параметр id

[Mobile_HLR-485](https://youtrack.protei.ru/issue/Mobile_HLR-485)([1028883](https://newportal.protei.ru/portal/#issues/issue:id=1028883)) UA First Registration
- Basic **Bug**, Заказчик: **Esmero** 
- Добавил в поиск регистрации на S-CSCF при получении запроса с Temporary IMPU

#### [2.0.12.1](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/237/artifact/hlr_ap.2.0.12.1.tar.gz) (2020-02-19)
[Mobile_HLR-480](https://youtrack.protei.ru/issue/Mobile_HLR-480)([1024984](https://newportal.protei.ru/portal/#issues/issue:id=1024984)) На чистится DM_STR_VPLMN при регистрации на SGSN
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)** 
- Не сохраняли VPLMN при регистрации в сети 4G

#### [2.0.12.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/231/artifact/hlr_ap.2.0.12.0.tar.gz)
##### Зависимость: HLR.2.2.49.0
- [Mobile_HLR-477](https://youtrack.protei.ru/issue/Mobile_HLR-477) NPE при формировании результата на HandleCF
- Добавил проверку наличия переадресации, при формировании ответа на HandleCF
- [Mobile_HLR-452](https://youtrack.protei.ru/issue/Mobile_HLR-452) Поддержка MAP ATSI
- Добавил команду getSdByKey, с помощью которй можно получить опрделенную часть абоненсткого профиля
- [Mobile_HLR-479](https://youtrack.protei.ru/issue/Mobile_HLR-479) Отбивается регистрация в MME при наличии WL с VLR
- Считали, что для абонента действуют правила белых списков, если привязаны хотя бы одни из масок (VLR или PLMN)
- [Mobile_HLR-474](https://youtrack.protei.ru/issue/Mobile_HLR-474) SRI4SM исправить ошибку 27 на ошибку 6

#### [2.0.11.0](https://jenkins.protei.ru/job/team4/job/buildAPI/job/HSS_API/job/HSS_API_release/227/artifact/hlr_ap.2.0.11.0.tar.gz)
##### Зависимость: HLR.2.2.48.8
- [Mobile_HLR-463](https://youtrack.protei.ru/issue/Mobile_HLR-463) Формирование repository data на основании профиля абонента
- Добавил формирование: MMTelServices на основании ssData, SIP-Basic-Data на основании IMSI/MSISDN, Advanced-Media-Services
- [Mobile_HLR-466](https://youtrack.protei.ru/issue/Mobile_HLR-466) HSS дает зарегистрировать один IMS Subscription на нескольких S-CSCF
- Добавил поиск регистрации на SCSCF по всем IMPI в рамках IMSU по запросу GetSdIms
- Добавил lock по IMSSubscription
- Передача Capabilities и PrefferedScscf на HSS всегда, не зависимо от наличия регистрации (+ fix поправил имя параметра)
- [Mobile_HLR-467](https://youtrack.protei.ru/issue/Mobile_HLR-467) HSS не присылает PPR при обновлении/добавлении charging info у IMS Subscription
- Сделал формироваине только одного PPR в рамках подписки

#### 2.0.10.3
- [Mobile_HLR-454](https://youtrack.protei.ru/issue/Mobile_HLR-454) Rename parameter + get vlr registration in getSdIms

#### 2.0.10.2
- [Mobile_HLR-454](https://youtrack.protei.ru/issue/Mobile_HLR-454) Передавать на HSS PsiActivate и  WildcardPSI

#### 2.0.10.1
- [Mobile_HLR-454](https://youtrack.protei.ru/issue/Mobile_HLR-454) Отвечаем LIR с 5003, если абонент зарегестрирован в 2G

#### 2.0.10.0
- [Mobile_HLR-445](https://youtrack.protei.ru/issue/Mobile_HLR-445) Добавть параметры в ответ на запрос SendPSI

#### 2.0.9.24
- [Mobile_HLR-449](https://youtrack.protei.ru/issue/Mobile_HLR-449) (fix) в сеттере (ssData.setType) перетиралось подменное знасение null, первоначальным значением -1

#### 2.0.9.23
- [Mobile_HLR-451](https://youtrack.protei.ru/issue/Mobile_HLR-451) Не удаляем ipSmGw из профиля

#### 2.0.9.22
- [Mobile_HLR-449](https://youtrack.protei.ru/issue/Mobile_HLR-449) Добавил поддержку значения -1 для параметров из ssData (совместимость со старым API)

#### 2.0.9.21
- [Mobile_HLR-449](https://youtrack.protei.ru/issue/Mobile_HLR-449) Поправил проверку subscriberIds в changeImsi

#### 2.0.9.20
- [Mobile_HLR-441](https://youtrack.protei.ru/issue/Mobile_HLR-441) Add params in epsProfile and qosEps

#### 2.0.9.19
- fix DownloadProfile

#### 2.0.9.18
- [Mobile_HLR-440](https://youtrack.protei.ru/issue/Mobile_HLR-440) Ошибка при выполнении changeImsi (Нарушение связки с TM_EIR)

#### 2.0.9.17
- [Mobile_HLR-437](https://youtrack.protei.ru/issue/Mobile_HLR-437) Проблемы с ODB в Diameter

#### 2.0.9.16
- [Mobile_HLR-435](https://youtrack.protei.ru/issue/Mobile_HLR-435) Заливка карт с OPC

#### 2.0.9.15
- Рефакторинг Send RTR

#### 2.0.9.14
- [Mobile_HLR-432](https://youtrack.protei.ru/issue/Mobile_HLR-432) fix убрал проверку impi при получении ChargingInformation по Sh

#### 2.0.9.13
- [Mobile_HLR-373](https://youtrack.protei.ru/issue/Mobile_HLR-373), Mobile_HLR-419
- добавил endpoints для запросов по http/json

#### 2.0.9.12
- [Mobile_HLR-433](https://youtrack.protei.ru/issue/Mobile_HLR-433) Ошибка в формате передачи RestorationInfo с API на HSS

#### 2.0.9.11
- Добавил ShImsData: PublicIdentities, MSISDN, IMSI, IMEISV, STNSR, UESRVCCCapability, PSIActivation, SCSCFName, IMSUserState

#### 2.0.9.10
- Добавил ShImsData.ChargingInformation

#### 2.0.9.9
- Замена html тегов нормальными символами

#### 2.0.9.8
- [Mobile_HLR-429](https://youtrack.protei.ru/issue/Mobile_HLR-429) Не удаляется Restoration Info после получения SAR с типом USER_DEREGISTRATION_STORE_SERVER_NAME

#### 2.0.9.7
- [Mobile_HLR-425](https://youtrack.protei.ru/issue/Mobile_HLR-425) Конвертация Oracle Бд МТТ для работы с HLR_API

#### 2.0.9.6
- drop unused TM_BASIC_SERVICE table

#### 2.0.9.5
- [Mobile_HLR-428](https://youtrack.protei.ru/issue/Mobile_HLR-428) Увеличение размера столбцов для хранения RestorationInfo

#### 2.0.9.4
- [Mobile_HLR-422](https://youtrack.protei.ru/issue/Mobile_HLR-422) UDR поддержка Data-Reference: TADSinformation + bugfix addImsProfile in ChangeProfileRequest

#### 2.0.9.3
- [Mobile_HLR-424](https://youtrack.protei.ru/issue/Mobile_HLR-424) Неправильный CancellationType
- [Mobile_HLR-426](https://youtrack.protei.ru/issue/Mobile_HLR-426) Флаг Reattach Required в CL

#### 2.0.9.2
- [Mobile_HLR-421](https://youtrack.protei.ru/issue/Mobile_HLR-421) Поддержка UDR ServiceData

#### 2.0.9.1
- [Mobile_HLR-423](https://youtrack.protei.ru/issue/Mobile_HLR-423) Поддержка SharedIFCSetID

#### 2.0.9.0
- [Mobile_HLR-419](https://youtrack.protei.ru/issue/Mobile_HLR-419) Добавить команду для отправки PSI fix oracle patch LB set accessRestrictionData NULL when all restriction eq 0

#### 2.0.8.20
- [Mobile_HLR-417](https://youtrack.protei.ru/issue/Mobile_HLR-417) activateSS очистил SubOptionType и SubOption для CLIR

#### 2.0.8.19
- Добавить в вывод getProfile->imsProfile->imsSubscriptionName

#### 2.0.8.18
- Удалить неиспользуемые таблицы + Mobile_HLR-414 Нет проверки на BAIC

#### 2.0.8.17
- Добавление уникальности в TM_IMS_CAPABILITIES_SET

#### 2.0.8.16
- При удалении imsProfile отправлять RTR по всей imsSubscription

#### 2.0.8.15
- [Mobile_HLR-411](https://youtrack.protei.ru/issue/Mobile_HLR-411) object="provisioning" в HrlHssTalk

#### 2.0.8.14
- [Mobile_HLR-410](https://youtrack.protei.ru/issue/Mobile_HLR-410) Добавить reload profile.json

#### 2.0.8.13
- Поддержка Slh интерфейса + Mobile_HLR-409

#### 2.0.8.12
- При изменении IMSI неправильно сравнивались GroupID старого и нового IMSI

#### 2.0.8.11
- Ошибка в sql запросе при получении tCsi (getRI)

#### 2.0.8.10
- [Mobile_HLR-403](https://youtrack.protei.ru/issue/Mobile_HLR-403) AddAndActivateEmptySubscribers NULL в NROAMINGNOTALLOWED (Oracle)

#### 2.0.8.9
- [Mobile_HLR-402](https://youtrack.protei.ru/issue/Mobile_HLR-402) bad sql request при смене imei

#### 2.0.8.8
- minifix IMS (save RestorationInfo when set ReassignmentPendingFlag)

#### 2.0.8.7
- [Mobile_HLR-373](https://youtrack.protei.ru/issue/Mobile_HLR-373) Add gmscAddress and callReferenceNumber in api request

#### 2.0.8.6
- IMSSubscribtion, ReassignmentPendingFlag

#### 2.0.8.5
- [Mobile_HLR-398](https://youtrack.protei.ru/issue/Mobile_HLR-398) PDA_Error при добавлении белого списка HSS

#### 2.0.8.4
- [Mobile_HLR-395](https://youtrack.protei.ru/issue/Mobile_HLR-395) INTERNAL_ERROR при привязке абоенту BL (Ошибка парсинга mcc, mnc из realm)

#### 2.0.8.3
- [Mobile_HLR-397](https://youtrack.protei.ru/issue/Mobile_HLR-397) Поддержка загрузки групп (load)

#### 2.0.8.2
- [Mobile_HLR-393](https://youtrack.protei.ru/issue/Mobile_HLR-393) sub_option_type при загрузке абонентов с ActiveSS = 18

#### 2.0.8.1
- [Mobile_HLR-384](https://youtrack.protei.ru/issue/Mobile_HLR-384) Поддержка Feature-LIst-Id=2 (откат изменений базы)

#### 2.0.8.0
- [Mobile_HLR-383](https://youtrack.protei.ru/issue/Mobile_HLR-383) Расширение Access-Restriction-Data для 5G
- [Mobile_HLR-384](https://youtrack.protei.ru/issue/Mobile_HLR-384) Поддержка Feature-LIst-Id=2
- [Mobile_HLR-385](https://youtrack.protei.ru/issue/Mobile_HLR-385) Поддержка расширенного AMBR для 5g сети

#### 2.0.7.9
- impu like as temporary impu in implicitly set

#### 2.0.7.8
- [Mobile_HLR-373](https://youtrack.protei.ru/issue/Mobile_HLR-373) SendProvideRoamingNumberRequest

#### 2.0.7.7
- [Mobile_HLR-386](https://youtrack.protei.ru/issue/Mobile_HLR-386) Не передавать Specific-APN в ULA

#### 2.0.7.6
- [Mobile_HLR-379](https://youtrack.protei.ru/issue/Mobile_HLR-379) Не отображается имя группы в статистике абонентов

#### 2.0.7.5
- [Mobile_HLR-376](https://youtrack.protei.ru/issue/Mobile_HLR-376) Не изменяется профиль абонента через activateSS и deactivateSS

#### 2.0.7.4
- [Mobile_HLR-372](https://youtrack.protei.ru/issue/Mobile_HLR-372) rename column name

#### 2.0.7.3
- [Mobile_HLR-375](https://youtrack.protei.ru/issue/Mobile_HLR-375) loadSubscriber

#### 2.0.7.2
- fix isVoLTE + human-like odb-param в API BS

#### 2.0.7.1
- Вывод краткой информации по WL/BL в getProfile

#### 2.0.7.0
- Поддержка isVoLTE и IMRN + fix getStat

#### 2.0.6.13
- minifix

#### 2.0.6.12
- [Mobile_HLR-370](https://youtrack.protei.ru/issue/Mobile_HLR-370) Не проходит MAR при использовании Implicit Temporary Public User Identity

#### 2.0.6.11
- [Mobile_HLR-231](https://youtrack.protei.ru/issue/Mobile_HLR-231) HTTP статус код не соответствует передаваемой в теле ошибке

#### 2.0.6.10
- [Mobile_HLR-364](https://youtrack.protei.ru/issue/Mobile_HLR-364) Смена статуса Forced_SS в profiles.json

#### 2.0.6.9
- liquibase oracle fix

#### 2.0.6.8
- Поправлен запрос на изменение TM_ROAMING_SGSN Oracle

#### 2.0.6.7
- [Mobile_HLR-362](https://youtrack.protei.ru/issue/Mobile_HLR-362) Не происходит подсчет статистики CurrentRegCount и UnblockCount

#### 2.0.6.6
- fix IMS RestorationInfo SIP Digest

#### 2.0.6.5
- [Mobile_HLR-360](https://youtrack.protei.ru/issue/Mobile_HLR-360) Не подключается ss data со статусом 1

#### 2.0.6.4
- fix IMS RestorationInfo

#### 2.0.6.3
- [Mobile_HLR-359](https://youtrack.protei.ru/issue/Mobile_HLR-359) Апдейт данных в таблице

#### 2.0.6.2
- [Mobile_HLR-359](https://youtrack.protei.ru/issue/Mobile_HLR-359) Неправильно кодируются ss-SubscriptionOption и cliRestrictionOption для CLIR

#### 2.0.6.1
- [Mobile_HLR-357](https://youtrack.protei.ru/issue/Mobile_HLR-357) Отправлять DSD при изменении ssStatus = 0

#### 2.0.6.0
- [Mobile_HLR-358](https://youtrack.protei.ru/issue/Mobile_HLR-358) Перенос функционал NoPsiGtMask с Protei_HLR_BS

#### 2.0.5.5
- [Mobile_HLR-351](https://youtrack.protei.ru/issue/Mobile_HLR-351) Модификация ip в eps-context'a абонента

#### 2.0.5.4
- [Mobile_HLR-354](https://youtrack.protei.ru/issue/Mobile_HLR-354) Не отправляем T-CSI в вызове с переадресацией

#### 2.0.5.3
- [Mobile_HLR-355](https://youtrack.protei.ru/issue/Mobile_HLR-355) Не создается черный список PLMN через API

#### 2.0.5.2
- [Mobile_HLR-353](https://youtrack.protei.ru/issue/Mobile_HLR-353) Не отправляем accessRestrictionData

#### 2.0.5.1
- [Mobile_HLR-345](https://youtrack.protei.ru/issue/Mobile_HLR-345) Ошибка ERROR_INIT_PROFILE при регистрации услуги cfu

#### 2.0.5.0
- [Mobile_HLR-347](https://youtrack.protei.ru/issue/Mobile_HLR-347) Вынести MAP Error Code и Diameter Result Code в параметры черного и белого списка

#### 2.0.4.9
- [Mobile_HLR-323](https://youtrack.protei.ru/issue/Mobile_HLR-323) Добавил команду по управления параметрами в TM_CONFIG

#### 2.0.4.8
- [Mobile_HLR-322](https://youtrack.protei.ru/issue/Mobile_HLR-322) Нет проверки VLR на нахождение в BlackList-е

#### 2.0.4.7
- [Mobile_HLR-308](https://youtrack.protei.ru/issue/Mobile_HLR-308) Возможность использования новой ветки HLR с СУБД Oracle 11g

#### 2.0.4.6
- [Mobile_HLR-336](https://youtrack.protei.ru/issue/Mobile_HLR-336) Не загружается PLMN_MASK через LoadHSSWL/load

#### 2.0.4.5
- [Mobile_HLR-335](https://youtrack.protei.ru/issue/Mobile_HLR-335) Опциональные параметры country/network при создании белого списка

#### 2.0.4.4
- [Mobile_HLR-334](https://youtrack.protei.ru/issue/Mobile_HLR-334) Ошибка парсинга LoadSubscriberReq

#### 2.0.4.3
- [Mobile_HLR-326](https://youtrack.protei.ru/issue/Mobile_HLR-326) Добавление лога со считываемой конфигурацией.

#### 2.0.4.2
- [Mobile_HLR-333](https://youtrack.protei.ru/issue/Mobile_HLR-333) "Force" Удаление m-CSI не привело к удалению пользовательской привязки

#### 2.0.4.1
- Возвращаем IncorrectParams при попытке выставить ssStatuts = 7, для ssBarr и ssData

#### 2.0.4.0
- Сброс noReplyConditionTime через API

#### 2.0.3.12
- Возвращаем ConflictSS при попытке выставить ssStatuts = 7, для ssBarr и ssData

#### 2.0.3.11
- Добавил экранирование ковычек при передаче ScscfRestorationInfo

#### 2.0.3.10
- [Mobile_HLR-327](https://youtrack.protei.ru/issue/Mobile_HLR-327) Отправили mCSI на VLR без поддержки третьей CAMEL-phase

#### 2.0.3.9
- [Mobile_HLR-331](https://youtrack.protei.ru/issue/Mobile_HLR-331) Null pointer при добавлении SSBarring

#### 2.0.3.8
- [Mobile_HLR-329](https://youtrack.protei.ru/issue/Mobile_HLR-329) NullPoinerException при добавлении абонента. Не было profiles.json

#### 2.0.3.7
- [Mobile_HLR-328](https://youtrack.protei.ru/issue/Mobile_HLR-328) Duplicate entry '34-1' for key 'UQ_SPEC_APN' при обновлении HLR-API

#### 2.0.3.6
- [Mobile_HLR-321](https://youtrack.protei.ru/issue/Mobile_HLR-321) Убрать массовую отправку ISD при изменении QoS

#### 2.0.3.5
- [Mobile_HLR-313](https://youtrack.protei.ru/issue/Mobile_HLR-313) Не отправился ISD при смене MSISDN

#### 2.0.3.4
- [Mobile_HLR-320](https://youtrack.protei.ru/issue/Mobile_HLR-320) Сохраняются дубликаты в TM_DM_SPECIFIC_APN на каждый Notify

#### 2.0.3.3
- [Mobile_HLR-316](https://youtrack.protei.ru/issue/Mobile_HLR-316) fix

#### 2.0.3.2
- [Mobile_HLR-315](https://youtrack.protei.ru/issue/Mobile_HLR-315) INTERNAL_ERROR при смене статуса

#### 2.0.3.1
- [Mobile_HLR-317](https://youtrack.protei.ru/issue/Mobile_HLR-317) Добавить проверку валидности ip4/ip6

#### 2.0.3.0
- [Mobile_HLR-316](https://youtrack.protei.ru/issue/Mobile_HLR-316) Добавление новых методов в API

#### 2.0.2.0 
- [Mobile_HLR-306](https://youtrack.protei.ru/issue/Mobile_HLR-306) Сделать файл profiles.json опциональным

#### 2.0.1.99
- [Mobile_HLR-302](https://youtrack.protei.ru/issue/Mobile_HLR-302) неправильно формировался PDA запрос, для отправки ISD

#### 2.0.1.98
- fix lb патча (2.0.1.6)

#### 2.0.1.97
- Italtel fix (odb, msisdn)

#### 2.0.1.96
- Вместо черных списков, изменялись белые

#### 2.0.1.95
- Добавить в таблицу TM_IMS_ROAMING_SCSCF поле NSTATE для определения статуса регистрации общих PublicIdentity

#### 2.0.1.94
- Предача Ind и Amf в режиме работы с HSM

#### 2.0.1.93
- добавить в таблицу TM_AUC HSM_ID

#### 2.0.1.92
- minifix Add impi in imsSubscriptionXml after change ImplicitlyRegisteredSet

#### 2.0.1.91
- Add EIR FK

#### 2.0.1.90
- [Mobile_HLR-257](https://youtrack.protei.ru/issue/Mobile_HLR-257) ERROR-ы при запросе на добавление уже существующего у абонента TS

#### 2.0.1.89
- [Mobile_HLR-282](https://youtrack.protei.ru/issue/Mobile_HLR-282) Alarm (Jdbc Alarm)

#### 2.0.1.88
- [Mobile_HLR-263](https://youtrack.protei.ru/issue/Mobile_HLR-263) В ISD добавил информацию по SS, попроавил удаление/изменение SsBs

#### 2.0.1.87
- [Mobile_HLR-192](https://youtrack.protei.ru/issue/Mobile_HLR-192) Отправка Cx Registration-Termination-Request по команде администратора

#### 2.0.1.86
- [Mobile_HLR-293](https://youtrack.protei.ru/issue/Mobile_HLR-293) Ошибка в сохранении IMEI

#### 2.0.1.85
- RT after chage ImplRegSet

#### 2.0.1.84
- add FK in TM_IMS_ROAMING_SCSCF, PP after chage ImplRegSet

#### 2.0.1.83
- [Mobile_HLR-290](https://youtrack.protei.ru/issue/Mobile_HLR-290) Не отправляется ISD при смене статуса барринга

#### 2.0.1.82
- [Mobile_HLR-188](https://youtrack.protei.ru/issue/Mobile_HLR-188) AMSISDN

#### 2.0.1.81
- [Mobile_HLR-289](https://youtrack.protei.ru/issue/Mobile_HLR-289) Заполнение полей переадресации null

#### 2.0.1.80
- fix getSdIms without PrivateIdentity

#### 2.0.1.79
- minifix TM_IMS_PUBLIC_IDENTITY change index

#### 2.0.1.78
- minifix HLRImsServiceProfileDAOImpl

#### 2.0.1.77
- [Mobile_HLR-253](https://youtrack.protei.ru/issue/Mobile_HLR-253) Отправка PPR при изменении implSet, добавления флага для дефолтного IMPU в ImplSet

#### 2.0.1.76
- [Mobile_HLR-281](https://youtrack.protei.ru/issue/Mobile_HLR-281) Просьба поменять State, который провижнится на HLR при административной блокировке карты. Сейчас 1, нужен 3

#### 2.0.1.75
- [Mobile_HLR-263](https://youtrack.protei.ru/issue/Mobile_HLR-263) Удаление ProvisinedSs при выставлении ssStatus=0

#### 2.0.1.74
- [Mobile_HLR-278](https://youtrack.protei.ru/issue/Mobile_HLR-278) Current operation note is present now! Remove before set.

#### 2.0.1.73
- [Mobile_HLR-276](https://youtrack.protei.ru/issue/Mobile_HLR-276)

#### 2.0.1.72
- Добавить внешний ключи в TM_IMS_ROAMING_SCSCF, в getSdIms добавить вывод Private Identities, которые привязаны к ImplicitlyRegisteredSet

#### 2.0.1.71
- Вынесен Implicitly Registered Set как отдельная сущность + RestorationInfo

#### 2.0.1.70
- fix Поправил отвязку черного списка по имени IMS: вернул использование iplicity registered set

#### 2.0.1.69
- [Mobile_HLR-274](https://youtrack.protei.ru/issue/Mobile_HLR-274) Проверка регистрации при формировании ISD/DSD

#### 2.0.1.68
- [Mobile_HLR-256](https://youtrack.protei.ru/issue/Mobile_HLR-256) Изменение CUG, авторизация CUG вызова
- [Mobile_HLR-266](https://youtrack.protei.ru/issue/Mobile_HLR-266) Не привязался BL к профилю
- [Mobile_HLR-271](https://youtrack.protei.ru/issue/Mobile_HLR-271) ISD. SS-Data без указания basicService

#### 2.0.1.67
- [Mobile_HLR-265](https://youtrack.protei.ru/issue/Mobile_HLR-265) Не отправляется ISD на SGSN при смене QOS профиля абоненту

#### 2.0.1.66
- [Mobile_HLR-260](https://youtrack.protei.ru/issue/Mobile_HLR-260) Ошибка при удалении msisdn через API (если msisdn
- пустая строка, то в базе меняем на null)

#### 2.0.1.65
- [Mobile_HLR-260](https://youtrack.protei.ru/issue/Mobile_HLR-260) Ошибка при удалении msisdn через API

#### 2.0.1.64
- [Mobile_HLR-261](https://youtrack.protei.ru/issue/Mobile_HLR-261) Сформировали UDT Malformed Packet ответ на SRI_FSM

#### 2.0.1.63
- [Mobile_HLR-262](https://youtrack.protei.ru/issue/Mobile_HLR-262) HSS включает в ULA RAT_FREQ_SELECTION_PRIORITY_ID=0

#### 2.0.1.62
- [Mobile_HLR-258](https://youtrack.protei.ru/issue/Mobile_HLR-258) minifix

#### 2.0.1.61
- [Mobile_HLR-258](https://youtrack.protei.ru/issue/Mobile_HLR-258) Не работает смена IMSI через API

#### 2.0.1.60
- [Mobile_HLR-253](https://youtrack.protei.ru/issue/Mobile_HLR-253) Отправка PPR (Push-Profile-Request) при изменении профиля

#### 2.0.1.59
- [Mobile_HLR-226](https://youtrack.protei.ru/issue/Mobile_HLR-226) Изменен формат запроса на изменение белых/черных листов

#### 2.0.1.58
- [Mobile_HLR-252](https://youtrack.protei.ru/issue/Mobile_HLR-252) При загрузке карты в HLR через ADD_SUBSCRIBER вставляется строка нулевой длинны в поля TM_SUBSCRIBER_PROFILE.STRDEFAULTFORWARDINGNUMBER и TM_SUBSCRIBER_PDP.STRPDP_ADDRESS

#### 2.0.1.57
- [Mobile_HLR-251](https://youtrack.protei.ru/issue/Mobile_HLR-251) Некорректный ответ на запрос provisioning от биллинга

#### 2.0.1.56
- [Mobile_HLR-228](https://youtrack.protei.ru/issue/Mobile_HLR-228) Нотификация при добавлении взаимоисключающих SS в профиль через API

#### 2.0.1.55
- [Mobile_HLR-249](https://youtrack.protei.ru/issue/Mobile_HLR-249) Расхождения в именованиии параметров со старой версией

#### 2.0.1.54
- Mobile-57 Добавить PK во все таблицы

#### 2.0.1.53
- minifix

#### 2.0.1.52
- [Mobile_HLR-247](https://youtrack.protei.ru/issue/Mobile_HLR-247) Не передаётся MSISDN на API из destReference registerSS

#### 2.0.1.51
- [Mobile_HLR-246](https://youtrack.protei.ru/issue/Mobile_HLR-246) Некорректный qos в ISD

#### 2.0.1.50
- [Mobile_HLR-244](https://youtrack.protei.ru/issue/Mobile_HLR-244) Некорректно добавляются pdp и eps контексты

#### 2.0.1.49
- Добавление внешних ключей

#### 2.0.1.48
- [Mobile_HLR-240](https://youtrack.protei.ru/issue/Mobile_HLR-240) Отправка SRI_Resp без списка SS-кодов

#### 2.0.1.47
- [Mobile_HLR-239](https://youtrack.protei.ru/issue/Mobile_HLR-239) Не отправили номер переадресации в SRI_Resp

#### 2.0.1.46
- [Mobile_HLR-153](https://youtrack.protei.ru/issue/Mobile_HLR-153) Добавить в профиль таймер периодического LU

#### 2.0.1.45
- [Mobile_HLR-224](https://youtrack.protei.ru/issue/Mobile_HLR-224) Не принимает OMI соединения при некорректном файле profiles.json

#### 2.0.1.44
- [Mobile_HLR-236](https://youtrack.protei.ru/issue/Mobile_HLR-236) Не добавлят в ISD/DSD инормацию об изменении T-CSI

#### 2.0.1.43
- [Mobile_HLR-235](https://youtrack.protei.ru/issue/Mobile_HLR-235) Не возвращали Result=ERROR;

#### 2.0.1.42
- [Mobile_HLR-233](https://youtrack.protei.ru/issue/Mobile_HLR-233) В SetRoaming не сохранялся LMSI Mobile_HLR-234 Выставление значения DTPURGED при UL , UL_GPRS

#### 2.0.1.41
- [Mobile_HLR-226](https://youtrack.protei.ru/issue/Mobile_HLR-226) fix управленик белыми/черными листами

#### 2.0.1.40
- [Mobile_HLR-137](https://youtrack.protei.ru/issue/Mobile_HLR-137) Управление RoamingAgreement

#### 2.0.1.39
- [Mobile_HLR-230](https://youtrack.protei.ru/issue/Mobile_HLR-230) Выставлять VLR=null при CL

#### 2.0.1.38
- [Mobile_HLR-223](https://youtrack.protei.ru/issue/Mobile_HLR-223) Нельзя загрузить PDP без QOS, minifix 219,

#### 2.0.1.37
- [Mobile_HLR-219](https://youtrack.protei.ru/issue/Mobile_HLR-219) Некорректное выставление битов forwarding reason в forwardingOptions тригером TM_PROVISIONED_SS_FORW_BEFORE_INSERT

#### 2.0.1.36
- удален JsonCustomConverter

#### 2.0.1.35
- добавлен JsonCustomConverter Bean

#### 2.0.1.34
- добавлен JsonCustomConverter для вывода многострочного json

#### 2.0.1.33
- изменен формат XML imsUserData

#### 2.0.1.32
- minifix

#### 2.0.1.31
- Разделил вывод ims профиле по ключам

#### 2.0.1.30
- обавил недостающие WithOperationNote

#### 2.0.1.29
- minifix cdr, вывод в getProfileResponse imsUserData и roaming-scscf-info

#### 2.0.1.28
- правление refferedScscf/Capability/ChargingInforamtion

#### 2.0.1.27
- minifix Управление ServiceProfile/Ifc/ImsPartProfile

#### 2.0.1.26
- Управление ServiceProfile/Ifc/ImsPartProfile

#### 2.0.1.25
- Управление AS

#### 2.0.1.24
- Не работал ClearScscf

#### 2.0.1.23
- [Mobile_HLR-213](https://youtrack.protei.ru/issue/Mobile_HLR-213) Расширить длину поля TM_AUC_IND.STRNODEADDRESS

#### 2.0.1.22
- [Mobile_HLR-209](https://youtrack.protei.ru/issue/Mobile_HLR-209) Ошибка на api при S6 PurgeUE

#### 2.0.1.21
- [Mobile_HLR-204](https://youtrack.protei.ru/issue/Mobile_HLR-204) Собственная адресация для каждой группы в рамках HSS

#### 2.0.1.20
- delete fro TM_CAMEL_SUBSCRIBER when delete CSI Profile

#### 2.0.1.19
- fixRoamingSgsn

#### 2.0.1.18
- minifix

#### 2.0.1.17
- Не очищаем TM_ROAMING_SGSN

#### 2.0.1.16
- [Mobile_HLR-201](https://youtrack.protei.ru/issue/Mobile_HLR-201) Изменение EPS QoS, привязанного к абоненту, не привело к отправке ISR на MME

#### 2.0.1.15
- Fix FK TM_SUBSCRIBER_PDP

#### 2.0.1.14
- [Mobile_HLR-181](https://youtrack.protei.ru/issue/Mobile_HLR-181) При отсутствии ТелеСервиса МТ СМС в ответ на SRI_FSM необходимо отправлять ошибку Teleservice Not Provisioned

#### 2.0.1.13
- Не отправляли CamelPhase в ответ на GetSD(changeSS)

#### 2.0.1.12
- Add uq Ts Bs

#### 2.0.1.11
- fixDCsiCriteria

#### 2.0.1.10
- fixOdb

#### 2.0.1.9
-  freq#198 Автоматическое добавление Temporary Public User Identity с BarringIndication=1 при регистрации по Temporary Public User Identity (XML)

#### 2.0.1.8
-  freq#195 Связывание Public idenity с несколькими Private identity

#### 2.0.1.7
-  TM_ROAMING_SGSN сделал NSUBSCRIBERID PK

#### 2.0.1.6
-  TM_SMS_DATA сделал NSUBSCRIBERID PK

#### 2.0.1.5
-  Значения AMF вынесены в TM_AUC

#### 2.0.1.4
-  ims digest + Mobile_HLR-190,191

#### 2.0.1.3
-  Управление PDP and CSi

#### 2.0.1.2
-  SetShUserData

#### 2.0.1.1
-  bug#175 Неверный формат GetAsResp

#### 2.0.1.0
-  freq#156 Скрытие логина и пароля подключения к БД

#### 2.0.0.12
- bug#170 API_BS. Unknown column 'ROWNUM'

#### 2.0.0.11
- minifix бодавление в EPS значения из QOS_EPS, была ошибка в именах некоторых параметров TM_ROAMING_SGSN

#### 2.0.0.10
- bug#148 (убрал передачу msisdn в getIsd, при изменении msisdn, новое значение придет в Pda после выполнения ChaneProfile)

#### 2.0.0.9 
- bug#150 (при загрузке eps через Load, отсутсвующие значения сохраняются как -1)
-         
- bug#152 (Некорректно отображаются параметры EPS-контекстов в ответе на get profile )

#### 2.0.0.8 
- bug#150 (неверное количество параметров в TM_SUBSCRIBER_PROFILE insert)

#### 2.0.0.7 
- bug#146, 147, 149 (minifix)

#### 2.0.0.6 
- ProteiSupport Add in GetSdImsResp mmtelIndication

#### 2.0.0.5 
- bug#146, 147 (актуализация)

#### 2.0.0.4 
- minifix Ошибка в синтаксисе mysql

#### 2.0.0.3 
- bug: Mobile_HLR-121  Упорядочить данные выдаваемые на S-CSCF в SAA согласно CxDataType_Rel11.xsd

#### 2.0.0.2 
- winter 3.0, java 8, mqsl connector 5.1.46

#### 2.0.0.1 
- Добавление IMS

#### 2.0.0.0 
- Объединение API и BS, добавление поддержки MySQL

#### 1.1.0.1 
- freq #16991: HLR.API: Выводить roamingNotAllowed в GetProfile

#### 1.1.0.0 
- freq #16624: HLR.API: новая система авторизации и проверки прав

#### 1.0.3.41
- freq # 16689 HLR.API Скрыть dmNurrpSgsn из roaming-sgns-info

#### 1.0.3.40
- bugfix #27828 HLR_API: убрана отправка ISD с актуальным списком при удалении TS

#### 1.0.3.39
- freq #16246 HLR_API: получение списка BL на карте с помощью get_profile

#### 1.0.3.38
- freq #27: HLR_API: добавлена информация по purge в EPS

#### 1.0.3.37
- к freq #15997: HLR_API: добавлены проверки на невозможность задания белых и чёрных списков одновременно

#### 1.0.3.36
- bug #27418 HLR_API: ошибки при выполнении SetMSISDNBatch к несуществующей карты

#### 1.0.3.35
- к freq #15997: HLR_API: добавлены чёрный списки по аналогии с белыми

#### 1.0.3.34
- к freq #15545
- исправлена отправка CL по DM_IsExistWL
- используются параметры MCCMNC из MME/SGSN REALM вместо HOST

#### 1.0.3.33
- В функциях FN_IsExistWL и FN_DM_IsExistWL возвращаемое значение изменено на integer

#### 1.0.3.32
- freq #15648: HLR_API: убрана отправка группы абонента в ISD и DSD

#### 1.0.3.31
- freq #15675 Billing:ограничение провижнинга удаления карт

#### 1.0.3.30
- freq #15648: HLR_API: добавлен контроль групп, изменен формат параметра lcs в changeProfile
-          --- отправка CL разделена на HLR/HSS/ALL для случаев белых списков

#### 1.0.3.29
- freq #15545: HLR_API: отправка CancelLocation при изменении WL если абонент не входит в WL

#### 1.0.3.28
- freq #15616: HLR_API: OMI active-standby

#### 1.0.3.27
- freq #15601: Billing: change_imsi в случае рассинхронизации профилей (imsi-msisdn) между биллингом и HLR.

#### 1.0.3.26
- freq #15527: добавлены поля PDP
- ext2QosSubscribed, ext3QosSubscribed, ext4QosSubscribed

#### 1.0.3.25
- freq #15549: добавлена возможность получение транспортного ключа в getProfile

#### 1.0.3.24
- freq #15304: реализовано получение идентификатора профиля lcs в getProfile и его изменение/удаление через changeProfile

#### 1.0.3.23
- freq #15304: добавлен параметр LCS_ID (location categories) в запрос HLRSubscriberService#addSubscriber и в profile.json

#### 1.0.3.22
- freq #15389: добавлен метод регистрации пустых подписчиков HLRSubscriberService#addAndActivateEmptySubscribers

#### 1.0.3.21
- пересборка с winter.http 2.1.3

#### 1.0.3.20
- freq #15302 (Добавить roaming_mme_info для запроса текущей регистрации в 4G (HLR_API))

#### 1.0.3.19
- добавлен changeMsisdnBatch

#### 1.0.3.18
- freq #15250 HLR_API: в getProfile добавлены eps-context-data и eps-data

#### 1.0.3.17
- bugfix #25895 HLR_API: добавлен анализ Forw в результате выполнения функции

#### 1.0.3.16
- freq #14926 (HLR_API: Оптимизация времени запроса)        
- исправлена незакрытая коннекция к БД в Main

#### 1.0.3.15
- bugfix #25880: добавлена поддержка отправки ISD и DSD при коммандах teleservicesToAdd, teleservicesToDelete, bearerservicesToAdd, bearerservicesToDelete

#### 1.0.3.14
- org.apache.commons.collections -> org.apache.commons.collections4

#### 1.0.3.13
- переход на winter2

#### 1.0.3.12
- freq #14665: HLR + API : Возможность задавать несколько белых списков, а не один.

#### 1.0.3.11
- ChangeProfileRequest#ChangePdpDataRequest
- добавлен список контекстов для добавления, аналог TeleServices
- список добавляется, остальные контексты удаляются

#### 1.0.3.10
- ChangeProfileRequest
- добавлены параметры TeleServicesToAdd, BearerServicesToAdd и TeleServicesToDelete, BearerServicesToDelete для точечного удаления и добавленя tele и bearer сервисов

#### 1.0.3.9
- freq #14260: добавлен параметр SS_TeleServices в profile.json, добавляется при LoadSubscriber

#### 1.0.3.8
- bugfix #25162: changeProfile
- в запросе changeSSData отправляется теперь реальный imsi абонента

#### 1.0.3.7
- freq #14259: SS в profile.json разбит на Active_SS и NotActive_SS

#### 1.0.3.6
- freq #14159: добавлено поле EPS_DEF_CONTEXT_ID в profile.json, поле EPS_PDP переименовано в EPS_CONTEXTS, при отсутствии epsData в HLRSubscriberService#AddSubscriber данные полностью берутся из profile.json, если оба параметра корректно заданы

#### 1.0.3.5
- freq #14151: добалено поле AucData в AddSubscriberRequest как возможность добавлять данные о сим-карте при добавлении профиля

#### 1.0.3.4
- bugfix #24723: исправлена проблема отправки ISD при смене MSISDN

#### 1.0.3.3
- bugfix #24732: ошибка в параметрах при формировании DSD команды + запрет отправки GPRS в ISD при отвязке

#### 1.0.3.2
- refactoring command service
- убран метод ISD_SGSN, теперь HLR решает, какие параметры отправлять на VLR, а какие на SGSN

#### 1.0.3.1
- bugfix #24589 & freq #14134
- PDP запрос отправляется на SGSN, добавлена команда DSD_SGSN, newMsisdn отправляется как на VLR, так и на SGSN

#### 1.0.3.0
- bugfix # : при добавлении локировок изменилось поведение поиска по imsi / msisdn, возвращено игнорированием пустых параметров imsi / msisdn в запросе

#### 1.0.2.9
- bugfix #24656: HLRProfileService#change Profile
- на смену ss отсылается действительный imsi, а не указанный в запросе (который может быть null, если смена по msisdn)

#### 1.0.2.8
- freq #14102: updateAll у HLRCsiDAO изменён на mergeAll, где старые записи не удаляются, а изменяют profile-contextId если есть, добавляются, если нет

#### 1.0.2.7
- freq #14090: добавлена отправка SMS_CSI на VLR
- сервисы переписаны на winter#LockService, защита от одновременных изменений профилей по идентификатору

#### 1.0.2.6
- freq #14006: добавлена смена MSISDN в changeProfile

#### 1.0.2.5
- bugfix #24484: winter fix NPE HttpLogger + no partial ok refactoring

#### 1.0.2.4
- freq #13956 (Billing: Назначение / смена профиля через WEB ТО биллинга : возможность получить WhiteList абонента)

#### 1.0.2.3
- мелкие правки по freq #13296

#### 1.0.2.2
- freq #13926
- addSubscriber & changeProfile
- добалена привязка абонентов к 4G, работа с EPS параметрами

#### 1.0.2.1
- bug 24341

#### 1.0.2.0
- hss api (freq 13852)

#### 1.0.1.1
- freq 13851

#### 1.0.1.0
- выделение модулей api/remote

#### 1.0.0.5
- bugfix #23891 (Падение в коре при удалении T-CSI профиля (HLR))

#### 1.0.0.4
- freq #13653 (HLR.API.Привязка WHITE_LIST_VLR абоненту через API)

#### 1.0.0.3
- freq #13217
- ChangeProfile : привязка PDP профиля абоненту

#### 1.0.0.2
- улучшена система логирования, аспектов, ошибки функций БД прнавильно учитываются в журнале и логах

#### 1.0.0.1
- freq #13278
- добавлено логирование операций в CDR
- OperationNote

#### 1.0.0.0
- начальная версия
