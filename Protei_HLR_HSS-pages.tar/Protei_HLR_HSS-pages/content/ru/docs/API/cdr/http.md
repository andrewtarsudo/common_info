---
title : "operation_journal.log"
description : "Журнал HTTP-транзакций"
weight : 4
---

## Описание CDR

appender = operation\_journal

Порядок полей:
1.  DT            - Время выполнения команды
2.  Operation     - Тип команды
3.  Status        - Статус выполнения
4.  ExecutionTime - Длительность выполнения (ms)
5.  SentToHlr     - Инициализация команды на HLR Core
6.  UserHost      - Хост пользователя системы
7.  UserName      - Имя пользователя системы
8.  MSISDN        - MSISDN абонента
9.  IMSI          - IMSI абонента
10. Params        - Список измененных параметров абонента


### Status - результат обработки запроса

1. OK
2. KO
3. NOT_FOUND
4. NOT_AVAILABLE
5. PERMISSION_DENIED
6. INVALID_AUTH
7. INTERNAL_ERROR
8. ALREADY_EXIST
9. INTEGRITY_VIOLATION
10. OBJECT_BUSY
11. INCORRECT_PARAMS
12. TEMPORARY_FAILURE
13. HLR_SERVER_ERROR
14. HLR_API_NOT_AVAILABLE
15. INVALID_PROFILE
16. HLR_OBJECT_BUSY
17. SAME_IMSI
18. NOTHING_CHANGED
19. OBJECT_LINKED
20. SUPPLEMENTARY_SERVICE_CONFLICT
21. REMOTE_HOST_UNREACHABLE


