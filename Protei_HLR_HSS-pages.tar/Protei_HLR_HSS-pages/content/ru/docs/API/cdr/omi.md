---
title : "bs_operation_journal.log"
description : "Журнал OMI-транзакций"
weight : 4
---

## Описание CDR

appender = bs\_operation\_journal

Порядок полей:
1.  DT            - Время выполнения команды
2.  Operation     - Имя команды
3.  Status        - Статус выполнения
4.  ExecutionTime - Длительность выполнения (ms)
5.  Request       - Тело запроса
6.  Response      - Тело ответа



### Status - результат обработки запроса

1. SUCCESS
2. NOT_FOUND
3. ALREADY_EXIST
4. DEALOCK
5. ERROR_INIT_PROFILE
6. ERROR
7. COMMAND_NOT_FOUND



