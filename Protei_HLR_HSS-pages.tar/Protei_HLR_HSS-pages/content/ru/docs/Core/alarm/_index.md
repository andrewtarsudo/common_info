---
title : "Аварии"
description : ""
weight : 4

---
# Генерация аварий в HLR

SNMP-идентификатор для проекта HLR - 146  

## Конфигурирование аварий

  - [HowConfig.txt](http://cvs/cgi-bin/cvsweb.cgi/ws/ATE/Doc/Utils/Alarm/HowConfig.txt)
    - описание файла конфигурации ap.cfg
  - [SNMP-Identification.doc](http://cvs/cgi-bin/cvsweb.cgi/ws/ATE/Doc/Utils/Alarm/SNMP-Identification.doc)
    - назначение SNMP-идентификаторов в дереве ПРОТЕЙ

<!-- end list -->

  - [Генерация аварий в
    OMI](http://wiki/doku.php?id=protei:doc:support:ate:omi:4_0:ap)

<table>
<thead>
<tr class="header">
<th>Компонентный тип</th>
<th>Компонентный адрес</th>
<th>Имя<br />
перем.</th>
<th>Тип<br />
переменной</th>
<th>Область<br />
допустимых<br />
значений</th>
<th>Отправка<br />
smnp-trap</th>
<th>Уровень<br />
важности<br />
трапов</th>
<th>Описание</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><strong>Оперативное состояние системы</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.General</td>
<td>HLR.General</td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>"ACTIVATE"<br />
"FAIL"<br />
"STOP"<br />
"STATUS OK"</td>
<td>+</td>
<td>ACTIVATE-normal<br />
FAIL-critical<br />
STOP-critical<br />
STATUS OK-normal</td>
<td><strong>Protei_HLR</strong><br />
ACTIVATE – старт, FAIL - аварийное завершение, STOP - ручной останов, STATUS OK - приложение активно</td>
</tr>
<tr class="odd">
<td><strong>Перезагрузка конфигурационных файлов</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.Reload</td>
<td>HLR.Reload</td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>"ACTIVATE"<br />
"FAIL"</td>
<td>+</td>
<td>info</td>
<td>Состояние перезагрузки</td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>имя конфигур.файла</td>
<td>+</td>
<td>info</td>
<td>Имя перезагружаемого конфигурационного файла + результат перезагрузки</td>
</tr>
<tr class="even">
<td><strong>Статистика по трафику</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td>HLR.Traffic.Stat</td>
<td>HLR.Traffic.Stat.All</td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>Суммарная статистика по MAP транзакциям</td>
<td>+</td>
<td>info</td>
<td>{&lt;Count&gt;;&lt;Rejected&gt;;&lt;MaxSpeed&gt;;[&lt;Time of MaxSpeed&gt;];};</td>
</tr>
<tr class="even">
<td>HLR.Traffic.Stat</td>
<td>HLR.Traffic.Stat.DM_All</td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>Суммарная статистика по DIAMETER транзакциям</td>
<td>+</td>
<td>info</td>
<td>{&lt;Count&gt;;&lt;Rejected&gt;;&lt;MaxSpeed&gt;;[&lt;Time of MaxSpeed&gt;];};</td>
</tr>
<tr class="odd">
<td>HLR.Traffic.Stat</td>
<td>HLR.Traffic.Stat.&lt;CommandName&gt;</td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>Статистика &lt;CommandName&gt; сообщений</td>
<td>+</td>
<td>info</td>
<td>{&lt;Count&gt;;&lt;Rejected&gt;;&lt;MaxSpeed&gt;;[&lt;Time of MaxSpeed&gt;];};</td>
</tr>
<tr class="even">
<td><strong>Статистика по абонентам</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td>HLR.Abonent.Stat</td>
<td>HLR.Abonent.Stat</td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>статистика</td>
<td>+</td>
<td>info</td>
<td>статистика</td>
</tr>
<tr class="even">
<td>HLR.Abonent.OperStat</td>
<td>HLR.Abonent.OperStat</td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>статистика</td>
<td>+</td>
<td>info</td>
<td>статистика</td>
</tr>
<tr class="odd">
<td><strong>Перегрузка занятых SL-логик</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.Handler.SL</td>
<td>HLR.OVRLOAD.Handler.SL</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"ACTIVATE","FAIL"}</td>
<td>+</td>
<td>normal/warning</td>
<td>Активация/деактивация перегрузки</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>Handlers=&lt;count&gt;;CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>normal/warning</td>
<td>Количество занятых SL-логик и идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение внутренних очередей примитивов</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.Queue.Logic</td>
<td>HLR.OVRLOAD.Queue.Logic</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"ACTIVATE","FAIL"}</td>
<td>+</td>
<td>normal/warning</td>
<td>Активация/деактивация превышения</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>Size=&lt;queue_size&gt;;CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>normal/warning</td>
<td>Размер очереди и идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Common лицензии</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.MINOVR</td>
<td>HLR.OVRLOAD.LICENSE.MINOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"ACTIVATE"}</td>
<td>+</td>
<td>normal</td>
<td>Превышен TrafficNominal</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>CallsCount=&lt;count&gt;;CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>normal</td>
<td>Величина TrafficNominal и идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Common лицензии прекратилось</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.MINOVR</td>
<td>HLR.OVRLOAD.LICENSE.MINOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"FAIL"}</td>
<td>+</td>
<td>warning</td>
<td>В течении CheckInterval не было превышения лицензии</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>warning</td>
<td>Идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Common лицензии в течении длительного времени</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.MAJOVR</td>
<td>HLR.OVRLOAD.LICENSE.MAJOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"ACTIVATE"}</td>
<td>+</td>
<td>normal</td>
<td>В течении TrafficTresholdInterval постоянное превышение лицензии</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>Interval=&lt;int&gt;;CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>normal</td>
<td>Величина TrafficTresholdInterval и идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Common лицензии прекратилось</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.MAJOVR</td>
<td>HLR.OVRLOAD.LICENSE.MAJOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"FAIL"}</td>
<td>+</td>
<td>warning</td>
<td>В течении CheckInterval не было превышения лицензии</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>warning</td>
<td>Идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Tcap лицензии</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.TCAP.MINOVR</td>
<td>HLR.OVRLOAD.LICENSE.TCAP.MINOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"ACTIVATE"}</td>
<td>+</td>
<td>normal</td>
<td>Превышен TcapTrafficNominal</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>CallsCount=&lt;count&gt;;CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>normal</td>
<td>Величина TcapTrafficNominal и идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Tcap лицензии прекратилось</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.TCAP.MINOVR</td>
<td>HLR.OVRLOAD.LICENSE.TCAP.MINOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"FAIL"}</td>
<td>+</td>
<td>warning</td>
<td>В течении CheckInterval не было превышения лицензии</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>warning</td>
<td>Идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Tcap лицензии в течении длительного времени</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.TCAP.MAJOVR</td>
<td>HLR.OVRLOAD.LICENSE.TCAP.MAJOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"ACTIVATE"}</td>
<td>+</td>
<td>normal</td>
<td>В течении TcapTrafficTresholdInterval постоянное превышение лицензии</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>Interval=&lt;int&gt;;CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>normal</td>
<td>Величина TcapTrafficTresholdInterval и идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Tcap лицензии прекратилось</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.TCAP.MAJOVR</td>
<td>HLR.OVRLOAD.LICENSE.TCAP.MAJOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"FAIL"}</td>
<td>+</td>
<td>warning</td>
<td>В течении CheckInterval не было превышения лицензии</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>warning</td>
<td>Идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Diam лицензии</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.DIAM.MINOVR</td>
<td>HLR.OVRLOAD.LICENSE.DIAM.MINOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"ACTIVATE"}</td>
<td>+</td>
<td>normal</td>
<td>Превышен DiamTrafficNominal</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>CallsCount=&lt;count&gt;;CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>normal</td>
<td>Величина DiamTrafficNominal и идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Diam лицензии прекратилось</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.DIAM.MINOVR</td>
<td>HLR.OVRLOAD.LICENSE.DIAM.MINOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"FAIL"}</td>
<td>+</td>
<td>warning</td>
<td>В течении CheckInterval не было превышения лицензии</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>warning</td>
<td>Идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Diam лицензии в течении длительного времени</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.DIAM.MAJOVR</td>
<td>HLR.OVRLOAD.LICENSE.DIAM.MAJOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"ACTIVATE"}</td>
<td>+</td>
<td>normal</td>
<td>В течении DiamTrafficTresholdInterval постоянное превышение лицензии</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>Interval=&lt;int&gt;;CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>normal</td>
<td>Величина DiamTrafficTresholdInterval и идентификатор ядра</td>
</tr>
<tr class="odd">
<td><strong>Превышение Diam лицензии прекратилось</strong></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>HLR.OVRLOAD.LICENSE.DIAM.MAJOVR</td>
<td>HLR.OVRLOAD.LICENSE.DIAM.MAJOVR</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td>OSTATE</td>
<td>AP_TYPE_STRING</td>
<td>{"FAIL"}</td>
<td>+</td>
<td>warning</td>
<td>В течении CheckInterval не было превышения лицензии</td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td>PARAM</td>
<td>AP_TYPE_STRING</td>
<td>CoreID=&lt;id&gt;;</td>
<td>+</td>
<td>warning</td>
<td>Идентификатор ядра</td>
</tr>
</tbody>
</table>

## Примеры конфигов

  - [ap.cfg](http://svn.protei:8080/websvn/filedetails.php?repname=ws&path=%2FProtei_HLR%2Ftrunk%2FMake%2Fconfig%2Fap.cfg)
  - [ap\_dictionary](http://svn.protei:8080/websvn/filedetails.php?repname=ws&path=%2FProtei_HLR%2Ftrunk%2FMake%2Fconfig%2Fap_dictionary)

# Мибы

  - [protei.mib](http://svn.protei:8080/websvn/filedetails.php?repname=ws&path=%2FProtei_HLR%2Ftrunk%2FMake%2Fconfig%2Fprotei.mib)
    - Миб с идентификатором ПРОТЕЙ
  - [protei\_hlr.hib](http://svn.protei:8080/websvn/filedetails.php?repname=ws&path=%2FProtei_HLR%2Ftrunk%2FMake%2Fconfig%2Fprotei_hlr.mib)
    - Миб, описывающий дерево переменных HLR

\======= Генерация трапов c помощью скрипта trap.pl ======

**Расшифровка данных, передаваемых в трапе:**  
1\. 192.168.108.111 = адрес SNMP-менеджера, который ловит трапы  
2\.
1.3.6.1.4.1.20873.146.1.1.2.1="HLR.General",1.3.6.1.4.1.20873.146.1.1.3.1="STOP"
- переменные, заданные SNMP-адресами со своими значениями, которые
передаются в трапе  
3\. enterprise = SNMP-адрес приложения (1.3.6.1.4.1.20873.146 = HLR)  
4\. specifictrap = идентификатор трапа, заданный в МИБе (1002 -
приложение HLR активно, 1001 - приложение HLR неактивно)  
  

  - Трап остановки HLR(прописывается в скрипте остановки приложения)

<!-- end list -->

``` bash
$SCRIPTS_DIR/trap.pl 192.168.108.111 public 1.3.6.1.4.1.20873.146.1.1.2.1="HLR.General",1.3.6.1.4.1.20873.146.1.1.3.1="STOP" enterprise=1.3.6.1.4.1.20873.146 specifictrap=1002
```

  - Трап падения HLR(прописывается в скрипте проверки, запущено
    приложение или нет (в ветке, когда приложения нет в
    процессах))

<!-- end list -->

``` bash
$SCRIPTS_DIR/trap.pl 192.168.108.111 public 1.3.6.1.4.1.20873.146.1.1.2.1="HLR.General",1.3.6.1.4.1.20873.146.1.1.3.1="FAIL" enterprise=1.3.6.1.4.1.20873.146 specifictrap=1002
```

  - Трап проверки активности HLR(прописывается в скрипте проверки,
    запущено приложение или нет (в ветке, когда приложения есть в
    процессах))

<!-- end list -->

``` bash
$SCRIPTS_DIR/trap.pl 192.168.108.111 public 1.3.6.1.4.1.20873.146.1.1.2.1="HLR.General",1.3.6.1.4.1.20873.146.1.1.3.1="STATUS OK" enterprise=1.3.6.1.4.1.20873.146 specifictrap=1001
```

Для системы скриптов **первой** версии трапы прописываются в следующих
скриптах:

  - Трап остановки - bin/on\_stop.sh после строки
    $SCRIPTS\_DIR/move\_log.sh
  - Трап падения - bin/scripts/\<название\_приложения\>\_repeat.sh после
    ${BIN\_DIR}/on\_finish.sh
  - Трап проверки активности -
    bin/scripts/\<название\_приложения\>\_repeat.sh в
    else-овой ветке последнего if...fi 

<!-- end list -->

``` bash
if
 ...
else
 $SCRIPTS_DIR/trap.pl...
fi
sleep $SLEEP
done
```

Для системы скриптов **второй** версии трапы прописываются в следующих
скриптах:

  - Трап остановки - stop после строки ./bin/utils/move\_log.sh
  - Трап падения - bin/utils/check\_threads.sh в начале функции start()

<!-- end list -->

``` bash
start()
{
 ./bin/utils/trap.pl...
 ...
}
```

  - Трап проверки активности - bin/utils/check\_threads.sh в else-овой
    ветке последнего if...fi (проверка MAX\_THREAD\_COUNT)

<!-- end list -->

``` bash
if ...
then
 ...
else
 ./bin/utils/trap.pl...
fi
```

\======= Перезагрузка параметров ======= Параметры конфигурации делятся
на три группы:  

1.  Параметры AP\_Agent. Формат перезагрузки:

<!-- end list -->

``` bash
./reload ap_agent.di 
./reload ap_agent.di “config/alarm/ap.cfg”
```

Если параметры не указаны, по умолчанию путь к ap.cfg = config/ap.cfg

1.  Параметры AP\_Manager

<!-- end list -->

``` bash
./reload ap_manager.di 
./reload ap_manager.di “config/alarm/ap.cfg”
```

1.  Параметры AP\_Interface(API\_CLIENT)

<!-- end list -->

``` bash
./reload ap_api_client.di 
./reload ap_api_client.di “config/alarm/ap.cfg”
```

Перезагрузить можно только приведенный ниже список параметров/секций:

1.  AP\_Agent

<!-- end list -->

``` bash
 [General]
ApplicationAddress=APP.1
MaxConnectionCount=10
[Logs]
```

1.  AP\_Manager

<!-- end list -->

``` bash
[General]
CyclicWalkTree=0
[StandardMib]
[SNMPTrap]
[SpecificTrapCA_Object]
[SpecificTrapCT_Object]
[SpecificTrapCA_Var]
```

1.  AP\_Interface(API\_CLIENT)

<!-- end list -->

``` bash
[General]
MaxOpenedTransactionCount
```

\======= Список возможных параметров в TrafficStat =======

  - {HLR(146).Traffic(2).Stat(1).All(1,1);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).All(1,1);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).UL(1,2);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).UL(1,2);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).CL(1,3);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).CL(1,3);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).PRN(1,4);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).PRN(1,4);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).ISD(1,7);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).ISD(1,7);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DSD(1,8);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DSD(1,8);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).SendPar(1,9);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).SendPar(1,9);PARAM(3);};
  - {HLR(146).Traffic(2).Stat(1).R\_SS(1,10);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).R\_SS(1,10);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).E\_SS(1,11);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).E\_SS(1,11);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).A\_SS(1,12);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).A\_SS(1,12);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).D\_SS(1,13);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).D\_SS(1,13);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).I\_SS(1,14);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).I\_SS(1,14);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).AFR(1,15);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).AFR(1,15);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).RP(1,17);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).RP(1,17);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).GP(1,18);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).GP(1,18);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).PSSD(1,19);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).PSSD(1,19);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).SRI(1,22);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).SRI(1,22);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).UL\_GPRS(1,23);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).UL\_GPRS(1,23);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).SRIFSM\_GPRS(1,24);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).SRIFSM\_GPRS(1,24);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).Reset(1,37);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).Reset(1,37);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).SRIFSM(1,45);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).SRIFSM(1,45);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).RSMDS(1,47);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).RSMDS(1,47);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).SAI(1,56);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).SAI(1,56);PARAM(3);};
  - {HLR(146).Traffic(2).Stat(1).RD(1,57);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).RD(1,57);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).SendIMSI(1,58);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).SendIMSI(1,58);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).PUSSR(1,59);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).PUSSR(1,59);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).USSR(1,60);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).USSR(1,60);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).USSN(1,61);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).USSN(1,61);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).ASC(1,64);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).ASC(1,64);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).ATM(1,65);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).ATM(1,65);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).RFSM(1,66);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).RFSM(1,66);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).PurgeMS(1,67);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).PurgeMS(1,67);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).PSI(1,70);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).PSI(1,70);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).ATI(1,71);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).ATI(1,71);PARAM(3);};
  - {HLR(146).Traffic(2).Stat(1).DM\_All(2,1);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_All(2,1);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_UA(2,300);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_UA(2,300);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_SA(2,301);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_SA(2,301);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_LI(2,302);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_LI(2,302);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_MA(2,303);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_MA(2,303);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_RT(2,304);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_RT(2,304);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_PP(2,305);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_PP(2,305);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_UD(2,306);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_UD(2,306);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_PU(2,307);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_PU(2,307);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_SN(2,308);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_SN(2,308);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_PN(2,309);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_PN(2,309);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_UL(2,316);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_UL(2,316);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_CL(2,317);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_CL(2,317);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_AI(2,318);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_AI(2,318);PARAM(3);};
  - {HLR(146).Traffic(2).Stat(1).DM\_ISD(2,319);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_ISD(2,319);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_DSD(2,320);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_DSD(2,320);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_PUE(2,321);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_PUE(2,321);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_RST(2,322);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_RST(2,322);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_NO(2,323);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_NO(2,323);PARAM(3);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_MEIC(2,324);CA(2);}; 
  - {HLR(146).Traffic(2).Stat(1).DM\_MEIC(2,324);PARAM(3);};
