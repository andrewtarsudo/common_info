---
title : "hlr_cdr.log"
description : "Журнал TCAP-транзакций"
weight : 4
---

## Описание CDR

appender = hlr\_cdr

Порядок полей:

1.  DT
2.  CommandNames
3.  OpCode
4.  IMSI
5.  CgPN
6.  CdPN
7.  TID
8.  DB\_Status
9.  TrStatus
10. ErrorCode
11. Version
12. VectorCount
13. MSISDN
14. VLR
15. MSC
16. SGSN
17. SGSNAddress
18. AlertReason
19. SCA
20. GMSC
21. InterrogationType
22. Camel
23. SuppressTCsi
24. MSRN
25. Full
26. SCF
27. SsCode
28. USSD
29. IsdCount

## Описание полей

1. **CommandName** - тип CDR-а  
2. **IMSI** - IMSI  
3. **CgPN** - GTA (SCCP) входящей транзакции  
4. **CdPN** - GTB (SCCP) входящей транзакции  
5. **MSISDN** - MSISDN  
6. **VLR** - номер VLR  
7. **MSC** - номер MSC  
8. **HLR** - номер HLR  
9. **OpCode** - код MAP-сообщения  
10. **TID** - идентификатор входящей tcap-транзакции (otid)  
11. **[nDB\_Status]()** - результат обработки запроса в DB  
12. **[nTrStatus]()** - статус завершения транзакции  
13. **ErrorCode** - код ошибки из TCAP\_RETURN\_ERROR\_IND (0 - без ошибки)  
14. **Version** - версия MAP  
15. **Full** - полнота информации в SRIResp (1 - полноценный SRI\_Resp; 0 - только VLR на основании Tm\_Roaming)  

### DB\_Status - результат обработки запроса в DB

1.  DB\_STATUS\_IS\_FORBIDDEN = -6,  
2.  DB\_STATUS\_NOT\_IN\_WHITE\_LIST = -5, not in WL  
3.  DB\_STATUS\_TIMEOUT\_ABORT = -2, DB\_TIMEOUT -\> TACP\_ABORT  
4.  DB\_STATUS\_INVALID\_DATA = -3,  
5.  DB\_STATUS\_PDA\_ERROR = -1, - нет доступа к базе  
6.  DB\_STATUS\_SUCCESS = 0, - успешно  
7.  DB\_STATUS\_UNKNOWN\_VLR = 36, for PurgeMS, success, Send TCAP\_END  
8.  DB\_STATUS\_NOT\_USE = 100,  

### TrStatus - статус завершения транзакции

1.  SL\_TIMEOUT = -1 - окончание транзакции по истечению времени ожидания  
2.  TCAP\_RETURN\_RESULT = 0 - окончание транзакции по TCAP\_RETURN\_RESULT  
3.  TCAP\_RETURN\_ERROR = 1 - окончание транзакции по TCAP\_RETURN\_ERROR  
4.  TCAP\_ABORT = 2 - окончание транзакции по TCAP\_ABORT  
5.  TCAP\_REJECT = 3 - окончание транзакции по TCAP\_REJECT  
6.  TCAP\_ERROR = 4 - окончание транзакции по TCAP\_ERROR (для НеПервых UL, нет ответа на ISD)  
7.  TCAP\_END = 5 - окончание транзакции по TCAP\_END
