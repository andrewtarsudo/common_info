---
title : "hss_cdr.log"
description : "Журнал DIAM-транзакций"
weight : 4
---

## Описание CDR

appender = hss\_cdr

Порядок полей:

1.  DT
2.  CommandName(nOpCode)
3.  OpCode
4.  UserName
5.  OrigHost
6.  DestHost
7.  SessionID
8.  DB\_Status
9.  ErrorCode
10. Msisdn
11. SgsnNumber
12. PrivateId
13. PublicId
14. Sat
15. Uat
16. AuthScheme
17. Count
18. PlmnId

## Описание полей

1.  **CommandName** - тип CDR-а  
2. **UserName** - IMSI  
3. **OrigHost** - Хост передающей стороны  
4. **DestHost** - Хост принимающей стороны  
5. **MSISDN** - MSISDN  
6. **SGSN\_Number** - номер SGSN  
7. **SessionID** - идентификатор DIAMETER сессии  
8. **[nDB\_Status]()** - результат обработки запроса в DB  
9. **nErrorCode** - код ошибки из ResultCode (2001 - без ошибки)  
10. **PrivateId** - Идентификатор в IMS аналог IMSI  
11. **PublicId** - Идентификатор в IMS аналог MSISDN  
12. **Sat** - Значение Server-Assignment-Type  
13. **Uat** - Значение User-Athorization-Type  
14. **AuthScheme** - Схема аутентификации  
15. **Count** - Количество векторов аутентификации  
16. **PlmnId** - Идентификатор сети  

### DB\_Status - результат обработки запроса в DB

1.  DB\_STATUS\_IS\_FORBIDDEN = -6,  
2.  DB\_STATUS\_NOT\_IN\_WHITE\_LIST = -5, not in WL  
3.  DB\_STATUS\_TIMEOUT\_ABORT = -2, DB\_TIMEOUT -\> UNABLE_TO_COMPLY  
4.  DB\_STATUS\_INVALID\_DATA = -3,  
5.  DB\_STATUS\_PDA\_ERROR = -1, - нет доступа к базе  
6.  DB\_STATUS\_SUCCESS = 0, - успешно  
8.  DB\_STATUS\_NOT\_USE = 100,
