---
title : "Описание Core"
description : ""
weight : 3

---