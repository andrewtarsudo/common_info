---
title : "trafic_stat.log"
description : "Журнал статистики по трафику"
weight : 4
---

## Описание CDR

appender = trafic\_stat

Порядок полей:

1. **DateTime** - Дата-Время сброса статистики
2. **OpCode** - Operation code (0 - All - статистика по всем типам транзакций)
3. **MsgName** - Краткое название транзакции (All - все транзакции)
4. **SuccessTrCount** - Кол-во успешных транзакций
5. **FailTrCount** - Кол-во неуспешных транзакций
6. **ErrorTrCount** - Кол-во неуспешных транзакция с разбивкой по  ошибкам, формат: { {ErrorCode1;Count2;};{ErrorCode2;Count2};...{ErrorCodeN;CountN} }
7. **TransitTrCount** - Кол-во транзитных транзакций (SAI, SRIFSM)
8. **MaxSpeed** - Макс. кол-во транзакций, посчитанное за интервал (statistics.cfg->Check)
