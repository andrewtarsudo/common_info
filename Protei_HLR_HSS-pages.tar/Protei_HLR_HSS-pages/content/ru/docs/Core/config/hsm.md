---
title : "hsm.cfg"
description : "Файл настройки работы с HSM модулем"
weight : 4
---

Ключ для reload - **hsm.cfg**.

Name | Description | Type | Value | Default | O/M | P/R | Example
:-----|:-----------------|------|------|---------|-----|-----|-----
**[Server]** ||
IP | Адрес сервера HSM | ip |  |  | M | P
Port | Порт сервера HSM | int |  |  | M | P
**[LocalAddr]** ||
IP | Локальный адрес | ip |  |  | M | P
Port | Локальный порт | int |  |  | M | P
**[Timers]** ||
WaitAnswer | Время ожидания ответа | int | ms | 2000 | O | R |
