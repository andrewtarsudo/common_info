---
title : "hlr.cfg"
description : "Файл настройки работы приложения"
weight : 4
---

Ключ для reload - **hlr.cfg**.

 Name | Description | Type | Value | Default | O/M | P/R | Example
:-----|:-----------------|------|------|---------|-----|-----|-----
**[General]** ||
CoreCount | Количество процессов| int | 1-7 | 2 | M | P
HLR_Handlers | Количество обработчиков HLR | int | | 10000 | M | P
HSS_Handlers | Количество обработчиков HSS | int | | HLR_Handlers | M | P
GT | SCCP адрес HLR | string | | | O | R
RoutingIndicator | SCCP.RoutingIndicator HLR | int | | | O | R
UseChangeGTinTCAP_BEGIN | Использовать подмену SCCP адреса на значение GT | int | 0/1 | 0 | O | R
LoadBlock | Количество загружаемых элементов в одной порции (Формула для расчета значения параметра: 0.9 * SegmentResponseTimeOut / 6, где SegmentResponseTimeOut - значение из om_interface.cfg [Client], 6 - время в мс необходимое для загрузки одного абонента (получено экспериментальным путем)) | int | 100-20000 | 100 | O | R 
LoadDataDir | Директория загрузки профиля | string | | LoadSubscriber | O | R
LoadWL_Dir | Директория загрузки белого списка | string | | LoadWL | O | R
LoadHSSWL_Dir | Директория загрузки белого списка для HSS | string | | LoadHSSWL | O | R
LoadBL_Dir | Директория загрузки черного списка | string | | LoadBL | O | R
LoadHSSBL_Dir | Директория загрузки черного списка для HSS | string | | LoadHSSBL | O | R
ResetDir | Директория запуска Reset | string | | Reset | O | R
ResetHSSDir | Директория запуска Reset | string | | ResetHSS | O | R
UCSIDir | Директория загрузки USSD CSI | string | | UCSI | O | R
LoadAS_Dir | Директория загрузки информации о серверах приложений (IMS) | string | | LoadAS | O | R
VirtualGT | Виртуальный GT HLR | string | | | O | R
TCAP_Timer | Таймер на ожидание ответа | int (sec) | | 12 | O | R
PSI_TCAP_Timer | Таймер ожидания ответа на PSI-транзакции | int (sec) | | TCAP_Timer | O | R
USSD_Timer | Таймер на ожидание ответа на USSD-транзакции | int (sec) | | 600 | O | R
EnabledReset | Посылка MAP_Reset при старте HLR | int (sec) | 0/1 | 0 | O | R
CountryCode | Код страны для преобразования MSISDN из national в int (SRI) | string | | | O | R
TypeBs | Тип используемого BS | int | 0/1 (0 - BS(Oracle); 1 - API_BS(Oracle/Mysql)) | 0 | M | R
HLR_ID | Идентификатор HLR, используется для выбора SCCP_GT и DiameterHost | int | | | O | R
UseHSM | Использование модуля HSM для расчета векторов аутентификации | int | 0/1 | 0 | O | R
UseUDP | Использование UDP нотификаций | int | 0/1 | 0 | O | R
SupportShNotification | Оповещать AS об изменениях профиля | int | 0/1 | 0 | O | R
ValidUssdPreffix | Префикс для проверки правильности декодирования UssdString, если декодированная строка не начинается с этого префикса, то делаем некие магические манипуляции, после чего пытаемся декодировать повторно. Если префикс не задан, то проверка не осуществляется (Mobile_HLR-407) | string | | | O | R
**[Database]** | Управление подключением к API |
ReestablishTimeout | Таймер повтора установки соединения | int (sec) | | 5 | M | P
PollReqTimeout | Таймер периодической проверки соединения | int (sec) | | 30 | M | P
PollConfTimeout | Время ожидания ответа активности соединения | int (sec) | | 10 | M | P
DirectionID | Id основного направления из om_interface.cfg | int | | | M | R
SlaveDirectionID | Id резервного направления из om_interface.cfg | int | | | O | R
ErrorCountForSelectSlave | Количество ошибок от API, после которого управление перейдет на резервное направление | int | | | O | R
DropErrorCountTimeout | время обнуления счетчика ошибок от BS | int (sec) | | | O | R
Necromancy | Пробовать все соединения, если нет активного | int | 0/1 | 0 | O | R
BreakDownTimeout | Время, в течении которого основное направление будет не активным | int (ms) | | 30000 | O | R
**[HPLMN]** | Список масок для определения домашней сети |
**{** ||
Enable | Индикатор включения маски | int | 0/1 |  | M | R
Mask | Маска VLR/SGSN номера или PLMN сети | string | | | M | R
**}** ||||||| {1;"7926.(0,7)"} |
**[RegisterSS]** | Cписок правил для регистрации переадресации |
**{** ||
SS_Code | Код переадресации | int | | | M | R
GroupID | Идентификатор абонентской группы | int | | | M | R
FTN_Mask | Маска номера переадресации | string | | | M | R
Action | Действие для данного правила | string | Allow/Reject | | M | R
**}** ||||||| {SS_Code=41;GroupID=1;FTN_Mask="7926.(0,7)";"Allow"} |
**[SRI_GT_GMSC]** | Список масок GT_GMSC от которых разрешен SRI |
**{** ||
Enable | Индикатор включения маски | int | 0/1 |  | M | R
Mask | Маска GT_GMSC | string | | | M | R
**}** ||||||| {1;"7926.(0,7)"} |
**[ATI_GT]** | Список масок GT от которых разрешен ATI |
**{** ||
Enable | Индикатор включения маски | int | 0/1 |  | M | R
Mask | Маска GT | string | | | M | R
**}** ||||||| {1;"7926.(0,7)"} |
**[SAI_IMSI_Transit]** | Cписок масок IMSI, для которых требуется транзит SAI на определенный GT  |
**{** ||
Enable | Индикатор включения маски | int | 0/1 |  | M | R
Mask | Маска IMSI | string | | | M | R
GT | GT, на который нужно перенаправить запрос | string | | | M | R
**}** ||||||| {1;"25000.(0,10)","79260000001";} |
**[SRIFSM_GT_Transit]** | Cписок GT, для которых требуется транзит SRIFSM на определенный GT  |
**{** ||
Enable | Индикатор включения маски | int | 0/1 |  | M | R
Mask | Маска GT | string | | | M | R
GT | GT, на который нужно перенаправить запрос | string | | | M | R
**}** ||||||| {1;"7926.(0,7)","79260000001";} |
**[USSD]** | Список правил маршрутизации USSD |
**{** ||
Mask | Маска USSD | string | | | M | R
GT | GT, на который нужно перенаправить запрос | string | | | M | R
Mode | Режим обработки USSD | string | msisdn/imsi/map3 (imsi - В destinationReference записывается значение IMSI, msisdn - В destinationReference записывается значение MSISDN, map3 - режим, при котором HLR принудительно отправляет исходящий PUSSR в 3ей версии MAP, в Destination Reference на TCAP подставляется IMSI, заполняется MSISDN на MAP уровне | | M | R
Allow | Применимость данного правила к списку групп | int | 0/1 | | M | R
**}** ||||||| {"*111\#";"79584499009";"msisdn";{1;2;3;};1;}; |
**[International]** | Список правил изменения параметра MAP_RegisterSS_Arg::e_forwardedToNumber |
**{** ||
Enable | Индикатор включения маски | int | 0/1 |  | M | R
Mask | Маска номера переадресации | string | | | M | R
Delete | Первые N символов, которые нужно удалить | int | | | M | R
Insert | Новый префикс | string | | | M | R
**}** ||||||| {1;Mask="8926.(0,7)";Delete=1;Insert="7"}; |
**[SMSC]** ||
WL | Белый список GT SMSC, с которых SRIFSM нужно отправлять на GT MSC, а не на IPSmGw | [string] | | | O | R | WL={"79584499008";"79584499009"};
**[ExperimentalResult]** | В этой секции прописаны случаи, при которых нужно возвращать ошибки, связанные с EPC доменом |
AI_UnknownSubscriber | Абонент не найден при обработке AuthentictionInformation | string | | | O | R
**[ExternalHss]** | Идентификаторы стороннего HSS. Используется для отправки AIR, конвертированный из SAI, на сторонний HSS. (Italtel) |
HSS_Host | Идентификатор хоста | string | | | O | R
HSS_Realm | Идентификатор реалма | string | | | O | R
