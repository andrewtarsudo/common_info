---
title : "license.cfg"
description : "Файл настройки лицензии"
weight : 4
---

Ключ для reload - **license.cfg**.

 Name | Description | Type | Value | Default | O/M | P/R
:-----|:-----------------|------|------|---------|-----|-----
**[License]** ||
HSS | Использование HSS части | int | 0/1 | 0 | O | R
IMS | Использование IMS части | int | 0/1 | 0 | O | R
LCS | Использование LCS сервисов  | int | 0/1 | 0 | O | R
Statistics | Исрользование статистики | int | 0/1 | 0 | O | P
TimeLicense | Исрользование временнОй лиуензии | int | 0/1 | 0 | O | P
max_links | Максимальное количество соединений по MTP | int |  | 0 | C | P
**Общая лицензия по трафику** ||
TrafficNominal | Номинальный разрешенный объм трафика | int | 1-4000 | 10 | C | P
TrafficCriticalThreshold | Критическая граница превышения трафика | int |  | TrafficNominal*120/100 | C | P
TrafficThreshold | Допустимая граница превышения трафика | int |  | TrafficNominal*110/100 | C | P
TrafficThresholdInterval | Интервал времени, в которм разрешено превышение трафика | int (sec) |  | 600 | C | P
**Разделенная лицензия по трафику** ||
TcapTrafficNominal | Номинальный разрешенный объм TCAP трафика | int | 1-4000 | 10 | C | P
TcapTrafficCriticalThreshold | Критическая граница превышения TCAP трафика | int | | TcapTrafficNominal*120/100 | C | P
TcapTrafficThreshold | Допустимая граница превышения TCAP трафика | int | TcapTrafficNominal*110/100 | C | P
TcapTrafficThresholdInterval | Интервал времени, в которм разрешено превышение DIAMETER трафика | int (sec) | value | 600 | C | P
DiamTrafficNominal | Номинальный разрешенный объм DIAMETER трафика | int | 1-4000 | 10 | C | P
DiamTrafficCriticalThreshold | Критическая граница превышения DIAMETER трафика | int | value | DiamTrafficNominal*120/100 | C | P
DiamTrafficThreshold | Допустимая граница превышения DIAMETER трафика  | int | DiamTrafficNominal*110/100 | C | P
DiamTrafficThresholdInterval | Интервал времени, в которм разрешено превышение DIAMETER трафика | int (sec) | value | 600 | C | P
