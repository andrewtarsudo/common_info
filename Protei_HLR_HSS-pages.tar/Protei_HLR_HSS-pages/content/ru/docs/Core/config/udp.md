---
title : "udp.cfg"
description : "Файл настройки udp для отправки уведомлений"
weight : 4
---

Ключ для reload - **udp.cfg**.

Name | Description | Type | Value | Default | O/M | P/R | Example
:-----|:-----------------|------|------|---------|-----|-----|-----
**[General]** ||
UseUdpForEmptyMask | Отправлять UDP при пустом/неактивном списке масок | int | 0/1 | 1 | M | R
**[IMSI_Mask]** | Список масок IMSI, по которым необходимо слать udp-нотификации |
[{Enable;IMSI_Mask;}] | Enable - Индикатор включения маски, IMSI_Mask - Маска IMSI | [{int;string;}] | Enable - 0/1 | | O | R | {1;"25001.(0,10)"}
**[Server]** | Список серверов, на которые нужно слать нотификации |
**{** ||
Port | Порт сервера | int | | | M | P
IP | IP - ip-адрес сервера | string | | | M | P
SendUL | Нотификация о успешном завершении UL | int | 0\1 | 0 | O | P 
SendCL | Нотификация о успешном завершении CL | int | 0\1 | 0 | O | P
SendUL_Start | Нотификация о начале транзакции UL | int | 0\1 | 0 | O | P
SendUL_Error | Нотификация о неуспешном завершении UL | int | 0\1 | 0 | O | P
SendISD | Нотификация о успешном завершении ISD (standalone) | int | 0\1 | 0 | O | P
SendISD_Error | Нотификация о неуспешном завершении ISD (standalone) | int | 0\1 | 0 | O | P
SendSAI | Нотификация о успешном завершении SAI | int | 0\1 | 0 | O | P
SendSAI_Error | Нотификация о неуспешном завершении SAI | int | 0\1 | 0 | O | P
SendUL_GPRS | Нотификация о успешном завершении UL_GPRS | int | 0\1 | 0 | O | P
SendUL_GPRS_Error | Нотификация о неуспешном завершении UL_GPRS | int | 0\1 | 0 | O | P
**}** |||||||{5050;"192.168.100.1";1;1;1;1;1;1;1;1;1;1;}
**[LocalAddr]** | |
Port | Порт, используемый клиентом | int | | | M | P
IP | IP-адрес, используемый клиентом | string | | | M | P
