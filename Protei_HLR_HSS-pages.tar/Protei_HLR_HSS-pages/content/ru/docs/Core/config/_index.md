---
title : "Конфигурация"
description : ""
weight : 4

---

#### Используемые стандартные конфигурационные файлы
* ap.cfg
* sccp_routing.cfg
* trace.cfg
* om_interface.cfg 

#### Используемые компонентные конфигурационные файлы
* component/config.cfg
* component/m3ua.cfg

#### Конфигурационные файлы HLR/HSS
