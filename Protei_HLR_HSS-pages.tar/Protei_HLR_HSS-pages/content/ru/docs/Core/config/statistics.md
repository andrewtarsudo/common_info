---
title : "statistics.cfg"
description : "Файл настройки статистики"
weight : 4
---

Ключ для reload - **statistics.cfg**.

Name | Description | Type | Value | Default | O/M | P/R | Example
:-----|:-----------------|------|------|---------|-----|-----|-----
**[TraficStatistics]** ||
LogName | Имя аппендера | string |  | "trafic_stat" | O | P
Intervals | Значение таймеров |  |  |  |  | 
{ |  |  |  |  |  | 
Check | Период подсчета макс. кол-ва транзакций в секунду (sec) | int |  | 30 | O | R
Out | Период вывода статистики в trafic_stat (sec) | int |  | 3600 | O | R
Online | Период вывода статистики в Alarm (sec) | int |  | 15 | O | R
TcapOut | Период вывода tcap статистики (sec) | int |  | 60 | O | P
} |  |  |  |  |  | 
**[AbonentStatistics]** ||
LogName | Имя аппендера | string |  | "abonent_stat" | O | P
Intervals | Значение таймеров |  |  |  |  | 
{ |  |  |  |  |  | 
Get | Период получения статистки зарегистрированных абонетов (sec) | int |  | 3 | O | R
Check | Период проверки на актуальность данных (sec) | int |  | 300 | O | R
Out | Период вывода статистики в abonent_stat (sec) | int |  | 86400 | O | R
Online | Период вывода статистики в Alarm (sec) | int |  | 3600 | O | R
Operative | Период вывода оперативной статистики (sec) | int |  | 300 | O | R
} |  |  |  |  |  | 
