---
title : "Конфигурация компонент"
description : ""
weight : 5

---
