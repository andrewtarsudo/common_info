---
title : "auc.cfg"
description : "Файл настройки работы с AUC модулем"
weight : 4
---

Ключ для reload - **auc.cfg**.

Name | Description | Type | Value | Default | O/M | P/R | Example
:-----|:-----------------|------|------|---------|-----|-----|-----
**[Millenage]** | Параметры алгоритма Millenage |
C1 | | int | [0;255] | 1 | O | R
C2 | | int | [0;255] | 3 | O | R
C3 | | int | [0;255] | 5 | O | R
C4 | | int | [0;255] | 7 | O | R
C5 | | int | [0;255] | 9 | O | R
OP | OPerator variant algorithm configuration field | HEX-string(16 byte) | | 22 30 14 c5 80 66 94 c0 07 ca 1e ee f5 7f 00 4f | O | R
TransportKey | Транспортный ключ | HEX-string(8 byte) | | | O | R
UseQuintuplets | Использование квинтуплетов | int | 0/1| 1 | O | R
R1 | Не конфигурируется | int | [0;255] | 64 | O | P
R2 | Не конфигурируется | int | [0;255] | 0 | O | P
R3 | Не конфигурируется | int | [0;255] | 32 | O | P
R4 | Не конфигурируется | int | [0;255] | 64 | O | P
R5 | Не конфигурируется | int | [0;255] | 96 | O | P
AllowResync | Использование ресинхронизации SQN | int | 0/1 | 0 | O | R
EncAlg | Алгоритм шифрования тарнспортного ключа | int | 0-DES; 1-AES; 2-3DES | 0 | O | R
**[TestAUC]** | Параметры для тестирования алгоритмов шифрования |
RAND |  | HEX-string(16 byte) | | | O | R | 62 2D 51 91 1F 0F D2 56 52 74 A5 C8 12 BA 6F AB
AddTrace |  | int | 0/1 | 0 | O | R 
