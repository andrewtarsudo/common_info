---
title : "История версий"
description : ""
weight : 1

---
#### 2.2.67.16.1304 (2021-11-09)
[Скачать версию 2.2.67.16.1304](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/264/artifact/Make/Protei_HLR.2.2.67.16.1304.tgz)

##### Зависимость: API.2.0.34.2
[Mobile_HLR-714](https://youtrack.protei.ru/issue/Mobile_HLR-714)([1049897](https://portal.protei.ru/portal/#issues/issue:id=1049897)) ss-ErrorStatus (17) при установке переадресации с телефона
- Basic **Bug**, Заказчик: **Глобал Телеком**
- Добавлена индикация о том, что абонент зарегистрировался в роаминге

#### 2.2.67.16.1304 (2021-11-09)
[Скачать версию 2.2.67.16.1304](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/263/artifact/Make/Protei_HLR.2.2.67.16.1304.tgz)

##### Зависимость: API.2.0.34.2
[Mobile_HLR-714](https://youtrack.protei.ru/issue/Mobile_HLR-714)([1049897](https://portal.protei.ru/portal/#issues/issue:id=1049897)) ss-ErrorStatus (17) при установке переадресации с телефона
- Basic **Bug**, Заказчик: **Глобал Телеком**
- Добавлена индикация о том, что абонент зарегистрировался в роаминге

#### 2.2.67.15.1303 (2021-11-02)
[Скачать версию 2.2.67.15.1303](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/262/artifact/Make/Protei_HLR.2.2.67.15.1303.tgz)

[Mobile_HLR-767](https://youtrack.protei.ru/issue/Mobile_HLR-767)([1057548](https://portal.protei.ru/portal/#issues/issue:id=1057548)) Несоответствие HLR SCCPGT и GROUPID абонента
- Basic **Bug**, Заказчик: **Top Connect**
- Сделана отправка TCAP_BEGIN_CONF после получение информации о группе абонента

#### 2.2.67.14.1302 (2021-10-26)
[Скачать версию 2.2.67.14.1302](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/261/artifact/Make/Protei_HLR.2.2.67.14.1302.tgz)

[Mobile_HLR-762](https://youtrack.protei.ru/issue/Mobile_HLR-762)([1057216](https://portal.protei.ru/portal/#issues/issue:id=1057216)) Замечание по Mobile_HLR-704
- Basic **Bug**, Заказчик: **Top Connect**
- Исправлено имя переменной в проверке на отправку SUBSCR_REG_GPRS_ERROR_IND

#### 2.2.67.13.1301 (2021-10-19)
[Скачать версию 2.2.67.13.1301](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/260/artifact/Make/Protei_HLR.2.2.67.13.1301.tgz)

##### Зависимость: API.2.0.33.11
[Mobile_HLR-755](https://youtrack.protei.ru/issue/Mobile_HLR-755) Рассмотреть ответ на PUR
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Исправлена ошибка выбора типа Result-Code

[Mobile_HLR-757](https://youtrack.protei.ru/issue/Mobile_HLR-757) Исправить алгоритм обработки полученного LIR
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Исправлено изменение статуса абонента при получении SAR.Server-Assignment-Type = USER_DEREGISTRATION_STORE_SERVER_NAME

[Mobile_HLR-759](https://youtrack.protei.ru/issue/Mobile_HLR-759) Реализовать удаление подписок после получения на PNR ответа с кодом 5001
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлено удаление подписок AS, если в ответ на PNR вернулся код 5001 (DIAMETER_ERROR_USER_UNKNOWN)

#### 2.2.67.12.1300 (2021-09-13)
[Скачать версию 2.2.67.12.1300](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/258/artifact/Make/Protei_HLR.2.2.67.12.1300.tgz)

[Mobile_HLR-750](https://youtrack.protei.ru/issue/Mobile_HLR-750)([1054563](https://portal.protei.ru/portal/#issues/issue:id=1054563)) NI USSD
- Basic **Bug**, Заказчик: **ОАО "Воентелеком"**
- Исправлена ошибка выбора направления при отправке не первых частей USSR

#### 2.2.67.11.1299 (2021-08-27)
[Скачать версию 2.2.67.11.1299](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/256/artifact/Make/Protei_HLR.2.2.67.11.1299.tgz)

[Mobile_HLR-744](https://youtrack.protei.ru/issue/Mobile_HLR-744)([1051709](https://portal.protei.ru/portal/#issues/issue:id=1051709)) MSISDN в destinationReference при NI USSD
- Basic **Bug**, Заказчик: **ОАО "Воентелеком"**
- Добавлена смена destinationReference на IMSI, если в пришедшем NI USSD был MSISDN

#### 2.2.67.10.1298 (2021-08-24)
[Скачать версию 2.2.67.10.1298](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/255/artifact/Make/Protei_HLR.2.2.67.10.1298.tgz)

[Mobile_HLR-734](https://youtrack.protei.ru/issue/Mobile_HLR-734)([1053007](https://portal.protei.ru/portal/#issues/issue:id=1053007)) Утечка TCAP логик при недоступности HSM
- Basic **Bug**, Заказчик: **ОАО "Воентелеком"**
- Исправлено завершение TCAP транзакции

#### 2.2.67.10.1297 (2021-07-27)
[Скачать версию 2.2.67.10.1297](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/254/artifact/Make/Protei_HLR.2.2.67.10.1297.tgz)

[Mobile_HLR-734](https://youtrack.protei.ru/issue/Mobile_HLR-734)([1053007](https://portal.protei.ru/portal/#issues/issue:id=1053007)) Утечка TCAP логик при недоступности HSM
- Basic **Bug**, Заказчик: **ОАО "Воентелеком"**
- Исправлено завершение TCAP транзакции

#### 2.2.67.9.1296 (2021-06-29)
[Скачать версию 2.2.67.9.1296](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/253/artifact/Make/Protei_HLR.2.2.67.9.1296.tgz)

[Mobile_HLR-722](https://youtrack.protei.ru/issue/Mobile_HLR-722)([1047018](https://portal.protei.ru/portal/#issues/issue:id=1047018)) Утечка SL_DIAM логик при отcотсутствии ответа от HSM
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена обработка таймера ожидания ответа от HSM

#### 2.2.67.8.1295 (2021-06-28)
[Скачать версию 2.2.67.8.1295](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/252/artifact/Make/Protei_HLR.2.2.67.8.1295.tgz)

##### Зависимость: API.2.0.32.9
[Mobile_HLR-721](https://youtrack.protei.ru/issue/Mobile_HLR-721)([1047018](https://portal.protei.ru/portal/#issues/issue:id=1047018)) Для карты с аутентификацией в HSM IMS векторы рассчитываются на самом HSS
- Important **Bug**, Заказчик: **НТЦ Протей**
- Добавлена работа логики MA_SL с внешним HSM

#### 2.2.67.7.1294 (2021-06-22)
[Скачать версию 2.2.67.7.1294](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/251/artifact/Make/Protei_HLR.2.2.67.7.1294.tgz)

[Mobile_HLR-719](https://youtrack.protei.ru/issue/Mobile_HLR-719) Нет профиля абонента в ULA
- Basic **Bug**
- Добавлен анализ ошибки сохранения регистрации

#### 2.2.67.6.1293 (2021-06-17)
[Скачать версию 2.2.67.6.1293](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/250/artifact/Make/Protei_HLR.2.2.67.6.1293.tgz)

[Mobile_HLR-704](https://youtrack.protei.ru/issue/Mobile_HLR-704)([1035618](https://newportal.protei.ru/portal/#issues/issue:id=1035618)) UDP notifications
- Basic **Bug**, Заказчик: **Top Connect**
- Исправлено заполнение значений в SUBSCR_REG_GPRS_IND

[Mobile_HLR-716](https://youtrack.protei.ru/issue/Mobile_HLR-716)([1050771](https://portal.protei.ru/portal/#issues/issue:id=1050771)) Падение в core
- Important **Bug**, Заказчик: **ООО "Глобал Телеком"**
- Убрана повторная индикация об отправки CLR после понижения версии MAP

#### 2.2.67.5.1292 (2021-05-26)
[Скачать версию 2.2.67.5.1292](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/249/artifact/Make/Protei_HLR.2.2.67.5.1292.tgz)

[Mobile_HLR-712](https://youtrack.protei.ru/issue/Mobile_HLR-712)([1050135](https://portal.protei.ru/portal/#issues/issue:id=1050135)) На Notify ответ 5012 (версия с БС)
- Important **Bug**, Заказчик: **ООО "Глобал Телеком"**
- Исправлена проблема совместимости с BS

#### 2.2.67.4.1291 (2021-05-19)
[Скачать версию 2.2.67.4.1291](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/248/artifact/Make/Protei_HLR.2.2.67.4.1291.tgz)

[Mobile_HLR-687](https://youtrack.protei.ru/issue/Mobile_HLR-687)([1032831](https://portal.protei.ru/portal/#issues/issue:id=1032831)) CL на SGSN после успешного Purge (2)
- Basic **Bug**, Заказчик: **ООО "Глобал Телеком"**
- Убрана отправка лицензионных параметров на API для версии с BS

#### 2.2.67.3.1290 (2021-05-18)
[Скачать версию 2.2.67.3.1290](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/247/artifact/Make/Protei_HLR.2.2.67.3.1290.tgz)

[Mobile_HLR-704](https://youtrack.protei.ru/issue/Mobile_HLR-704)([1035618](https://newportal.protei.ru/portal/#issues/issue:id=1035618)) UDP notifications
- Basic **Bug**, Заказчик: **Top Connect**
- Исправлена нотификации по завершению ISD

#### 2.2.67.2.1289 (2021-05-18)
[Скачать версию 2.2.67.2.1289](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/246/artifact/Make/Protei_HLR.2.2.67.2.1289.tgz)

[Mobile_HLR-687](https://youtrack.protei.ru/issue/Mobile_HLR-687)([1032831](https://portal.protei.ru/portal/#issues/issue:id=1032831)) CL на SGSN после успешного Purge (2)
- Basic **Bug**, Заказчик: **ООО "Глобал Телеком"**
- Исправлена ошибка в команде с HSS на HSS_BS

#### 2.2.67.1.1288 (2021-05-11)
[Скачать версию 2.2.67.1.1288](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/245/artifact/Make/Protei_HLR.2.2.67.1.1288.tgz)

[Mobile_HLR-702](https://youtrack.protei.ru/issue/Mobile_HLR-702)([1048423](https://portal.protei.ru/portal/#issues/issue:id=1048423))  Отправка Cancel Location при переходе между узлами
- Basic **Freq**, Заказчик: **ООО "Центр 2М"**
- Асинхронная отправка CL в рамках UL

#### 2.2.67.0.1287 (2021-04-28)
[Скачать версию 2.2.67.0.1287](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/244/artifact/Make/Protei_HLR.2.2.67.0.1287.tgz)

[Mobile_HLR-702](https://youtrack.protei.ru/issue/Mobile_HLR-702)([1048423](https://portal.protei.ru/portal/#issues/issue:id=1048423))  Отправка Cancel Location при переходе между узлами
- Basic **Freq**, Заказчик: **ООО "Центр 2М"**
- Изменен порядок отправки команд CLR, ULA

#### 2.2.66.1.1286 (2021-03-29)
[Скачать версию 2.2.66.1.1286](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/243/artifact/Make/Protei_HLR.2.2.66.1.1286.tgz)

[Mobile_HLR-685](https://youtrack.protei.ru/issue/Mobile_HLR-685) Добавить поддержку параметра ICS-Indicator
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Исправлено заполнение поля

#### 2.2.66.0.1285 (2021-03-24)
[Скачать версию 2.2.66.0.1285](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/242/artifact/Make/Protei_HLR.2.2.66.0.1285.tgz)

##### Зависимость: API.2.0.31.0
[Mobile_HLR-688](https://youtrack.protei.ru/issue/Mobile_HLR-688) HSS отправляет RTR User-Name AVP и Public-Identity AVP, если в API команде указать только IMPI
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Исправлены ошибки в логике RT

[Mobile_HLR-690](https://youtrack.protei.ru/issue/Mobile_HLR-690) Добавить поддержку Profile-Update-Request с Data-Reference STN-SR
- Important **Freq**, Заказчик: **НТЦ Протей**
- Переделана логика управления ShUserData

[Mobile_HLR-691](https://youtrack.protei.ru/issue/Mobile_HLR-691) Управление SMSInformation через Sh
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена передача Origin-Host и Origin-Realm из PUR на API

[Mobile_HLR-692](https://youtrack.protei.ru/issue/Mobile_HLR-692) Не получили CgPN из конфига при отправке PSI
- Basic **Bug**, Заказчик: **ООО "Глобал Телеком"**
- Исправлена проблема с получением CgPN из конфига

#### 2.2.65.1.1284 (2021-03-09)
[Скачать версию 2.2.65.1.1284](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/241/artifact/Make/Protei_HLR.2.2.65.1.1284.tgz)

[Mobile_HLR-687](https://youtrack.protei.ru/issue/Mobile_HLR-687)([1032831](https://portal.protei.ru/portal/#issues/issue:id=1032831)) CL на SGSN после успешного Purge (2)
- Basic **Bug**, Заказчик: **ООО "Глобал Телеком"**
- Исправлена проверка регистрации на SGSN3G

#### 2.2.65.0.1283 (2021-03-01)
[Скачать версию 2.2.65.0.1283](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/240/artifact/Make/Protei_HLR.2.2.65.0.1283.tgz)

##### Зависимость: API.2.0.30.0
[Mobile_HLR-677](https://youtrack.protei.ru/issue/Mobile_HLR-677) Запрос UDR с Data-Reference-List: CSRN и TADSinformation отбивается при отсутствии User-Name AVP
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Изменена команда проверки пользователя в базе. Убрана проверка на обязательное присутствие CallReferenceInfo AVP в UDR при запросе CSRN

[Mobile_HLR-679](https://youtrack.protei.ru/issue/Mobile_HLR-679)([1041153](https://newportal.protei.ru/portal/#issues/issue:id=1041153)) Не отправляется ISD/DSD при добавлении/снятии Access Restriction Data через API
- Basic **Bug**, Заказчик: **Телематика**
- Добавлено заполнение ARD в ISD standalone

[Mobile_HLR-685](https://youtrack.protei.ru/issue/Mobile_HLR-685) Добавить поддержку параметра ICS-Indicator
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена передача ICS-Indicator на VLR/SGSN/MME

#### 2.2.64.2.1281 (2021-02-08)
[Скачать версию 2.2.64.2.1281](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/238/artifact/Make/Protei_HLR.2.2.64.2.1281.tgz)

[Mobile_HLR-669](https://youtrack.protei.ru/issue/Mobile_HLR-669)([1044575](https://newportal.protei.ru/portal/#issues/issue:id=1044575),[1044689](https://newportal.protei.ru/portal/#issues/issue:id=1044689)) Отправка Reset в ULA, хотя поддержкa Reset не заявлялась в ULR
- Basic **Bug**, Заказчик: **Телематика**
- Добавлена проверка SupportedFeatures

#### 2.2.64.1.1280 (2021-01-25)
[Скачать версию 2.2.64.1.1280](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/237/artifact/Make/Protei_HLR.2.2.64.1.1280.tgz)

[Mobile_HLR-667](https://youtrack.protei.ru/issue/Mobile_HLR-667) Потеряны imsi/msisdn в cdr ATM
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлен вывод MSISDN в CDR

[ATE-522](https://youtrack.protei.ru/issue/ATE-522) Падение при получении COMM_UP
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Сборка с исправленной версией SI

#### 2.2.64.0.1279 (2021-01-20)
[Скачать версию 2.2.64.0.1279](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/236/artifact/Make/Protei_HLR.2.2.64.0.1279.tgz)

[Mobile_HLR-661](https://youtrack.protei.ru/issue/Mobile_HLR-661) Добавить ошибку к статусу при неудачном HTTP запросе GetUserLocation
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена передача ErrorCode на API в PDA_OPERATION_CONF

[Mobile_HLR-666](https://youtrack.protei.ru/issue/Mobile_HLR-666)([1043793](https://newportal.protei.ru/portal/#issues/issue:id=1043793)) Утечка примитивов
- Important **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Не удалялись примитивы с ответами от API на SetCoreProperties в SLM

#### 2.2.63.2.1278 (2021-01-13)
[Скачать версию 2.2.63.2.1278](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/235/artifact/Make/Protei_HLR.2.2.63.2.1278.tgz)

[Mobile_HLR-662](https://youtrack.protei.ru/issue/Mobile_HLR-662)([1039491](https://newportal.protei.ru/portal/#issues/issue:id=1039491)) Для SRI_FSM MAPv1 происходит перепосылка сообщения вместо returnResultLast
- Basic **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Исправлена проверка наличия регистрации

#### 2.2.63.1.1277 (2020-12-30)
[Скачать версию 2.2.63.1.1277](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/234/artifact/Make/Protei_HLR.2.2.63.1.1277.tgz)

[Mobile_HLR-638](https://youtrack.protei.ru/issue/Mobile_HLR-638)([1038948](https://newportal.protei.ru/portal/#issues/issue:id=1038948)) Не отправляется CL сформированный запросом
- Important **Bug**, Заказчик: **Телематика**
- Добавлено выставление FinalResponseIndicator в OM_TRANSACTION_RESP (ответ на запрос от API)

#### 2.2.63.0.1276 (2020-12-24)
[Скачать версию 2.2.63.0.1276](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/233/artifact/Make/Protei_HLR.2.2.63.0.1276.tgz)

##### Зависимость: API.2.0.28.0
[Mobile_HLR-536](https://youtrack.protei.ru/issue/Mobile_HLR-536) ISD на получение EPS User State and/or EPS Location Information
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Исправлена ошибка именования параметра

[Mobile_HLR-647](https://youtrack.protei.ru/issue/Mobile_HLR-647) Добавить команду на получение конфигурации jdbc
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена передача информации о поддерживаемых функциональностях на API

[Mobile_HLR-649](https://youtrack.protei.ru/issue/Mobile_HLR-649) Реализовать механизм обработки Active-APN и Specific-APN
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Изменен формат передачи Active-APN на API

[Mobile_HLR-652](https://youtrack.protei.ru/issue/Mobile_HLR-652)([1039966](https://newportal.protei.ru/portal/#issues/issue:id=1039966)) Tcap_abort на ISD_resp
- Basic **Bug**, Заказчик: **ОАО "Воентелеком"**
- Добавлена проверка ответа на пустоту

[Mobile_HLR-653](https://youtrack.protei.ru/issue/Mobile_HLR-653) HLR возвращает в ответе на ATI информацию, которую у него не запрашивали
- Basic **Bug**, Заказчик: **ОАО "Воентелеком"**
- Изменена инициализация m_lEPS и m_lTADS на false

[Mobile_HLR-654](https://youtrack.protei.ru/issue/Mobile_HLR-654) Убрать записи о превышении лицензии из warning.log
- Low **Task**, Заказчик: **НТЦ Протей**
- Вывод переведен в TRACE под уровнем 6

[Mobile_HLR-655](https://youtrack.protei.ru/issue/Mobile_HLR-655)([1041496](https://newportal.protei.ru/portal/#issues/issue:id=1041496)) Падение в коре при нагрузочном тесте
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Одновременное обращение к общему ресурсу в абонентской статистике

[Mobile_HLR-656](https://youtrack.protei.ru/issue/Mobile_HLR-656) Убрать под лицензию использование SS7 интерфейсов
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлен параметр лицензии HLR (по умолчанию 1)

#### 2.2.62.1.1275 (2020-11-17)
[Скачать версию 2.2.62.1.1275](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/232/artifact/Make/Protei_HLR.2.2.62.1.1275.tgz)

[ATE-498](https://youtrack.protei.ru/issue/ATE-498) Обработка RedirectAnswer в DiameterInterface
- Basic **Task**, Заказчик: **НТЦ Протей**
- Сборка с DiameterInterface 4.1.8.9

#### [2.2.62.0.1274](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/231/artifact/Make/Protei_HLR.2.2.62.0.1274.tgz) (2020-10-30)
[Mobile_HLR-642](https://youtrack.protei.ru/issue/Mobile_HLR-642)([1039602](https://newportal.protei.ru/portal/#issues/issue:id=1039602)) Отправлять параметр Roaming Restricted In SGSN, если ODB с ПД не поддерживается SGSN
- Basic **Freq**, Заказчик: **ООО "Центр 2М"**
- Добавлено формирование пакета ISD с Roaming Restricted In SGSN Due To Unsupported Feature

#### [2.2.61.0.1273](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/230/artifact/Make/Protei_HLR.2.2.61.0.1273.tgz) (2020-10-27)
##### Зависимость: API.2.0.26.0
[Mobile_HLR-559](https://youtrack.protei.ru/issue/Mobile_HLR-559) RegionalSubscription
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Реализована поддержка RegionalSubscription

[Mobile_HLR-632](https://youtrack.protei.ru/issue/Mobile_HLR-632) Реализовать реснхронизацию векторов аутентификации для IMS
- Basic **Freq**, Заказчик: **Esmero**

[Mobile_HLR-633](https://youtrack.protei.ru/issue/Mobile_HLR-633) Упал в коре
- Basic **Bug**, Заказчик: **Телематика**
- Одновременное обращение к общему ресурсу в абонентской статистике

[Mobile_HLR-635](https://youtrack.protei.ru/issue/Mobile_HLR-635) Status в cdr по cancel_location при отсустствии ответа
- Basic **Bug**, Заказчик: **Телематика**
- Исправлен статус в CL, ISD, DSD, PSI, PRN. Добавлены статусы ERROR_BY_RX_TCAP_ABORT(-3) и ERROR_BY_RX_TCAP_ERROR(-4)

[Mobile_HLR-636](https://youtrack.protei.ru/issue/Mobile_HLR-636) Разделить статус для транзакций с полученным абортом и аборотом, инициированным HLR
- Basic **Bug**, Заказчик: **Телематика**
- Добавлен статус RX_TCAP_ABORT(6) в CL, ISD, DSD, PSI, PRN, ASC

[Mobile_HLR-637](https://youtrack.protei.ru/issue/Mobile_HLR-637) Отдельный таймер для SRI/PSI/PRN/ATI транзакций
- Basic **Freq**, Заказчик: **Телематика**
- Таймер PSI_TCAP_Timer переименован в Long_TCAP_Timer

[Mobile_HLR-643](https://youtrack.protei.ru/issue/Mobile_HLR-643)([1038154](https://newportal.protei.ru/portal/#issues/issue:id=1038154)) WAIT_HSM_RESP Timeout
- Basic **Bug**, Заказчик: **ОАО "Воентелеком"**
- Добавлен отдельный таймер одидания ответа от HSM

#### [2.2.60.1.1272](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/229/artifact/Make/Protei_HLR.2.2.60.1.1272.tgz) (2020-09-16)
[Mobile_HLR-625](https://youtrack.protei.ru/issue/Mobile_HLR-625) Изменить дефолтные значения c1-c5 на значения из спеки
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Изменения: c1 (1->0), c2 (3->1), c3 (5->2), c4 (7->4), c5 (9->8)

#### [2.2.60.0.1271](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/228/artifact/Make/Protei_HLR.2.2.60.0.1271.tgz) (2020-09-10)
##### Зависимость: API.2.0.24.0
[Mobile_HLR-613](https://youtrack.protei.ru/issue/Mobile_HLR-613) Сохранение посчитанного OPC в БД
- Basic **Freq**, Заказчик: **Телематика**
- Реализован механизм отправки посчитанного OPc на API

[Mobile_HLR-618](https://youtrack.protei.ru/issue/Mobile_HLR-618)([1036563](https://newportal.protei.ru/portal/#issues/issue:id=1036563)) Еженочно не отправляются подтверждения запросов
- Important **Bug**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Изменен уровень логирования с 6 на 20, при изменении абонентской статистики

[Mobile_HLR-619](https://youtrack.protei.ru/issue/Mobile_HLR-619)([1037767](https://newportal.protei.ru/portal/#issues/issue:id=1037767)) UnProxyable AIA c Result-Code DIAMETER_TOO_BUSY
- Basic **Bug**, Заказчик: **ООО "Центр 2М"**
- Добавлено заполнение P-bit в PEA если P-bit был в запросе

#### [2.2.59.5.1270](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/227/artifact/Make/Protei_HLR.2.2.59.5.1270.tgz) (2020-09-03)
##### Зависимость: API.2.0.23.4
[Mobile_HLR-606](https://youtrack.protei.ru/issue/Mobile_HLR-606)([1036326](https://newportal.protei.ru/portal/#issues/issue:id=1036326)) Не подставляем str_realm из subscriber group для Notify
- Basic **Bug**, Заказчик: **Top Connect**
- Добавлено заполнение Origin-Host, Origin-Realm значениями из ответа API

[Mobile_HLR-603](https://youtrack.protei.ru/issue/Mobile_HLR-603)([1032784](https://newportal.protei.ru/portal/#issues/issue:id=1032784)) Упал с core
- Basic **Bug**, Заказчик: **SIM Telecom**
- Исправлена работа SocketInterface

#### [2.2.59.4.1269](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/226/artifact/Make/Protei_HLR.2.2.59.4.1269.tgz) (2020-09-01)
[Mobile_HLR-615](https://youtrack.protei.ru/issue/Mobile_HLR-615) SQNms не попадает в диапазон SqnEnd
- Important **Bug**, Заказчик: **Телематика**
- Исправлен перевод hex-string -> dec

#### [2.2.59.3.1268](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/225/artifact/Make/Protei_HLR.2.2.59.3.1268.tgz) (2020-08-12)
[Mobile_HLR-604](https://youtrack.protei.ru/issue/Mobile_HLR-604)([1036283](https://newportal.protei.ru/portal/#issues/issue:id=1036283)) Не отправили CL на SGSN при UL от MME
- Basic **Bug**, Заказчик: **SIM Telecom**
- Добавлена проверка на наличие регистрации на SGSN в 3G

#### [2.2.59.2.1267](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/224/artifact/Make/Protei_HLR.2.2.59.2.1267.tgz) (2020-08-03)
[Mobile_HLR-601](https://youtrack.protei.ru/issue/Mobile_HLR-601)([1032784](https://newportal.protei.ru/portal/#issues/issue:id=1032784)) Почистить warning.log
- Basic **Bug**, Заказчик: **SIM Telecom**
- Вывод сообщения о том, что размер CSI профиля превысел 150 байт, перенесен в trace (level 10)

#### [2.2.59.1.1266](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/223/artifact/Make/Protei_HLR.2.2.59.1.1266.tgz) (2020-07-29)
[Mobile_HLR-484](https://youtrack.protei.ru/issue/Mobile_HLR-484) Криво пишется hlr.cdr
- Basic **Bug**, Заказчик: **Top Connect**
- Добавлено удаление символа newline из ussd-строки

#### [2.2.59.0.1265](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/222/artifact/Make/Protei_HLR.2.2.59.0.1265.tgz) (2020-07-28)
##### Зависимость: API.2.0.23.0
[Mobile_HLR-535](https://youtrack.protei.ru/issue/Mobile_HLR-535) ISD на получение статуса доступности UE
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена отправка IDR с IDR-Flags=1 при получении ATM c SubscribeForUeReachability

[Mobile_HLR-595](https://youtrack.protei.ru/issue/Mobile_HLR-595) P-CSCF Restoration Procedure
- Basic **Freq**, Заказчик: **ТТ-Мобайл (Мегафон)**
- Добавлена отправка IDR/ISD при получении SAR с SAR-Flags=1

[Mobile_HLR-599](https://youtrack.protei.ru/issue/Mobile_HLR-599) В МО USSD оставлять в originationReference GT MSC
- Basic **Freq**, Заказчик: **Ariantel**
- Удалено изменение значения originationReference на GT_HLR

#### [2.2.58.0.1264](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/221/artifact/Make/Protei_HLR.2.2.58.0.1264.tgz) (2020-07-17)
##### Зависимость: API.2.0.22.0
[Mobile_HLR-551](https://youtrack.protei.ru/issue/Mobile_HLR-551)([1035527](https://newportal.protei.ru/portal/#issues/issue:id=1035527)) Поддержка сообщения MAP-ANY-TIME Modification в интерфейсе с HSS Italtel
- Basic **Freq**, Заказчик: **Italtel Rus**
- Добавлена отправка MME_Host, MME_Realm, MME_Number в ответ на SRIFSMДобавлено формирование запроса на подписку доступности пользователяОтправка AlertSC при получении команды от Italtel HSS

#### [2.2.57.1.1263](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/220/artifact/Make/Protei_HLR.2.2.57.1.1263.tgz) (2020-06-18)
[Mobile_HLR-583](https://youtrack.protei.ru/issue/Mobile_HLR-583) Отправляется AIA с 2001, когда не вычислили векторы аутентификации
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена проверка результата вычисления векторов

#### [2.2.57.0.1262](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/219/artifact/Make/Protei_HLR.2.2.57.0.1262.tgz) (2020-06-16)
##### Зависимость: API.2.0.20.0
[Mobile_HLR-560](https://youtrack.protei.ru/issue/Mobile_HLR-560) Расширить функциональность Reset
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Добавлена отправка Reset по groupId. Добавлен Reset-Id AVP в ULA/IDR

[Mobile_HLR-571](https://youtrack.protei.ru/issue/Mobile_HLR-571) HSS дает зарегистрироваться на IP-SM-GW при отсутствии телесервисов SMS
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена проверка телесервисов SMS

[Mobile_HLR-572](https://youtrack.protei.ru/issue/Mobile_HLR-572) SRI4SM отбивается при наличии регистрации на IP-SM-GW
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена проверка регистрации на IP_SM_GW

[Mobile_HLR-574](https://youtrack.protei.ru/issue/Mobile_HLR-574) Генерация AlertSC по ATM регистрации на IP-SM-GW
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлена отправка AlertSC при регистрации на IP_SM_GW

[Mobile_HLR-575](https://youtrack.protei.ru/issue/Mobile_HLR-575) Включать в ответ на ATM в рамках регистрации IP-SM-GW адрес SMSC из профиля
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлен SCA в ответ на ATM

[Mobile_HLR-578](https://youtrack.protei.ru/issue/Mobile_HLR-578)([1031677](https://newportal.protei.ru/portal/#issues/issue:id=1031677)) Добавить PLMN_ID в HSS cdr
- Basic **Freq**, Заказчик: **Ariantel**
- Добавлен вывод PLMN для транзакций UL и AI

#### [2.2.56.1.1261](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/218/artifact/Make/Protei_HLR.2.2.56.1.1261.tgz) (2020-06-10)
[Mobile_HLR-577](https://youtrack.protei.ru/issue/Mobile_HLR-577)([0](https://newportal.protei.ru/portal/#issues/issue:id=0)) Падение в коре
- Basic **Bug**, Заказчик: **Esmero**
- Добавлен анализ E-bit при получении IDA

#### 2.2.56.0.1260 (2020-05-27)
[Скачать версию 2.2.56.0.1260](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/217/artifact/Make/Protei_HLR.2.2.56.0.1260.tgz)

##### Зависимость: API.2.0.19.0
[Mobile_HLR-561](https://youtrack.protei.ru/issue/Mobile_HLR-561)([1028892](https://newportal.protei.ru/portal/#issues/issue:id=1028892)) Изменить вид вывода результата о загрузке абонентов через Load интерфейс
- Low **Freq**, Заказчик: **МТТ (Межрегионал Транзит Телеком)**
- Возвращен первоначальный формат вывода

[Mobile_HLR-563](https://youtrack.protei.ru/issue/Mobile_HLR-563)([1032771](https://newportal.protei.ru/portal/#issues/issue:id=1032771)) Неверный nErrorCode в SRI_SM
- Basic **Bug**, Заказчик: **Esmero**
- Исправлен вывод ErrorCode в CDR

[Mobile_HLR-565](https://youtrack.protei.ru/issue/Mobile_HLR-565) Падение при получении AIR с некорректным Re-Synchronization-Info AVP
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена проверка на наличие Number-Of-Requested-Vectors AVP

[Mobile_HLR-568](https://youtrack.protei.ru/issue/Mobile_HLR-568) AIR с использованием Immediate Response Preferred
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлен анализ Immediate-Response-Preferred AVP

#### 2.2.55.0.1259 (2020-05-14)
[Скачать версию 2.2.55.0.1259](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/216/artifact/Make/Protei_HLR.2.2.55.0.1259.tgz)
##### Зависимость: API.2.0.18.0
[Mobile_HLR-550](https://youtrack.protei.ru/issue/Mobile_HLR-550) Реализовать поддержку Si интерфейса между IM-SSF и HSS
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Добавлено заполнение O-IM-CSI, VT-IM-CSI, D-IM-CSI в ATSI RR

#### [2.2.54.0.1258](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/215/artifact/Make/Protei_HLR.2.2.54.0.1258.tgz) (2020-05-13)
##### Зависимость: API.2.0.17.0
[Mobile_HLR-543](https://youtrack.protei.ru/issue/Mobile_HLR-543) Убрать конфигурационный файл gsm.cfg из HLR
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Параметры из gsm.cfg [SMSC] перенесены в hlr.cfg [General]Переименования: Address->GT; AddressRI->RoutingIndicator; Handlers->HLR_Handlers; DIAM_Handlers->HSS_Handlers

[Mobile_HLR-544](https://youtrack.protei.ru/issue/Mobile_HLR-544) Поддержка GPRS-Subscription-Data AVP
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавлено заполнение GPRS-Subscription-Data в ULA/IDR

[Mobile_HLR-545](https://youtrack.protei.ru/issue/Mobile_HLR-545)([1032079](https://newportal.protei.ru/portal/#issues/issue:id=1032079)) Не отправили CL MAP на SGSN при регистрации на MME
- Important **Bug**, Заказчик: **Esmero**
- Добавлена проверка регистрации на SGSN в 3G при Initial Attach

[Mobile_HLR-546](https://youtrack.protei.ru/issue/Mobile_HLR-546)([1031267](https://newportal.protei.ru/portal/#issues/issue:id=1031267)) Не вычислили векторы аутентификации, но отправили успешный MAR
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавлена проверка валидности Ki

[Mobile_HLR-548](https://youtrack.protei.ru/issue/Mobile_HLR-548) UE-Usage-Type Decor
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Добавлено заполнение AVP ULA.SubscriptionData.UeUsageType и AIA.UeUsageType

[Mobile_HLR-549](https://youtrack.protei.ru/issue/Mobile_HLR-549) MPS Priority Service в EPS профиль
- Basic **Freq**, Заказчик: **ОАО "МЕГАФОН"**
- Добавлено заполнение AVP ULA.SubscriptionData.MpsPriority

[Mobile_HLR-552](https://youtrack.protei.ru/issue/Mobile_HLR-552) В ответ на MAR со схемой unknown возвращается Nokia SIP Digest вектор
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Исправлено условие отправки Nokia SIP Digest вектора

[Mobile_HLR-554](https://youtrack.protei.ru/issue/Mobile_HLR-554)([1032236](https://newportal.protei.ru/portal/#issues/issue:id=1032236)) encoding failed при отправке 3004
- Low **Bug**, Заказчик: **НТЦ Протей**
- Добавлено заполнение E-Bit в Protocol-Error-Answer

#### [2.2.53.0.1257](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/214/artifact/Make/Protei_HLR.2.2.53.0.1257.tgz) (2020-04-21)
##### Зависимость: API.2.0.16.0
[Mobile_HLR-531](https://youtrack.protei.ru/issue/Mobile_HLR-531) Некорректный SubscriberStatus и отсутствует ODB в ISD
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Убрал ненужный запрос на API, из-за которого происходило дублирование данных

[Mobile_HLR-532](https://youtrack.protei.ru/issue/Mobile_HLR-532) При изменении AccessRestrictionData не отправляется ISD
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Убрал ненужный запрос на API, из-за которого происходило дублирование данных

[Mobile_HLR-401](https://youtrack.protei.ru/issue/Mobile_HLR-401) Доработки по IMS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Подписка ASов на обновление профиля пользователейОтправка PNR при изменении профиля

[Mobile_HLR-275](https://youtrack.protei.ru/issue/Mobile_HLR-275) Перенести команду для инициализации Reset с Load на API
- Basic **Freq**, Заказчик: **НТЦ Протей**

[Mobile_HLR-536](https://youtrack.protei.ru/issue/Mobile_HLR-536) ISD на получение EPS User State and/or EPS Location Information
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавил формирование запроса при инициализации со стороны APIДобавил формирование запроса при наличии флагов locationInformationEPS_Supported и t_adsData в ATI

[Mobile_HLR-537](https://youtrack.protei.ru/issue/Mobile_HLR-537)([1031447](https://newportal.protei.ru/portal/#issues/issue:id=1031447)) IDR на получение текущего статуса поддержки "IMS Voice over PS Sessions" сетью доступа
- Basic **Freq**, Заказчик: **Esmero**
- Добавил отправку IDR из UD если от API в GetSdImsResp пришла информация об MME

[Mobile_HLR-419](https://youtrack.protei.ru/issue/Mobile_HLR-419) Добавить команду для отправки PSI
- Basic **Freq**, Заказчик: **Italtel**
- Добавил передачу TrStatus в ответ на API

#### [2.2.52.0.1256](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/213/artifact/Make/Protei_HLR.2.2.52.0.1256.tgz) (2020-04-07)
##### Зависимость: API.2.0.15.0
[Mobile_HLR-401](https://youtrack.protei.ru/issue/Mobile_HLR-401) Доработки по IMS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавил использование параметра UnregTermServiceIndicate

[Mobile_HLR-504](https://youtrack.protei.ru/issue/Mobile_HLR-504)([1029257](https://newportal.protei.ru/portal/#issues/issue:id=1029257)) Некорректно формируем PSI после ATI
- Important **Bug**, Заказчик: **ООО "Центр 2М"**
- Вернул совместимость со старым BS

#### [2.2.51.6.1255](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/212/artifact/Make/Protei_HLR.2.2.51.6.1255.tgz) (2020-04-06)
[Mobile_HLR-529](https://youtrack.protei.ru/issue/Mobile_HLR-529) Access Restriction Data не отправляется в Update GPRS Location
- Basic **Bug**, Заказчик: **Телематика**
- Добавил отправку Access Restriction Data в ISD на SGSN

#### [2.2.51.5.1254](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/211/artifact/Make/Protei_HLR.2.2.51.5.1254.tgz) (2020-04-03)
##### Зависимость: API.2.0.14.3
[Mobile_HLR-452](https://youtrack.protei.ru/issue/Mobile_HLR-452) Поддержка MAP ATSI
- Basic **Freq**, Заказчик: **Italtel**
- Исправление выявленных ошибок, окончательное включение функциональности

[Mobile_HLR-523](https://youtrack.protei.ru/issue/Mobile_HLR-523) Поддержка Wildcarded PSI
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Использовать IMPU, который вернул API, если этот IMPU был получен по Wildcard

[Mobile_HLR-524](https://youtrack.protei.ru/issue/Mobile_HLR-524)([1029571](https://newportal.protei.ru/portal/#issues/issue:id=1029571)) Создавать error файл при загрузке через Load интерфейс некорректного файла абонентского профиля
- Basic **Freq**, Заказчик: **SIM Telecom**

#### [2.2.51.4.1253](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/210/artifact/Make/Protei_HLR.2.2.51.4.1253.tgz) (2020-03-25)
[Mobile_HLR-372](https://youtrack.protei.ru/issue/Mobile_HLR-372)([1011937](https://newportal.protei.ru/portal/#issues/issue:id=1011937)) Поддержка isVolte и imrn
- Basic **Freq**, Заказчик: **Italtel**
- При получении ответа от API, сделал проверку IMRN как самую приоритетную

#### [2.2.51.3.1252](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/208/artifact/Make/Protei_HLR.2.2.51.3.1252.tgz) (2020-03-16)
##### Зависимость: API.2.0.13.1
[Mobile_HLR-508](https://youtrack.protei.ru/issue/Mobile_HLR-508) 5ти кратное повторение RepositoryData в Sh профиле
- Basic **Bug**, Заказчик: **Esmero**
- Не очищался список запрашиваемых параметров (UD.m_DataRequestList)

[Mobile_HLR-511](https://youtrack.protei.ru/issue/Mobile_HLR-511) Запросы TADS Information по IMSI и MSISDN отбиваются с 5001
- Basic **Bug**, Заказчик: **Esmero**
- Запрос ShUserData по IMSI/MSISDN

#### [2.2.51.2.1251](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/207/artifact/Make/Protei_HLR.2.2.51.2.1251.tgz) (2020-03-06)
##### Зависимость: API.2.0.12.6
[Mobile_HLR-504](https://youtrack.protei.ru/issue/Mobile_HLR-504)([1029274](https://newportal.protei.ru/portal/#issues/issue:id=1029274)) Некорректно формируем PSI после ATI
- Important **Bug**, Заказчик: **ООО "Центр 2М"**
- Отправляли PSI при отсутствии регистрации на VLR

[Mobile_HLR-503](https://youtrack.protei.ru/issue/Mobile_HLR-503) Некорректные ответы в Notification procedure
- Basic **Bug**, Заказчик: **НТЦ Протей**
- При отсутсвии AVP, значения которых нужно сохранить в профиле, все равно делаем запрос на API, что бы проверить наличие такого абонента и его регистрацию на MME/SGSN

[Mobile_HLR-498](https://youtrack.protei.ru/issue/Mobile_HLR-498) Поддержка Coupled-Node-Diameter-ID
- Low **Freq**, Заказчик: **НТЦ Протей**
- Добавил передачу Host-Identity из Coupled-Node-Diameter-ID на API

[Mobile_HLR-506](https://youtrack.protei.ru/issue/Mobile_HLR-506) Некорректное выставление флагов при частичном Purge
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Добавил передачу PartialPurge из PUR-Flags на API

#### [2.2.51.1.1250](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/206/artifact/Make/Protei_HLR.2.2.51.1.1250.tgz) (2020-03-05)
[Mobile_HLR-493](https://youtrack.protei.ru/issue/Mobile_HLR-493) Некорректное значение CancellationType
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Отправка Cancel-Location-Type=INITIAL_ATTACH_PROCEDURE в приоририте, если в ULR-Falgs выставлен соответсвующий флаг

[Mobile_HLR-502](https://youtrack.protei.ru/issue/Mobile_HLR-502) Некорректный ответ PUA для несуществующего абонента
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Изменил на UNKNOWN_SUBSCRIBER

[Mobile_HLR-504](https://youtrack.protei.ru/issue/Mobile_HLR-504)([1029274](https://newportal.protei.ru/portal/#issues/issue:id=1029274)) Некорректно формируем PSI после ATI
- Important **Bug**, Заказчик: **ООО "Центр 2М"**
- Неправильно парсился ответ от API

#### [2.2.51.1.1249](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/205/artifact/Make/Protei_HLR.2.2.51.1.1249.tgz) (2020-03-04)
[Mobile_HLR-493](https://youtrack.protei.ru/issue/Mobile_HLR-493) Некорректное значение CancellationType
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Отправка Cancel-Location-Type=INITIAL_ATTACH_PROCEDURE в приоририте, если в ULR-Falgs выставлен соответсвующий флаг

[Mobile_HLR-502](https://youtrack.protei.ru/issue/Mobile_HLR-502) Некорректный ответ PUA для несуществующего абонента
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Изменил на UNKNOWN_SUBSCRIBER

[Mobile_HLR-504](https://youtrack.protei.ru/issue/Mobile_HLR-504)([1029274](https://newportal.protei.ru/portal/#issues/issue:id=1029274)) Некорректно формируем PSI после ATI
- Important **Bug**, Заказчик: **ООО "Центр 2М"**
- Неправильно парсился ответ от API

#### [2.2.51.0.1248](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/204/artifact/Make/Protei_HLR.2.2.51.0.1248.tgz) (2020-03-03)
##### Зависимость: API.2.0.12.5
[Mobile_HLR-489](https://youtrack.protei.ru/issue/Mobile_HLR-489) 3GPP-SIP-Authentication-Scheme: Digest (Nokia_SIP_Digest)
- Basic **Freq**, Заказчик: **Esmero**
- Добавил специфическое формирование SIP-Auth-Data-Item AVP, если в MAR пришел 3GPP-SIP-Authentication-Scheme AVP = Digest

[Mobile_HLR-490](https://youtrack.protei.ru/issue/Mobile_HLR-490) RoamingNotAllowed для HSS
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Добавил проверку соответсвия AVP Visited-PLMN-Id со значениями из hlr.cfg [HPLMN]

[Mobile_HLR-493](https://youtrack.protei.ru/issue/Mobile_HLR-493) Некорректное значение CancellationType
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Не отправлялось SGSN_UPDATE_PROCEDURE

[Mobile_HLR-494](https://youtrack.protei.ru/issue/Mobile_HLR-494) Возвращать ошибку DIAMETER_ERROR_ROAMING_NOT_ALLOWED при выставленном ODB
- Basic **Freq**, Заказчик: **НТЦ Протей**
- Сделал отправку ошибки DIAMETER_ERROR_ROAMING_NOT_ALLOWED, если у абонента выставлен ODB (15,16,17), а MME не поддерживает данный функционал

[Mobile_HLR-495](https://youtrack.protei.ru/issue/Mobile_HLR-495)([1029274](https://newportal.protei.ru/portal/#issues/issue:id=1029274)) Отбиваем ATI с teleserviceNotProvisioned
- Basic **Bug**, Заказчик: **ООО "Центр 2М"**
- Изменил запрос регистрации с API c GET_RI на GET_LOC_INFO

[Mobile_HLR-491](https://youtrack.protei.ru/issue/Mobile_HLR-491) Пустой Session-ID в ULA
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Получали запрос без обязательного AVP, из-за чего не происходила распаковка диаметрового запроса, добавил в DiameterInterface (4.1.6.5) формироваия ответного сообщения с кодом 5005 (MISSING_AVP)

#### [2.2.50.0.1247](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/203/artifact/Make/Protei_HLR.2.2.50.0.1247.tgz) (2020-02-21)
[Mobile_HLR-471](https://youtrack.protei.ru/issue/Mobile_HLR-471) Отбой USSD-запросов со стороны HLR
- Basic **Freq**, Заказчик: **Top Connect**
- Заменил TCAP_ABORT на TCAP_RETURN_ERROR с кодами MAP_SystemFailure и MAP_UnexpectedDataValue

[Mobile_HLR-443](https://youtrack.protei.ru/issue/Mobile_HLR-443)([1026684](https://newportal.protei.ru/portal/#issues/issue:id=1026684)) Изменить MAP код ошибки, возвращаемый при внутренних проблемах на платформе
- Basic **Bug**, Заказчик: **ООО "Центр 2М"**
- + MO_USSD

[Mobile_HLR-481](https://youtrack.protei.ru/issue/Mobile_HLR-481) Некорректный ResultCode в UAA
- Basic **Bug**, Заказчик: **НТЦ Протей**
- Поменял код ответа с AUTHENTICATION_REJECTED на AUTHORIZATION_REJECTED

[Mobile_HLR-470](https://youtrack.protei.ru/issue/Mobile_HLR-470) Раздельный подсчет суточной и оперативной статистики по абонентам
- Basic **Freq**, Заказчик: **Top Connect**

[Mobile_HLR-486](https://youtrack.protei.ru/issue/Mobile_HLR-486) Доп поля в cdr файлы по IMS транзакциям
- Basic **Freq**, Заказчик: **Esmero**

[Mobile_HLR-463](https://youtrack.protei.ru/issue/Mobile_HLR-463) Формирование repository data на основании профиля абонента
- Basic **Freq**, Заказчик: **Esmero**
- HSS передавал на API только имя первого сервиса из UDR

[Mobile_HLR-407](https://youtrack.protei.ru/issue/Mobile_HLR-407)([1024330](https://newportal.protei.ru/portal/#issues/issue:id=1024330)) Декодирование неверно закодированных USSD
- Basic **Freq**, Заказчик: **Top Connect**
- Поменял ValidUssdPreffix на NotValidUssdPreffix. Теперь в этом параметре нужно указывать префикс невалидного USSD

#### [2.2.49.0.1246](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/200/artifact/Make/Protei_HLR.2.2.49.0.1246.tgz) (2020-02-12)
##### Зависимость: API.2.0.12.0

- [Mobile_HLR-452](https://youtrack.protei.ru/issue/Mobile_HLR-452) Поддержка MAP ATSI

    - Basic **Freq**, Заказчик: **Italtel** 
    - На данный момент на стадии тестирования, на релизовой сборке до сих пор не поддерживается
- [Mobile_HLR-475](https://youtrack.protei.ru/issue/Mobile_HLR-475) В PSI статистике не учитываются сообщения, порожденные транзакцией ATI

    - Basic **Bug**, Заказчик: **Top Connect** 
    - Не хватало инкремента статистики при получении успешного ответа на PSI в ATI
- [Mobile_HLR-473](https://youtrack.protei.ru/issue/Mobile_HLR-473) Изменить критерии успешности для транзакций SendRoutingInfo, PRN, PSI, SendRoutingInfo4SM

    - Basic **Freq**, Заказчик: **Top Connect** 
    - 
#### [2.2.48.8.1245](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/196/artifact/Make/Protei_HLR.2.2.48.8.1245.tgz) (11.02.2020)
##### Зависимость: API.2.0.11.0
- [Mobile_HLR-443](https://youtrack.protei.ru/issue/Mobile_HLR-443) -  Изменить MAP код ошибки, возвращаемый при внутренних проблемах на платформе: SAI
- Basic **Bug**, заказчик: ООО \, связанные обращения: 1026684
- Так же внес аналогичный фикс в логики Diameter: UL, AI
- При отсутсвии в запросе AIR количества запрашиваемых векторов, используется дефолтное значение (4 E_UTRAN вектора)
- [Mobile_HLR-466](https://youtrack.protei.ru/issue/Mobile_HLR-466) -  HSS дает зарегистрировать один IMS Subscription на нескольких S-CSCF
- Basic **Bug**, заказчик: НТЦ Протей
- Рефакторинг IMS

#### [2.2.48.7.1244](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/195/artifact/Make/Protei_HLR.2.2.48.7.1244.tgz) (28.01.2020)
- [Mobile_HLR-465](https://youtrack/issue/Mobile_HLR-465) - Core на HLR
- Basic Bug, заказчик: Top Connect
- Формировали некорректный запрос на BS
#### [2.2.48.6.1243](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/194/artifact/Make/Protei_HLR.2.2.48.6.1243.tgz) (28.01.2020)
- [Mobile_HLR-465](https://youtrack/issue/Mobile_HLR-465) - Core на HLR
- Basic Bug, заказчик: Top Connect
- Падали при получении ULR без Supported_Features AVP
#### [2.2.48.5.1242](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/188/artifact/Make/Protei_HLR.2.2.48.5.1242.tgz) (22.01.2020)
- [Mobile_HLR-462](https://youtrack/issue/Mobile_HLR-462) - Получение Allocated Primitives по SNMP
- Не находим параметр, если его имя больше 8 символов. Заменил на AL_PRIM.
- Пример конфигурации: {HLR(146).COMMON,IND(9,1);AL_PRIM(7);};
#### [2.2.48.4.1241](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/187/artifact/Make/Protei_HLR.2.2.48.4.1241.tgz) (21.01.2020)
- [Mobile_HLR-280](https://youtrack/issue/Mobile_HLR-280) - Завис счётчик CurrentRegCount в абонентской статистике
- В состоянии ожидания ответа от API, сработал таймер запроса статистики, который был проигнорирован и заново не запущен (AbonentStatistics.Get)
- [Mobile_HLR-461](https://youtrack/issue/Mobile_HLR-461) - Переделка получения количество логик по SNMP
- Изменен тип получаемого значения STRING->INTEGER
- [Mobile_HLR-462](https://youtrack/issue/Mobile_HLR-462) - Получение Allocated Primitives по SNMP
- PROTEI-HLR-MIB::hlr-CommonSL-ALLOCATED_PRIMITIVES.1 = INTEGER: 0
- Не отправлять PSI, если абонент удален из VLR (SRI_SL)
#### [2.2.48.3.1240](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/186/artifact/Make/Protei_HLR.2.2.48.3.1240.tgz) (20.01.2020)
- [Mobile_HLR-454](https://youtrack/issue/Mobile_HLR-454) - Отвечаем LIR с 5003, если абонент зарегестрирован в 2G
- Рефакторинг LI_SL, Remove setProxiable calls, Others warnings fix, SAR UNREGISTERED (добавить в UserData все паблики)
- Отправлять PRN, если в UDR требуется вернуть CSRN
- Зависимости: API.2.0.10.3 
#### [2.2.48.2.1239](https://jenkins.protei.ru/job/team4/job/CentOs6/job/HSS/job/HSS_release/182/artifact/Make/Protei_HLR.2.2.48.2.1239.tgz) (17.01.2020)
- [Mobile_HLR-458](https://youtrack/issue/Mobile_HLR-458) - Ошибки при формировании диаметровых CDR на HSS (cdr_common_diam_YYMMDD.log)
- При освобождении логики не очищалась переменная m_MSISDN
#### 2.2.48.1
- [Mobile_HLR-454](https://youtrack/issue/Mobile_HLR-454) - Отвечаем LIR с 5003, если абонент зарегестрирован в 2G
- При отсутсвии регистрации в IMS, задан ли абоненту адрес SCC_AS, если да, то добавляем его в LIA.Server_Name AVP
- Добавил провреку SAR.User_Data_Already_Available AVP
#### 2.2.48.0
- [Mobile_HLR-445](https://youtrack/issue/Mobile_HLR-445) - Расширить запрос PSI
- Добавил в PSI запрос locationInformation
#### 2.2.47.1
- [Mobile_HLR-450](https://youtrack/issue/Mobile_HLR-450) - Неправильно выставляем Result-Code при отсутсвии User_Autherization_Type
- Result_Code=2001 -> Experimental_Result.Experimental_Result_Code=2002
#### 2.2.47.0
- [Mobile_HLR-447](https://youtrack/issue/Mobile_HLR-447) - Добавить значение переодичности вывода TCAP статистики в конфиг
#### 2.2.46.0
- [Mobile_HLR-447](https://youtrack/issue/Mobile_HLR-441) - Добавить Pre-emption-Capability и Pre-emption-Vulnerability в EPS профиль
#### 2.2.45.2
- [Mobile_HLR-446](https://youtrack/issue/Mobile_HLR-446) - Потеря полей в UL cdr
#### 2.2.45.1
- Добавил Supported-Features и Expire-Time в SNA
#### 2.2.45.0
- [Mobile_HLR-435](https://youtrack/issue/Mobile_HLR-435) - Заливка карт с OPC
#### 2.2.44.18
- [Mobile_HLR-434](https://youtrack/issue/Mobile_HLR-434) - Утечка логик из-за неправильного закрытия логики DIAM_CL + fix аналогичных проблем в других логиках
#### 2.2.44.17
- [Mobile_HLR-433](https://youtrack/issue/Mobile_HLR-433) - Ошибка в формате передачи RestorationInfo с API на HSS
#### 2.2.44.16
- Не отправлять ShUserData в SNA если Send_Data_Indication != 1
#### 2.2.44.15
- [Mobile_HLR-429](https://youtrack/issue/Mobile_HLR-429) - Не удаляется Restoration Info после получения SAR с типом USER_DEREGISTRATION_STORE_SERVER_NAME
#### 2.2.44.14
- [Mobile_HLR-430](https://youtrack/issue/Mobile_HLR-430) - Падали при получении пустого Visited-PLMN в AIR
#### 2.2.44.13
- [Mobile_HLR-428](https://youtrack/issue/Mobile_HLR-428) - Неверный формат передачи опциональных парамтров RestorationInfo
#### 2.2.44.12
- [Mobile_HLR-422](https://youtrack/issue/Mobile_HLR-422) - UDR поддержка Data-Reference: TADSinformation
#### 2.2.44.11
- [Mobile_HLR-424](https://youtrack/issue/Mobile_HLR-424) - Неправильный CancellationType
- [Mobile_HLR-426](https://youtrack/issue/Mobile_HLR-426) - Флаг Reattach Required в CL
#### 2.2.44.10
- [Mobile_HLR-421](https://youtrack/issue/Mobile_HLR-421) - Поддержка UDR ServiceData
#### 2.2.44.9
- [Mobile_HLR-423](https://youtrack/issue/Mobile_HLR-423) - Поддержка SharedIFCSetID
#### 2.2.44.8
- [Mobile_HLR-420](https://youtrack/issue/Mobile_HLR-420) - Утечка TCAP (1. ussd not in wl, 2. ul-isd bad body isd)
#### 2.2.44.7
- [Mobile_HLR-419](https://youtrack/issue/Mobile_HLR-419) - SendPSI by API
#### 2.2.44.6
- [Mobile_HLR-418](https://youtrack/issue/Mobile_HLR-418) - LoadInterface EPS
#### 2.2.44.5
- [Mobile_HLR-392](https://youtrack/issue/Mobile_HLR-392) - Поддержка запроса sendParameters
#### 2.2.44.4
- [Mobile_HLR-415](https://youtrack/issue/Mobile_HLR-415) - Не очищаются параметры mmeRealm и mmeHost при CL
#### 2.2.44.3
- [Mobile_HLR-412](https://youtrack/issue/Mobile_HLR-412) - Не отдали RestorationInfo, при получении SAR после MAR
#### 2.2.44.2
- [Mobile_HLR-350](https://youtrack/issue/Mobile_HLR-350) - Доработка hlr cdr
#### 2.2.44.1
- [Mobile_HLR-407](https://youtrack/issue/Mobile_HLR-407) - Декодирование неверно закодированных USSD
#### 2.2.44.0
- [Mobile_HLR-404](https://youtrack/issue/Mobile_HLR-404) - SLH интерфейс
#### 2.2.43.5
- Добавлять всегда IMPI в SAA, кроме случаев, когда IMPU не найден
#### 2.2.43.4
- [Mobile_HLR-373](https://youtrack/issue/Mobile_HLR-373) - Команда на получение MSRN (receive gmscAddress and callReferenceNumber from API)
#### 2.2.43.3
- Use reassignmentPendingFlag for IMS
#### 2.2.43.2
- [Mobile_HLR-397](https://youtrack/issue/Mobile_HLR-397) - Поддержка загрузки групп (load) ct toString
#### 2.2.43.1
- [Mobile_HLR-394](https://youtrack/issue/Mobile_HLR-394) - Пустые вектора в рамках ресинхронизации (ожидали строку рессинхронизации длиной 32 байта, хотя она должна быть 30 байт)
#### 2.2.43.0
- [Mobile_HLR-117](https://youtrack/issue/Mobile_HLR-117) - Обработка USSD phase 1(382)
#### 2.2.42.0
- [Mobile_HLR-388](https://youtrack/issue/Mobile_HLR-388) - Общая лицензия по TPS
- [Mobile_HLR-389](https://youtrack/issue/Mobile_HLR-389) - Поднять пороговое значение лицензионного ограничения до 4000 TPS
#### 2.2.41.0
- [Mobile_HLR-383](https://youtrack/issue/Mobile_HLR-383) - Расширение Access-Restriction-Data для 5G (без MAP части)
- [Mobile_HLR-384](https://youtrack/issue/Mobile_HLR-384) - Поддержка Feature-LIst-Id=2
- [Mobile_HLR-385](https://youtrack/issue/Mobile_HLR-385) - Поддержка расширенного AMBR для 5g сети
#### 2.2.40.0
- [Mobile_HLR-373](https://youtrack/issue/Mobile_HLR-373) - Команда на получение MSRN
#### 2.2.39.0
- [Mobile_HLR-378](https://youtrack/issue/Mobile_HLR-378) - Лицензия IMS
- [Mobile_HLR-377](https://youtrack/issue/Mobile_HLR-377) - Включить лицензионное ограничение TPS
#### 2.2.38.9
- [Mobile_HLR-375](https://youtrack/issue/Mobile_HLR-375) - loadSubscriber
#### 2.2.38.8
- [Mobile_HLR-371](https://youtrack/issue/Mobile_HLR-371) - undef opCode CDR
#### 2.2.38.7
- Не добавлялся TemporaryPublicId в xmlUserData
#### 2.2.38.6
- Поддержка isVoLTE и IMRN
#### 2.2.38.5
- Убрал указание Destination-Host при маршрутизации CLR/IDR/DDR на PCSM
#### 2.2.38.4
- Не сохраняли ScscfServerName после SAR
#### 2.2.38.3
- [Mobile_HLR-359](https://youtrack/issue/Mobile_HLR-359) - Неправильно кодируются ss-SubscriptionOption и cliRestrictionOption для CLIR
#### 2.2.38.2
- [Mobile_HLR-357](https://youtrack/issue/Mobile_HLR-357) - Отправлять DSD при изменении ssStatus = 0
#### 2.2.38.1
- [Mobile_HLR-352](https://youtrack/issue/Mobile_HLR-352) - Пустой AVP: Visited-Network-Identifier
#### 2.2.38.0
- [Mobile_HLR-347](https://youtrack/issue/Mobile_HLR-347) - Вынести MAP Error Code и Diameter Result Code в параметры черного и белого списка
#### 2.2.37.1
- IMS: Убрал изменение статуса юзера при SAR Type NO_ASSIGNMENT + fix Restoration Info
#### 2.2.37.0
- Необходимо все переменные (ALL, DIAM_ALL, UL и пр.) выводить каждый под своим OID
#### 2.2.36.12
- Добавил экранирование ковычек при передачи данных на API
#### 2.2.36.11
- [Mobile_HLR-318](https://youtrack/issue/Mobile_HLR-318) - Не выставляется флаг Proxyable в Cancel-Location Request 
#### 2.2.36.10
- [Mobile_HLR-310](https://youtrack/issue/Mobile_HLR-310) - Некоторые HSM не попадают в trace. Лишние вектора для HSM у SAI
#### 2.2.36.9
- [Mobile_HLR-307](https://youtrack/issue/Mobile_HLR-307) - Падает в коре при отсутсвии кофига udp.cfg, вынес использование UDP_Notifier пд флаг. + добавила эту проверку во всех логиках
#### 2.2.36.8
- [Mobile_HLR-307](https://youtrack/issue/Mobile_HLR-307) - Падает в коре при отсутсвии кофига udp.cfg, вынес использование UDP_Notifier пд флаг.
#### 2.2.36.7
- [Mobile_HLR-307](https://youtrack/issue/Mobile_HLR-307) - Падение в коре из-за попытки закодировать список с пустой строкой (Reset)
#### 2.2.36.6
- Не инкрементировался порядковый номер векторов аутентификаци при работе с HSM
#### 2.2.36.5
- HLR падает в core при некорректной лицензии + оповещение SystemManager о релоаде лицензии
#### 2.2.36.4
- Поправил кодирование AMF при запросе на HSM
#### 2.2.36.3
- Добавить в запрос на изменение регистрации на SCSCF индикатор для сохранения имени сервера после дерегисрации
#### 2.2.36.2
- [Mobile_HLR-300](https://youtrack/issue/Mobile_HLR-300) - Некорректное формирование запроса на HSM при регистрации в LTE (Ошибка в парсинге ответа от API)
#### 2.2.36.1
- [Mobile_HLR-299](https://youtrack/issue/Mobile_HLR-299) - Добавить поддержку Array Mechanism ( использование индексов) при формировании SQN в рамках интеграции с HSM
#### 2.2.36.0
- [Mobile_HLR-296](https://youtrack/issue/Mobile_HLR-296) - Сделать доступным поддержки в одном HLR работы с картами разных HSMах и карт в нашем AUC 
#### 2.2.35.0
- [Mobile_HLR-267](https://youtrack/issue/Mobile_HLR-267) - Добавить UDP-интерфейс в HLR
#### 2.2.34.2
- [Mobile_HLR-295](https://youtrack/issue/Mobile_HLR-295) - Добавил проверку валидности параметров при load-загрузке
#### 2.2.34.1
- [Mobile_HLR-263](https://youtrack/issue/Mobile_HLR-263) - Формируем ISD SS основываясь на информации, полученной от API
#### 2.2.34.0
- [Mobile_HLR-192](https://youtrack/issue/Mobile_HLR-192) - Отправка Cx Registration-Termination-Request по команде администратора/При изменении ImplicitlyRegisteredSet
#### 2.2.33.0
- [Mobile_HLR-291](https://youtrack/issue/Mobile_HLR-291) - Обновление интерфейса HSM-HSS/HLR/AuC
#### 2.2.32.2
- [Mobile_HLR-288](https://youtrack/issue/Mobile_HLR-288) - Использовать Hostname из TM_HLR_GT для формирования Diameter Session-Id 
#### 2.2.32.1
- [Mobile_HLR-283](https://youtrack/issue/Mobile_HLR-283) - Не считается MaxSpeed в traffic_stat
#### 2.2.32.0
- [Mobile_HLR-256](https://youtrack/issue/Mobile_HLR-256) - Реализовать авторизацию МТ вызова с CUG на HLR
#### 2.2.31.1
- [Mobile_HLR-261](https://youtrack/issue/Mobile_HLR-261) - Сформировали UDT Malformed Packet ответ на SRI_FSM 
#### 2.2.31.0
- [Mobile_HLR-253](https://youtrack/issue/Mobile_HLR-253) - Отправка PushProfileRequest по команде с API
#### 2.2.30.0
- [Mobile_HLR-153](https://youtrack/issue/Mobile_HLR-153) - Добавить в профиль таймер периодического LU (load-интерфейс)
#### 2.2.29.0
- [Mobile_HLR-245](https://youtrack/issue/Mobile_HLR-245) - Временная лицензия
#### 2.2.28.4
- [Mobile_HLR-248](https://youtrack/issue/Mobile_HLR-248) - Включение CompleteDataListIncluded только в первый ISD 
#### 2.2.28.3
- [Mobile_HLR-247](https://youtrack/issue/Mobile_HLR-247) - Не передаётся MSISDN на API из destReference registerSS 
#### 2.2.28.2
- [Mobile_HLR-242](https://youtrack/issue/Mobile_HLR-242) - Неуспешная 3G аутентификация SIM карт G+D (Была неверная реализация функции rot(x, r, out))
#### 2.2.28.1
- [Mobile_HLR-241](https://youtrack/issue/Mobile_HLR-241) - Доработка CDR SAI 
#### 2.2.28.0
- [Mobile_HLR-153](https://youtrack/issue/Mobile_HLR-153) - Добавить в профиль таймер периодического LU
#### 2.2.27.10
- [Mobile_HLR-233](https://youtrack/issue/Mobile_HLR-233) - Некорректо формируется PRN с lMSI в сторону VLR
#### 2.2.27.9
- [Mobile_HLR-232](https://youtrack/issue/Mobile_HLR-232) - При помещении в директорию для загрузки абонентских профилей файла некорректного формата HLR подвисает 
#### 2.2.27.8
- [Mobile_HLR-229](https://youtrack/issue/Mobile_HLR-229) - В get_profile отсутствует регистрация на MME 
#### 2.2.27.7
- [Mobile_HLR-221](https://youtrack/issue/Mobile_HLR-221) - Неверное кодирование CC
- [Mobile_HLR-222](https://youtrack/issue/Mobile_HLR-222) - Падение в коре при неверном ТК
#### 2.2.27.6
- Падения в коре при получении UL до того, как поднимется DIAM Config
#### 2.2.27.5
- [Mobile_HLR-218](https://youtrack/issue/Mobile_HLR-218) - В рамках Diam_UL был отправлен CL, по которому сработал timeout и очистилось местоположение.
#### 2.2.27.4
- [Mobile_HLR-214](https://youtrack/issue/Mobile_HLR-214) - Не понизили версию CL до 1
#### 2.2.27.3
- [Mobile_HLR-215](https://youtrack/issue/Mobile_HLR-215) - Наличие F в callReferenceNumber приводит к появлению записи в warning.log
#### 2.2.27.2
- [Mobile_HLR-211](https://youtrack/issue/Mobile_HLR-211) - Не заполняется Origin-Realm в CLR (After UL 3g SGSN)
- [Mobile_HLR-212](https://youtrack/issue/Mobile_HLR-212) - PUER
#### 2.2.27.1
- [Mobile_HLR-205](https://youtrack/issue/Mobile_HLR-205) - Не заполняем Origin_Host/Origin_Realm в Notify_Answer 
#### 2.2.27.0
- [Mobile_HLR-204](https://youtrack/issue/Mobile_HLR-204) - Собственная адресация для каждой группы в рамках HSS
#### 2.2.26.8
- [Mobile_HLR-202](https://youtrack/issue/Mobile_HLR-202) - Не возвращается Cx профиль абонента на S-CSCF при assignment-type = unregistered user
#### 2.2.26.7
- [Mobile_HLR-189](https://youtrack/issue/Mobile_HLR-189) - Декодирование SGSN-адрес из update GPRS Location
#### 2.2.26.6
- [Mobile_HLR-198](https://youtrack/issue/Mobile_HLR-198) - Автоматическое добавление Temporary Public User Identity с BarringIndication=1 при регистрации по Temporary Public User Identity (XML)
#### 2.2.26.5 IMS+XOR
- [Mobile_HLR-195](https://youtrack/issue/Mobile_HLR-195) - Связывание Public idenity с несколькими Private identity
#### 2.2.26.4
- Отправка rtr, если пришел mar от другого scscf
#### 2.2.26.3
- [Mobile_HLR-194](https://youtrack/issue/Mobile_HLR-194) - Вынести параметр аутентификации AMF в таблицу TM_AUC для доменов UMTS и LTE и IMS
#### 2.2.26.2
- [Mobile_HLR-190](https://youtrack/issue/Mobile_HLR-190) - Добавить заполнение Subscription-Data -> 3GPP-Charging-Characteristics AVP
#### 2.2.26.1
- [Mobile_HLR-169](https://youtrack/issue/Mobile_HLR-169) - Интерфейс H (HSM). Вынести в конфигурацию заполнение AMF
#### 2.2.26.0
- [Mobile_HLR-166](https://youtrack/issue/Mobile_HLR-166) - Аутентификация по s6a c внешнего AUC
#### 2.2.25.6
- [Mobile_HLR-162](https://youtrack/issue/Mobile_HLR-162) - fix H-Interface
- [Mobile_HLR-164](https://youtrack/issue/Mobile_HLR-164)
- [Mobile_HLR-165](https://youtrack/issue/Mobile_HLR-165)
- [Mobile_HLR-167](https://youtrack/issue/Mobile_HLR-167)
#### 2.2.25.5
- [Mobile_HLR-160](https://youtrack/issue/Mobile_HLR-160) - Неверное кодирование KASME (PLMN был в формате string, исправил на формат byte_buffer)
#### 2.2.25.4
- [Mobile_HLR-159](https://youtrack/issue/Mobile_HLR-159) - Реализовать функционал Partial Purge на HSS
#### 2.2.25.3
- [Mobile_HLR-158](https://youtrack/issue/Mobile_HLR-158) - Интерфейс H (HSM). Неверно закодировали AUTHENTICATION_RESYNCHRONIZATION_REQ
#### 2.2.25.2
- [Mobile_HLR-148](https://youtrack/issue/Mobile_HLR-148) - Отправка ISD на VLR только с IMSI
#### 2.2.25.1
- [Mobile_HLR-145](https://youtrack/issue/Mobile_HLR-145) - Пустая абонентская статистика за период после рестарта
#### 2.2.25.0
- [Mobile_HLR-142](https://youtrack/issue/Mobile_HLR-142) - SWX(MA)
#### 2.2.24.5
- [Mobile_HLR-146](https://youtrack/issue/Mobile_HLR-146) - minifix
#### 2.2.24.4
- minifix LIR.mmtelIndicate
#### 2.2.24.3
- minifix LIR.m_Originating_Request
#### 2.2.24.2
- [Mobile_HLR-140](https://youtrack/issue/Mobile_HLR-140) - Нет возможно загрузить EPS контекст без QCI
#### 2.2.24.1
- [Mobile_HLR-113](https://youtrack/issue/Mobile_HLR-113) - Проверять tid у abort/error в логики CL
#### 2.2.24.0
- [Mobile_HLR-131](https://youtrack/issue/Mobile_HLR-131) - Load Загрузка групп
#### 2.2.23.0
- [Mobile_HLR-130](https://youtrack/issue/Mobile_HLR-130) - Логику DeactivatePSI расширить проверкой VLR 
#### 2.2.22.0
- [Mobile_HLR-129](https://youtrack/issue/Mobile_HLR-129) - Таймаут PSI
#### 2.2.21.1
- [Mobile_HLR-105](https://youtrack/issue/Mobile_HLR-105) - Упарвление AccessRestrictionData (замениить битовую маску на структуру)
#### 2.2.21.0
- [Mobile_HLR-105](https://youtrack/issue/Mobile_HLR-105) - Упарвление AccessRestrictionData
#### 2.2.20.3
- [Mobile_HLR-110](https://youtrack/issue/Mobile_HLR-110) - Добавить GT сетевого элемента, ответа от которого мы не дождались
#### 2.2.20.2
- [Mobile_HLR-123](https://youtrack/issue/Mobile_HLR-123) - Загрузка профиля EPS->AllocRetPrior 
#### 2.2.20.1
- [Mobile_HLR-116](https://youtrack/issue/Mobile_HLR-116) - Утечка TCAP обработчиков на HLR во время отказа БС
#### 2.2.20.0
- [Mobile_HLR-122](https://youtrack/issue/Mobile_HLR-122) - Привязывать BS/TS к связке ss_code+ss_status
#### 2.2.19.2
- [Mobile_HLR-108](https://youtrack/issue/Mobile_HLR-108) - Падаем в коре при отсутствии smpp.cfg
#### 2.2.19.1
- [Mobile_HLR-110](https://youtrack/issue/Mobile_HLR-110) - Убрать из warning лог HLR записи по событиям, которые нельзя классифицировать как warningи 
#### 2.2.19.0
- [Mobile_HLR-107](https://youtrack/issue/Mobile_HLR-107) - Поддержка интерфейса авторизации в AUC
#### 2.2.18.1
- [Mobile_HLR-109](https://youtrack/issue/Mobile_HLR-109) - При загрузке PDP контекста с не заданным lVPLMN_AddressAllowed в БД грузится случайное число 
#### 2.2.18.0
- [Mobile_HLR-98](https://youtrack/issue/Mobile_HLR-98) - Проксировать SRIFSM на GT IPSMGW
#### 2.2.17.0
- [Mobile_HLR-103](https://youtrack/issue/Mobile_HLR-103) - Передача ASN-структуры USSD-запроса при передаче USSD от HLR на GMSC для целей СОРМ 
#### 2.2.16.2
- minifix Пустые опциональные параметры EPS выставлять в -1, выводить в err ошибку добавления pdp, а не тело команды
#### 2.2.16.1
- [Mobile_HLR-96](https://youtrack/issue/Mobile_HLR-96) - Откат
#### 2.2.16.0
- [Mobile_HLR-96](https://youtrack/issue/Mobile_HLR-96) - minifix Проверка числа pdp-контекстов
- [Mobile_HLR-99](https://youtrack/issue/Mobile_HLR-99) - Добавить возможность управлять флагом RoamingNotAllowed в Load Subscriber
- [Mobile_HLR-88](https://youtrack/issue/Mobile_HLR-88) - Добавить возможность загрузки QoS профиля через Load-Интерфейс 
#### 2.2.15.1
- [Mobile_HLR-93](https://youtrack/issue/Mobile_HLR-93) - Понижение контекста в MAP_Reset
#### 2.2.15.0
- [Mobile_HLR-94](https://youtrack/issue/Mobile_HLR-94) - Определение префикса IMSI для Reset непосредственно в файле
#### 2.2.14.2
- [Mobile_HLR-97](https://youtrack/issue/Mobile_HLR-97) - Некорректное заполнение DSR-Flags при удалении EPS-контекста
#### 2.2.14.1
- [Mobile_HLR-95](https://youtrack/issue/Mobile_HLR-95) - Управление ExperimentalResult через конфиг
#### 2.2.14.0
- [Mobile_HLR-88](https://youtrack/issue/Mobile_HLR-88) - Управление QoS-параметрами PDP и EPS-контекстов абонента
#### 2.2.13.5
- [Mobile_HLR-89](https://youtrack/issue/Mobile_HLR-89) - Не используется RealGT при отправке GetPassword врамках DeactivateSS транзакции
#### 2.2.13.4
- [Mobile_HLR-90](https://youtrack/issue/Mobile_HLR-90) - Не работает рессинхронизация по диаметру
#### 2.2.13.3
- [Mobile_HLR-85](https://youtrack/issue/Mobile_HLR-85)
- [Mobile_HLR-83](https://youtrack/issue/Mobile_HLR-83)
#### 2.2.13.2
- [Mobile_HLR-71](https://youtrack/issue/Mobile_HLR-71) - minifix
#### 2.2.13.1
- [Mobile_HLR-78](https://youtrack/issue/Mobile_HLR-78) - Некорректное декодирование VisitedNetworkIdentity
#### 2.2.13.0
- [Mobile_HLR-75](https://youtrack/issue/Mobile_HLR-75) - Некорректный статус в cdr, отбивать все транзакции с недоступностью базы по resourceLimitation
#### 2.2.12.0
- [Mobile_HLR-67](https://youtrack/issue/Mobile_HLR-67) - Разделение абонентской статистики на HLR и HSS, управление GetStat
#### 2.2.11.0
- [Mobile_HLR-71](https://youtrack/issue/Mobile_HLR-71) - Обработка NetworkAccessMode
#### 2.2.10.0
- [Mobile_HLR-66](https://youtrack/issue/Mobile_HLR-66) - Отдавать GT IPSMGW в ответе на SRI4SM, если абонент не зарегистрирован
#### 2.2.9.2
- [Mobile_HLR-70](https://youtrack/issue/Mobile_HLR-70) - Не отработал DIAM_Reset
#### 2.2.9.1
- [Mobile_HLR-65](https://youtrack/issue/Mobile_HLR-65) - Выдача ODB в EPS домен
#### 2.2.9.0
- [Mobile_HLR-64](https://youtrack/issue/Mobile_HLR-64) - Список GT с реальным GT вместо ipSmGw
#### 2.2.8.4
- [Mobile_HLR-63](https://youtrack/issue/Mobile_HLR-63) - Ошибка при расчетах максимальной скорости (результат в 1000 раз больше) + Out таймер теперь задается в секундах
#### 2.2.8.3
- [Mobile_HLR-62](https://youtrack/issue/Mobile_HLR-62) - Не загрузился DM_BL
#### 2.2.8.2
- [Mobile_HLR-59](https://youtrack/issue/Mobile_HLR-59)
- [Mobile_HLR-60](https://youtrack/issue/Mobile_HLR-60)
#### 2.2.8.1
- Отвечать на UL_GPRS только после выполнения SetRoam
#### 2.2.8.0
- Передавать в GetSD CamelPhases в виде маски
#### 2.2.7.6
- [Mobile_HLR-50](https://youtrack/issue/Mobile_HLR-50) - Упал в коре из-за того, что не было Mutex
#### 2.2.7.5
- [Mobile_HLR-47](https://youtrack/issue/Mobile_HLR-47) - Вывод TotalHandlers
- [Mobile_HLR-49](https://youtrack/issue/Mobile_HLR-49) - Статус SRI TCAP_Error (на самом деле нет)
- [Mobile_HLR-46](https://youtrack/issue/Mobile_HLR-46) - регистрация трапов при запуске
#### 2.2.7.4
- [Mobile_HLR-39](https://youtrack/issue/Mobile_HLR-39) - СОРМ Индикации по S6a сообщениям
#### 2.2.7.3
- [Mobile_HLR-45](https://youtrack/issue/Mobile_HLR-45) - Отвечать на UL только после выполнения SetRoam
#### 2.2.7.2
- [Mobile_HLR-44](https://youtrack/issue/Mobile_HLR-44) - Отбивать левые ussd на основании белого списка, составленного из ussd из hlr.cfg
#### 2.2.7.1
- Удалил min_max_profiler в логиках HLR/HSS, убрал наследование логик от Tm-HLR-Profile, вывод cdr для транзакций, которые не попали в логику из-за их отсутсвия, отдельный параметр в конфиге на кол-во логик диаметра
#### 2.2.7.0
- [Mobile_HLR-34](https://youtrack/issue/Mobile_HLR-34)) - IMEI in ATI & PSI
#### 2.2.6.0
- [Mobile_HLR-33](https://youtrack/issue/Mobile_HLR-33) - по SNMP GET отдавать инофрмацию о занятости логик
#### 2.2.5.2
- [Mobile_HLR-30](https://youtrack/issue/Mobile_HLR-30) - првоерка параметров на корректность
#### 2.2.5.1
- minifix CLIR 
#### 2.2.5.0
- [Mobile_HLR-26](https://youtrack/issue/Mobile_HLR-26) - резервирование BS, (в SRI при отправке PRN MSISDN отправлялся в формате из SRIReq, сделал, что бы отправлялся всегда в INT) 
#### 2.2.4.3
- [Mobile_HLR-22](https://youtrack/issue/Mobile_HLR-22) - некорректное кодирование suboption для clir
#### 2.2.4.2
- Некорректный вывод MSISDN в CDR
#### 2.2.4.1
- Указать относительные пути для Load по умолчанию
#### 2.2.4.0
- [Mobile_HLR-16](https://youtrack/issue/Mobile_HLR-16) - Включать в отправляемый на VLR профиль BAOC в случае, если VLR не поддерживает Camel
#### 2.2.3.2
- [Mobile_HLR-13](https://youtrack/issue/Mobile_HLR-13) - Различные GT для MVNO (исправления)
#### 2.2.3.1
- Freq#17718  замена ssStatus 1 -> 5, 3 -> 7
#### 2.2.3.0
- [Mobile_HLR-13](https://youtrack/issue/Mobile_HLR-13) Различные GT для MVNO
#### 2.2.2.1
- [Mobile_HLR-11](https://youtrack/issue/Mobile_HLR-11) Загрузка абонента с DeactivatePsi = 1
#### 2.2.2.0
- [Mobile_HLR-9](https://youtrack/issue/Mobile_HLR-9) Опционально не запрашивать PSI
#### 2.2.1.25
- [Mobile_HLR-7](https://youtrack/issue/Mobile_HLR-7) Некорректный subscriberStatus: serviceGranted (0) при выставленном ODB 
#### 2.2.1.24
- Freq#17718 Загрузка абонента с привязаным ForcedSS
#### 2.2.1.23
- [Mobile_HLR-2](https://youtrack/issue/Mobile_HLR-2) Падение в коре (обращение к Diam_TrMan, когда в лицензии HSS не было)
#### 2.2.1.22
- [Mobile_HLR-1](https://youtrack/issue/Mobile_HLR-1) Некорректно сформирован номер MSC в SRI4SM-Response
#### 2.2.1.21
- Вывод profilers в отдельный лог
#### 2.2.1.20
- Отправка IpSmGw в SriForSM Resp, если запрос пришел не с этого gt
#### 2.2.1.19
- CancelationType всегда выставлялся SUBSCRIPTION_WITHDRAWAL при запросе с API
#### 2.2.1.18
- При получении ответа на API->CLR отправился ClearRoaming
#### 2.2.1.17
- Freq#17638 Загрузка абонента с привязаным M_CSI
#### 2.2.1.16
- Bug#28881 При отправке PushNotification родительская логика не освобождалась
- Bug#27397
- Bug#28677 (PDA от API)
#### 2.2.1.15
- При загрузке абонента выставлять параметры RatType и RatFreqPriorId в NULL, если они отсутствуют
#### 2.2.1.14
- При отсутсвии в белом списке вернуть en_DIAMETER_ERROR_RAT_NOT_ALLOWED вместо en_DIAMETER_ERROR_ROAMING_NOT_ALLOWED
#### 2.2.1.13
- Не очищался PublicId в UA_SL, неверное сравнение SCSCF в MA_SL
#### 2.2.1.12
- Freq#17201 UCSI Хранение UCSI на HSS
#### 2.2.1.11
- Bug#28801 При получении UL_GPRS не отправляется CLR на MME
#### 2.2.1.10
- Freq#17387
- Bug#28677
- Bug#28778
- Bug#28785
- Bug#28802
#### 2.2.1.9 HLR Load USSD-CSI
#### 2.2.1.8
- Freq# Reset over Diam
#### 2.2.1.7
- Freq#17201 UCSI
#### 2.2.1.6
- Freq# Запуск HSS без SS7
#### 2.2.1.5
- Bug#28485 Не добавляется subscriberStatus в ISD при отсутствии ODB
#### 2.2.1.4
- Bug#28418 Неверная проверка опционального поля DestinationHost
#### 2.2.1.3
- Freq#17154 Ограничения на параметры QOS
#### 2.2.1.2
- Bug#28376 Неуспешная аутинтификация в 4g из-за некорректного декодирования plmn
#### 2.2.1.1
- Freq#17053 Сделать IP-адрес параметром связки контекста и абонента
#### 2.2.1.0
- Freq#17048 Поддержка M3UA IPSP
#### 2.2.0.16
- Bug#28308 Некорректная передача PLMN на BS в рамках AI
#### 2.2.0.15
- Bug#28256 Удалилось местоположение из базы при одиночном CL при неполучении ответа 
#### 2.2.0.14
- Freq#16895 Для неопределенных величин в транзакционной статистике в cdr требуется писать -1 
#### 2.2.0.13
- Freq#16800 Анализ WL по VPLMN + сохранение SF 
#### 2.2.0.12
- Bug#28090 При получении reject-компонент из-за некорректно закодированного ISD HLR сразу не завершает транзакцию по reject-компоненте.
#### 2.2.0.11
- Bug#28031 Некорректный ton в ответе на SRI с MSISDN в national формате
#### 2.2.0.10
- Bug#27975 Отвечаем на NOR с 5012
#### 2.2.0.9
- Bug#27920 Не вложили MSRN в SRI-Resp
#### 2.2.0.8
- Bug#27916 Не вложили T-CSI в SRI-Resp
#### 2.2.0.7
- Bug#27907 При конвертации USSD в mapv3 MSISDN кодируется как 00
#### 2.2.0.6
- Freq#16592 Добавить в правила USSD группы
#### 2.2.0.5
- Freq#16375, 16376, 16371
#### 2.2.0.4
- Freq#16374 Реализация IMS-AKA + Обновление Diameter логик до версии HSS.LTE 2.1.40.10.749
#### 2.2.0.3
- Bug#27073 SAA не чистится список associated-identities
#### 2.2.0.2
- Bug#27059 Сформировал MAA с 3мя SIP_Auth_Data_Item
#### 2.2.0.1
- Bug#27003 поддержка SGP
#### 2.2.0.0
- Freq#15505 поддержка IMS 
#### 2.1.36.2
- Freq#15574 Передача PDP_ADDRESS в ISD на SGSN
#### 2.1.36.0
- Freq#15527 Добавить поддержку extQoS2, extQoS3 и extQoS4 для pdp_контекстов
#### 2.1.35.1
- Bug#26789 Неверное заполнение Vendor-Specific-Application-Id
#### 2.1.35.0
- Reset
#### 2.1.34.1
- Freq#15406 Обработка SRi4SM при отсутсвии телесервиса MT-SMS
#### 2.1.34.0
- Freq#15304 Поддержка LCS
#### 2.1.33.1
- Bug#26452 упали в коре на SRI
#### 2.1.32.5
- Bug#26160 Ошибка 5012 в Notify
#### 2.1.32.4
- Freq#14992 Не отправляет ответ с 5004 в сеть
#### 2.1.32.3
- Bug#26111 Не считываются параметры OP_ID AucC_ID AucR_ID
#### 2.1.32.2
- Freq#14665 Загрузка WL через Load интерфейс
#### 2.1.32.1
- Freq#14898 использование IND при генерации SQN, доработка в HSS
#### 2.1.32.0
- Freq#14898 использование IND при генерации SQN
#### 2.1.31.2
- Bug#25984 Некорреткный interrogateSS_resp для баррингов 
#### 2.1.30.3
- Freq#14665 Работа с белыми листами в HSS
#### 2.1.30.2
- Bug#25878 Отсутствие tid в cdr (Исходящие транзакции)
#### 2.1.30.1
- Freq#14900 Разделитель для diam_cdr берем из trace.cfg
#### 2.1.30.0
- Freq#14900 Изменен формат diam_cdr, разделитель ';' заменен на ','
#### 2.1.29.0
- Freq#14541 Процедура ресинхронизации SQN
#### 2.1.28.0
- Freq#14665 Возможность задавать несколько белых списков, а не один.
#### 2.1.26.5
- Bug#25605 При реистрации на SGSN, множество запросов завершаются с UNABLE_TO_COMPLY (5012) 
#### 2.1.26.4
- Bug#25390 При добавлении context_id ISR завершается 5004
#### 2.1.26.3
- Bug#25348 ISD/DSD на SGSN при смене MSISDN
#### 2.1.26.2
- Bug#25309 Неуспешные PSI/PRN транзакции не пишутся в cdr-файлы и не учитываются в статистике
#### 2.1.26.1
- Bug#25277 понижение версии для PRN
#### 2.1.26.0
- Freq#14260 Телесервисы доп. услуг
#### 2.1.25.2
- Bug#25206 Некорректная запись diameter-транзакций в trafic_stat
#### 2.1.25.1
- Некорректно формируется SessionID
#### 2.1.25.0
- Freq#14259 Управление статусом доп. услуг при загрузке абонентов
#### 2.1.24.4
- Bug#24919 При изменении статуса ss в ISD отправляется дефолтная переадресация
#### 2.1.24.4
- AMBR and RAT-Freq eq 0 in answer
#### 2.1.24.3
- Bug#24941 Неправильный Cancellation-Type при отправки CLR от API;
- Bug#24924 Неверный ResultCode в AIA при Admin_State != 2; Исправление декодирования NOR
#### 2.1.24.2
- Bug#24919 При изменении статуса ss в ISD отправляется дефолтная переадресация
#### 2.1.24.1
- Bug#24914 Некорректный ISD при наличии у ss телесервиса -1
#### 2.1.24.0
- use License
#### 2.1.23.6
- Объединение с 2.0.23.6
#### 2.0.23.6
- Bug$24905 На все запросы отвечали tcap_abort
#### 2.1.23.5
- Объединение с 2.0.23.5
#### 2.0.23.5
- Freq#14247 Forwarding options для дефолтной переадресации
#### 2.1.23.3
- Объединение с 2.0.23.3
#### 2.0.23.4
- Bug#24883 Некорректный выбор FTN для CFNRC
#### 2.0.23.3
- Bug#23793 При попытке регистрации переадресации с отсутствующим у абонента телесервисом, register_SS отбивается с unknown_subscriber 
#### 2.1.22.2
- Объединение с 2.0.22.2
#### 2.0.22.2
- Freq# Добавление CFNA для дефолтовой переадресации 
#### 2.1.22.1
- Объединение с 2.0.22.1 
#### 2.0.22.1
- Bug#24736 При загрузке абонента в случае получения PDA_error hlr не пишет ошибку в файл error
#### 2.0.22.0
- Greq#14134 Репликация данных на SGSN при внесении изменений через API
#### 2.0.21.3
- Freq#13985 возможность задавать различные параметры симкарты в AUC (LoadSubscriber)
#### 2.0.21.2
- Freq#14090 Передача изменений SMS-CSI в случае обновления профиля через API
#### 2.0.20.4
- Bug#24550 AlertSC Application context name
#### 2.1.19.0
- Объединение с 2.0.20.3
#### 2.0.20.3
- Bug#24340 Не удаляется запись из MWD в случае если на ASC был получен UDTS.(убрать повторные отправки ASC)
#### 2.0.20.2
- Bug#24482 понижение версии MAP для Cancel location
#### 2.0.19.0
- Bug#24443 медленная обработка gprs_ul
#### 2.0.18.5
- Freq#13950 Необходимо исключить посылку ss с plmn-specific tele-service в ISD на VLR
#### 2.0.18.3
- Bug#24394 Заполнение Camel-TDP-Criteria-List в SRI-Resp
#### 2.1.18.0
- Freq#13926
- Загрузка абонентов
#### 2.0.18.1
- merge (1.0.28.3 -Bug#24374 PRN транзакции не учитываются в traffic_stat)
#### 2.0.18.0
- merge (1.0.28.0 -Freq#13609 Логгирование операции загрузки абонентских профилей
- 								1.0.28.1 -Bug#24340 Не удаляется запись из MWD в случае если на ASC был получен UDTS)
#### 2.1.17.1
- merge (1.0.27.1, 2.0.17.1 -Bug#24313 падаем в коре при получении SRI)
#### 2.0.17.1
- merge (1.0.27.1 -Bug#24313 падаем в коре при получении SRI)
#### 2.1.16.5
- Передача Cancel Location по запросу от API 
#### 2.1.16.4
- add ULA-Flags and Supported-Features to UpdateLocationAnswer
#### 2.0.16.4
- merge (1.0.26.7 -Freq#12910 информирование о USSD)
#### 2.1.16.3
- merge
#### 2.0.16.3
- merge (1.0.26.6  sccp cgpn tt =0)
#### 2.0.16.2
- merge (1.0.26.5 -Bug#24203 выдали кучу clip в ответе на SRI)
#### 2.0.16.1
- Bug#24181 Кодирование provisioned_ss
#### 2.1.16.2
- Bug#24176 Формирование OrigHost и OrigReakm из diameter.cfg 
#### 2.1.16.1
- Bug#24166 Неверный формат передачи параметра PLMN_ID 
#### 2.0.16.0
- Freq#13730 Возможность передавать chargingcharacteristics вне параметра GPRSSubscriptionData
- Bug#23921 ActivateSS.Не отправили в ISD подключаемый SS
- merge (1.0.26.2 -Bug#24111 При ошибочном завершении транзакции PSI не пишутся cdr)
#### 2.0.15.1
- merge (1.0.26.1 -Bug#24074 AlertSC.Постоянные перепосылки при получении tcap.abort.)
#### 2.0.15.0
- merge (1.0.26.0 -Freq#12866 Возможность транзита SAI
- 					 -Freq#12867 SMS Home Routing)
#### 2.0.13.3
- Bug#24023 Ошибка при вставке в Tm_Roaming
#### 2.0.13.2
- SRI
#### 2.0.13.1
- Bug#23976 UpdateLocation GPRS не отправились chargingCharacteristics
#### 2.0.13.0
- merge (Подсистема аварий)
#### 2.0.12.4
- Bug#23921 ActivateSS.Не отправили в ISD подключаемый SS
#### 2.0.12.3
- merge (1.0.23.3 -Bug#23922 USSD.Срабатывает 20сек таймер при ожидании USSR_resp)
#### 2.0.12.2
- merge (1.0.23.2 -Bug#23864 Некорреткный ErrorCode при запрете регистрации по белым спискам VLR
- 				 -Bug#23863 Отбивается RestoreData при наличии у аб-та WHITE_LIST_VLR.)
#### 2.0.12.1
- Bug# 23891  падение в коре при удалении T-CSI через API
#### 2.0.12.0
- OMI для API перенесено в SL
#### 2.0.11.0
- merge (1.0.23.0 -Freq#13220 Возможность использования нескольких транспортных ключей (привязка TK к абоненту через LoadSubscriber))
#### 2.0.10.7
- Bug#23843 Не работает unconditional forwarding (SRI, CSI)
#### 2.0.10.6
- merge (1.0.22.1 -Bug#23761 Cancel Location SGSN
-  1.0.22.2 -Bug#23822 Висит транзакция ISD при получении ISD_resp с error (HLR))
- 					RegisterSS, ActivateSS, DeactivateSS, EraseSS  если не пришел SS из базы, посылать SS_NotAvailable
#### 2.0.10.4
- Bug#780 BcsmCamelTDP_CriteriaList
#### 2.0.10.3
- Bug#23768 UpdateLocation транзакция вставки IMSI в ISD
#### 2.0.10.2 Некорректно закодированный class MAP_Ext_CallBarringFeature +merge (1.0.22.1 -Bug#23761 Cancel Location SGSN)
#### 2.0.10.1
- merge (1.0.20.1 -Bug#23747 При обработке RestoreData GetSD_Req уходит с CamelPhase=0)
#### 2.0.10.0
- merge (1.0.19.1 TraficStatistics Добавление ErrorCode = ERROR_BY_RX_TCAP_ABORT (-3))
#### 2.0.9.0
- merge (1.0.16.1 -Freq#12599 API, отключение избыточного трафика
-  1.0.16.2 -Freq#12895 Вынести TCAP-таймер в конфигурацию
-  1.0.16.3 -Freq#12910 СОРМ HLR: информирование о USSD
-  1.0.16.4 -Bug#23632 При поступлении TCAP_Begin с некорректной диалоговой частью приложение падает в core
-  1.0.18.0 -Freq#13164 Ограничение роуминга белыми списками
- )
#### 2.0.8.3
- Bug#23555 некорректно кодируются форвардинги в ISD
#### 2.0.8.2
- Кодирование MApv2::InterrogateSS
#### 2.0.8.1
- merge (1.0.15.5 -Freq#23322 добавление возможности выставления переадресации для карты при загрузке через load_profile)
#### 2.0.8.0
- merge (
-  1.0.12.2 -Freq#13261 Обрабаотка переадресация в статусе 3
-  1.0.13.0 -Freq#13216 Загрузка PDP профиля
-  1.0.13.1 -Bug#23311 Использование Secondary подключений в OMI направлении
-  1.0.14.0 -Freq#23217 привязка PDP профиля абоненту
-  1.0.14.1 -Freq#12597 Разрешать/запрещать регистрацию в VLR, не поддерживающем camel
-  1.0.15.0 -Freq#13276 Доработка статистики UnblockCount
-  1.0.15.1 -Bug#23385 Отсутсвует индикация о неуспешной загрузке абонента в БД
-  1.0.15.2 -Freq#13246 При успешной регистрации отправлять MAP_AlertServiceCenter
- 				  M2PA ProductInfo
-  1.0.15.3 -Bug#23385 Отсутсвует индикация о неуспешной загрузке абонента в БД
-  1.0.15.5 -Freq#23322 добавление возможности выставления переадресации для карты при загрузке через load_profile)
#### 2.0.7.2
- ISD_GPRS Добавлены Network Access Mode и Subscriber Status, BearerService, Teleservice
#### 2.0.7.1
- API_SL Added IMSI to ISD
#### 2.0.7.0
- merge (
-  1.0.9.10 -Freq#12910 СОРМ HLR: информирование о USSD (изменение формата команд)
-  1.0.10.0 -Freq#13236 Повышение версии MAP и вставка MSISDN при проксировании USSD
-  1.0.11.0 -Freq#13212 режим работы с виртуальным GT
- 				 -Freq#13241 Subscriber-Info в ответе на SRI без Suppress T-CSI
-  1.0.11.1 -Bug#23357 Понижение версии MAP для AlertSC
-  1.0.12.0 -Freq#13260 SubscriberInfo для случая, когда в базе нет VLR
- 				 -Freq#13232 Обработка PurgeMS
-  1.0.12.1 -Bug#23373 MAP ошибка при lforbidreg_withoutcamel)
#### 2.0.2.0
- Кодирование CSI для хранения в DB
#### 2.0.1.4
- merge (1.0.9.9 -Freq#12910 СОРМ HLR: информирование о USSD)
#### 2.0.1.3
- merge (1.0.9.8 -Freq#12990 Доработка загрузки кемел профиля согласно описанию на вики)
#### 2.0.1.1
- merge (1.0.9.6 -Freq#12753  СОРМ HLR информирование об изменении статуса ДВО абонента)
#### 2.0.1.0
- merge
- 	(1.0.9.5 -Freq#12458  DSD for Camel-profile,
- 	1.0.9.4 -Freq#12905  Добавление в API интерфейс команд AddSubscriber и DeleteSubscriber
- 	1.0.9.3 -Bug#23011  некорректный ISD при изменении ODB из API
- 				-Bug#23016  SegmentationProhibeted для Millenage
- 	1.0.9.2 -Freq#12895 PSI timer = 12000)
#### 2.0.0.0
- MultiThread version
#### 1.0.9.1
- Bug#22865 падение в core при обработке UL с vlr-Capability: informPreviousNetworkEntity
#### 1.0.9.0
- Freq#12725 статистика abonent_stat (текущее кол-во зарегистрированных абонентов)
#### 1.0.8.1
- Bug#22695 SRI+PRN.Ошибка Unknown(-1) при недоступности абонента.
- 				Bug#22699 USSD. Некорректный SSN в CdPN.
#### 1.0.8.0
- Freq#12551 статистика abonent_stat
#### 1.0.7.1
- Bug#22618 Не задекодирован ответ на PurgeMS
#### 1.0.7.0
- Freq#12597 Разрешать/запрещать регистрацию в VLR, не поддерживающем ...
#### 1.0.6.0
- Freq#12516 добавить msisdn в USSD
#### 1.0.5.0
- Freq#12551 статистика trafic_stat
#### 1.0.4.0
- Freq#12514 Вставка баррингов и переадресации для групповых операций (API_SL)
#### 1.0.3.0
- Freq#12447 Необходимо реализовать преобразование номера переадресации...
- 				Bug#22507 Некорректный NAI
- //1.0.3.0 Added Reset
#### 1.0.2.0
- Freq#12514 Вставка баррингов и переадресации для групповых операций.
- 				Bug#22402 Неуспешная регистрация при включенной переадресацией без FTN
#### 1.0.1.2
- ChopEndline in MO_USSD
#### 1.0.1.1
- Bug#22359
- Bug#22379
#### 1.0.1.0
- Added CDR
- Freq#12470
#### 1.0.0.3
- Bugfix# 22298
#### 1.0.0.2
- Freq#12243
#### 1.0.0.1
- Freq#12260
#### 1.0.0.0
- First version
